import requests
import json
import jwt
import time
import boto3
from botocore.exceptions import ClientError
import urllib.parse

def get_secret(secret_id="eqa-evidence-integrations"):
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name='us-east-1'
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_id
        )
    except ClientError as e:
        print("Error in get_secret function")
        raise e
    
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

class GitHubAlertsIntegration:

    def __init__(self):
        self.api_base = "https://api.github.com"
        self.search_api_base = "https://api.github.com/search/"
        self.token = None
        self.evidence_secrets = get_secret()
        self.key = self.evidence_secrets["Git-App-Key"].replace('\\n', '\n')
        self.clientid = self.evidence_secrets["Git-App-ClientID"]
        self.installid = self.evidence_secrets["Git-App-InstallID"]
        self.gen_new_gitaccess()

    def gen_new_gitaccess(self):
        self.generate_jwt()
        self.get_installation_token()
        self.get_headers()

    def generate_jwt(self):
        payload = {
            'iat': int(time.time()),
            'exp': int(time.time()) + 590,
            'iss': self.clientid
        }
        encoded_jwt = jwt.encode(payload, self.key, algorithm='RS256')
        self.jwt_token = encoded_jwt

    def get_installation_token(self):
        headers = {
            'Authorization': f'Bearer {self.jwt_token}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        }
        url = f"{self.api_base}/app/installations/{self.installid}/access_tokens"
        response = requests.post(url, headers=headers)
        data = response.json()
        self.token = data['token']

    def get_headers(self):
        self.headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        }

    def get_repos_by_appci(self, appci):
        query_string = f"props.AppCI:{appci} org:United-Airlines-Org archived:false"
        url = f"{self.search_api_base}repositories?q={urllib.parse.quote(query_string)}&per_page=100"
        
        repos = []
        
        try:
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                data = response.json()
                if 'items' in data:
                    for repo in data['items']:
                        repo_full_name = repo['full_name']
                        if repo_full_name not in repos:
                            repos.append(repo_full_name)
                    print(f"Found {len(repos)} repositories for AppCI: {appci}")
                else:
                    print(f"No repositories found for AppCI: {appci}")
            else:
                print(f"Error fetching repos: {response.status_code} - {response.text}")
                
        except Exception as e:
            print(f"Exception fetching repos for AppCI {appci}: {e}")
            return []
        
        return repos

    def get_code_scanning_alerts(self, repo_owner, repo_name):
        url = f"{self.api_base}/repos/{repo_owner}/{repo_name}/code-scanning/alerts"
        params = {
            'state': 'open',
            'per_page': 100
        }
        
        all_alerts = []
        
        try:
            while url:
                response = requests.get(url, headers=self.headers, params=params)
                
                if response.status_code == 200:
                    alerts = response.json()
                    all_alerts.extend(alerts)
                    
                    if 'Link' in response.headers:
                        links = response.headers['Link'].split(',')
                        url = None
                        for link in links:
                            if 'rel="next"' in link:
                                url = link[link.find('<')+1:link.find('>')]
                                params = None
                                break
                    else:
                        url = None
                elif response.status_code == 404:
                    print(f"Code scanning not enabled or accessible for {repo_owner}/{repo_name}")
                    break
                else:
                    print(f"Error fetching code scanning alerts: {response.status_code} - {response.text}")
                    break
                    
        except Exception as e:
            print(f"Exception fetching code scanning alerts: {e}")
            return []
        
        return all_alerts

    def get_all_alerts(self, repo_owner, repo_name):
        print(f"Fetching alerts for {repo_owner}/{repo_name}...")
        
        alerts = {
            "repository": f"{repo_owner}/{repo_name}",
            "code_scanning_alerts": self.get_code_scanning_alerts(repo_owner, repo_name)
        }
        
        alerts["summary"] = {
            "code_scanning_count": len(alerts["code_scanning_alerts"]),
            "total_alerts": len(alerts["code_scanning_alerts"])
        }
        
        return alerts

    def save_alerts_to_file(self, alerts, filename="github_alerts.json"):
        try:
            with open(filename, 'w') as f:
                json.dump(alerts, f, indent=2)
            print(f"\nAlerts saved to {filename}")
            return True
        except Exception as e:
            print(f"Error saving alerts to file: {e}")
            return False

    def extract_specific_findings(self, all_alerts_data, repo_name, finding_id):
        results = {}
        repos_with_findings = {}
        
        for repo_data in all_alerts_data.get("repositories", []):
            full_repo_name = repo_data.get("repository", "")
            
            if repo_name not in full_repo_name:
                continue
            
            paths = []
            severity = None
            
            for alert in repo_data.get("code_scanning_alerts", []):
                rule_id = alert.get("rule", {}).get("id", "")
                
                if finding_id in rule_id:
                    path = alert.get("most_recent_instance", {}).get("location", {}).get("path", "")
                    
                    if path:
                        paths.append(path)
                        if not severity:
                            severity = alert.get("rule", {}).get("security_severity_level", "")
            
            if paths:
                repos_with_findings[full_repo_name] = paths
        
        if repos_with_findings:
            results = {
                "finding_id": finding_id,
                "severity": severity,
                "total_occurrences": sum(len(paths) for paths in repos_with_findings.values()),
                "repositories": []
            }
            
            for repo, paths in repos_with_findings.items():
                results["repositories"].append({
                    "repository": repo,
                    "path_count": len(paths),
                    "paths": paths
                })
        
        return results


if __name__ == "__main__":
    APPCI = "AQQ"
    OUTPUT_FILE = "github_alerts_output.json"
    
    print("GitHub Alerts Proof of Concept")
    print("=" * 60)
    print(f"AppCI: {APPCI}")
    print("=" * 60)
    
    gh_alerts = GitHubAlertsIntegration()
    
    print(f"\nFetching repositories for AppCI: {APPCI}...")
    repos = gh_alerts.get_repos_by_appci(APPCI)
    
    if not repos:
        print(f"No repositories found for AppCI: {APPCI}")
        print("Exiting...")
        exit(0)
    
    print(f"\nFound {len(repos)} repositories. Fetching alerts for each...\n")
    
    all_alerts_data = {
        "appci": APPCI,
        "total_repositories": len(repos),
        "repositories": []
    }
    
    total_code_scanning = 0
    
    for i, repo_full_name in enumerate(repos, 1):
        parts = repo_full_name.split('/')
        if len(parts) != 2:
            print(f"Skipping invalid repo name: {repo_full_name}")
            continue
        
        repo_owner = parts[0]
        repo_name = parts[1]
        
        print(f"[{i}/{len(repos)}] Processing {repo_full_name}...")
        
        alerts = gh_alerts.get_all_alerts(repo_owner, repo_name)
        
        total_code_scanning += alerts['summary']['code_scanning_count']
        
        all_alerts_data["repositories"].append(alerts)
        
        print(f"   └─ Code Scanning Alerts: {alerts['summary']['code_scanning_count']}\n")
    
    all_alerts_data["overall_summary"] = {
        "total_code_scanning_alerts": total_code_scanning
    }
    
    print("\n" + "=" * 60)
    print("OVERALL SUMMARY")
    print("=" * 60)
    print(f"Total Repositories Scanned: {len(repos)}")
    print(f"Total Code Scanning Alerts: {total_code_scanning}")
    
    gh_alerts.save_alerts_to_file(all_alerts_data, OUTPUT_FILE)
    
    print("\n" + "=" * 60)
    print("Test completed!")
    print("=" * 60)
    
    specific_findings = gh_alerts.extract_specific_findings(
        all_alerts_data,
        "AQQ-Aflyer-Model-Optimization",
        "toctou-race-condition"
    )
    
    print("\n" + "=" * 60)
    print("SPECIFIC FINDINGS EXTRACTION")
    print("=" * 60)
    print(f"Finding: {specific_findings.get('finding_id', 'N/A')}")
    print(f"Severity: {specific_findings.get('severity', 'N/A')}")
    print(f"Total occurrences: {specific_findings.get('total_occurrences', 0)}\n")
    
    for repo_data in specific_findings.get("repositories", []):
        print(f"Repository: {repo_data['repository']}")
        print(f"Path count: {repo_data['path_count']}")
        print("Paths:")
        for i, path in enumerate(repo_data['paths'], 1):
            print(f"  {i}. {path}")
        print()
    
    with open("specific_findings.json", "w") as f:
        json.dump(specific_findings, f, indent=2)
    print("Specific findings saved to specific_findings.json")
