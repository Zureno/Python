import json
import csv
import sys
from pathlib import Path


def extract_findings_validators(json_file_path, output_csv_path):
    with open(json_file_path, 'r') as f:
        data = json.load(f)
    
    csv_rows = []
    
    for control_item in data:
        control_id = control_item.get('control', '')
        enabled = control_item.get('enabled', False)
        validators = control_item.get('validators', [])
        
        has_findings = False
        for validator in validators:
            if validator.get('type') == 'findings':
                has_findings = True
                tool = validator.get('tool', '')
                scope = validator.get('scope', '')
                criteria = validator.get('criteria', [])
                
                criteria_str = '; '.join([str(c) for c in criteria])
                
                csv_rows.append({
                    'Control': control_id,
                    'Enabled': enabled,
                    'Tool': tool,
                    'Scope': scope,
                    'Criteria': criteria_str
                })
        
    if csv_rows:
        with open(output_csv_path, 'w', newline='') as csvfile:
            fieldnames = ['Control', 'Enabled', 'Tool', 'Scope', 'Criteria']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            writer.writerows(csv_rows)
        
        print(f"Successfully extracted {len(csv_rows)} findings validators to {output_csv_path}")
    else:
        print("No findings validators found in the JSON file.")


if __name__ == '__main__':
    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    json_file = project_root / 'src' / 'control' / 'appsecrequirements' / 'ASVS.json'
    output_csv = project_root / 'findings_validators.csv'
    
    if len(sys.argv) > 1:
        json_file = Path(sys.argv[1])
    if len(sys.argv) > 2:
        output_csv = Path(sys.argv[2])
    
    if not json_file.exists():
        print(f"Error: JSON file not found at {json_file}")
        sys.exit(1)
    
    extract_findings_validators(json_file, output_csv)
