#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from typing import Dict, Any, Iterable, List, Tuple
import json
import os
from datetime import datetime

import boto3
from botocore.config import Config


def iter_scan(table, page_limit: int | None = None) -> Iterable[Dict[str, Any]]:
    exclusive_start_key = None
    pages = 0

    while True:
        scan_kwargs = {}
        if exclusive_start_key is not None:
            scan_kwargs["ExclusiveStartKey"] = exclusive_start_key

        resp = table.scan(**scan_kwargs)
        for item in resp.get("Items", []):
            yield item

        exclusive_start_key = resp.get("LastEvaluatedKey")
        pages += 1
        if page_limit is not None and pages >= page_limit:
            break
        if not exclusive_start_key:
            break


def _parse_json_list(raw: Any) -> List[Dict[str, Any]]:
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str):
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                return data
        except Exception:
            return []
    return []


def _parse_queue(raw: Any) -> List[Dict[str, Any]]:
    return _parse_json_list(raw)


def _parse_results(raw: Any) -> List[Dict[str, Any]]:
    return _parse_json_list(raw)


def has_control(item: Dict[str, Any], control_name: str) -> bool:
    queue = _parse_queue(item.get("validation_queue"))
    for entry in queue:
        if isinstance(entry, dict) and entry.get("control") == control_name:
            return True
    return False


def count_results(item: Dict[str, Any], control_name: str) -> Tuple[int, bool]:
    results = _parse_results(item.get("validation_results"))
    occ = 0
    present = False
    for entry in results:
        if isinstance(entry, dict) and entry.get("control") == control_name:
            occ += 1
            present = True
    return occ, present


def collect_identifiers(item: Dict[str, Any]) -> str | None:
    ident = item.get("identifier")
    if isinstance(ident, str):
        return ident
    if isinstance(ident, (int, float)):
        return str(ident)
    return None


def main(argv: List[str]) -> int:
    parser = argparse.ArgumentParser(description="Count entities with a specific control in validation_queue")
    parser.add_argument(
        "--table",
        default="eqa-cdr-processing-table",
        help="DynamoDB table name (default: eqa-cdr-processing-table)",
    )
    parser.add_argument("--control", default="CDR-NSS3.4.2 - App01", help="Control name to look for")
    parser.add_argument("--region", default=None, help="AWS region, e.g. us-east-1")
    parser.add_argument("--profile", default=None, help="AWS credentials profile to use")
    parser.add_argument("--show-ids", action="store_true", help="Print identifiers that match")
    parser.add_argument("--page-limit", type=int, default=None, help="Limit number of scan pages (debug)")
    parser.add_argument("--json", action="store_true", help="Output a JSON report")
    parser.add_argument("--output", default=None, help="Write JSON report to a file path")

    args = parser.parse_args(argv)

    session_kwargs = {}
    if args.profile:
        session_kwargs["profile_name"] = args.profile

    session = boto3.Session(**session_kwargs)

    config = Config(retries={"max_attempts": 10, "mode": "adaptive"})
    resource = session.resource("dynamodb", region_name=args.region, config=config)
    table = resource.Table(args.table)

    total = 0
    queue_matched = 0
    results_entities = 0
    results_occurrences = 0
    queue_ids: List[str] = []
    results_ids: List[str] = []
    queue_set: set[str] = set()
    results_set: set[str] = set()

    for item in iter_scan(table, page_limit=args.page_limit):
        total += 1
        if has_control(item, args.control):
            queue_matched += 1
            ident = collect_identifiers(item)
            if ident is not None:
                queue_set.add(ident)
                if args.show_ids:
                    queue_ids.append(ident)

        occ, present = count_results(item, args.control)
        results_occurrences += occ
        if present:
            results_entities += 1
            ident = collect_identifiers(item)
            if ident is not None:
                results_set.add(ident)
                if args.show_ids:
                    results_ids.append(ident)

    diff_ids = sorted(queue_set - results_set)

    report = {
        "table": args.table,
        "region": args.region or None,
        "control": args.control,
        "total_scanned": total,
        "queue_entities": queue_matched,
        "results_entities": results_entities,
        "results_occurrences": results_occurrences,
        "diff": {
            "queue_but_not_results_count": len(diff_ids),
            "identifiers": diff_ids,
        },
    }
    payload = json.dumps(report, indent=2)
    output_path = args.output
    if not output_path:
        base_dir = os.path.dirname(os.path.dirname(__file__))
        out_dir = os.path.join(base_dir, "reports")
        os.makedirs(out_dir, exist_ok=True)
        safe_control = "".join(ch if ch.isalnum() else "_" for ch in args.control)
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        output_path = os.path.join(out_dir, f"validation_queue_vs_results_{safe_control}_{ts}.json")

    if args.json:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(payload + "\n")
        print(payload)
        print(f"\nWrote JSON report to: {output_path}")
    else:
        print("Table:", args.table)
        print("Region:", args.region or "(session default)")
        print("Control:", args.control)
        print(f"Total items scanned: {total}")
        print(f"Entities with control in validation_queue: {queue_matched}")
        print(f"Entities with control in validation_results: {results_entities}")
        print(f"Total occurrences in validation_results: {results_occurrences}")
        print(f"Queue but not results: {len(diff_ids)}")

        if args.show_ids:
            if queue_ids:
                print("\nQueue identifiers:")
                for ident in sorted(set(queue_ids)):
                    print(ident)
            if results_ids:
                print("\nResults identifiers:")
                for ident in sorted(set(results_ids)):
                    print(ident)
            if diff_ids:
                print("\nQueue-only identifiers:")
                for ident in diff_ids:
                    print(ident)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(payload + "\n")
        print(f"\nWrote JSON report to: {output_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
