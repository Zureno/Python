#!/usr/bin/env python3
import os
import sys
import time
import argparse
from typing import Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

DEFAULT_TABLE = os.getenv("DDB_TABLE", "eqa-cdr-processing-table")
DEFAULT_REGION = os.getenv("AWS_REGION", os.getenv("AWS_DEFAULT_REGION", "us-east-1"))
TARGET_DATE = "01/01/1900"
PRIMARY_KEY = "identifier"  # Adjust if your table's PK differs
ATTRIBUTE_NAME = "last_processed"
VALIDATION_RESULTS_ATTR = "validation_results"


def make_client(region: str):
    return boto3.resource("dynamodb", region_name=region, config=Config(retries={"max_attempts": 10, "mode": "standard"}))


def scan_all_items(table, projection_expression: Optional[str] = None):
    """Yield all items from the table using paginated Scan."""
    kwargs = {}
    if projection_expression:
        kwargs["ProjectionExpression"] = projection_expression

    while True:
        resp = table.scan(**kwargs)
        for item in resp.get("Items", []):
            yield item
        last_evaluated_key = resp.get("LastEvaluatedKey")
        if not last_evaluated_key:
            break
        kwargs["ExclusiveStartKey"] = last_evaluated_key


def update_item_with_retry_two_attrs(table, key: dict, attr1: str, val1, attr2: str, val2, max_retries: int = 5):
    """Update two attributes with exponential backoff on throttling."""
    delay = 0.5
    for attempt in range(max_retries):
        try:
            table.update_item(
                Key=key,
                UpdateExpression="SET #a1 = :v1, #a2 = :v2",
                ExpressionAttributeNames={"#a1": attr1, "#a2": attr2},
                ExpressionAttributeValues={":v1": val1, ":v2": val2},
                ReturnValues="NONE",
            )
            return True
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code")
            if code in {"ProvisionedThroughputExceededException", "ThrottlingException"}:
                time.sleep(delay)
                delay = min(delay * 2, 5.0)
                continue
            raise
    return False


def main():
    parser = argparse.ArgumentParser(description="Reset last_processed to 01/01/1900 for all items in a DynamoDB table.")
    parser.add_argument("--table", default=DEFAULT_TABLE, help="DynamoDB table name (default: env DDB_TABLE or eqa-cdr-processing-table)")
    parser.add_argument("--region", default=DEFAULT_REGION, help="AWS region (default: env AWS_REGION or us-east-1)")
    parser.add_argument("--dry-run", action="store_true", help="Don't write updates; only show count of items to change")
    args = parser.parse_args()

    ddb = make_client(args.region)
    table = ddb.Table(args.table)

    total = 0
    changed = 0
    skipped_missing_pk = 0

    # Only fetch PK and the target attribute to minimize RCUs
    for item in scan_all_items(table, projection_expression=f"{PRIMARY_KEY}, {ATTRIBUTE_NAME}"):
        total += 1
        pk_val = item.get(PRIMARY_KEY)
        if pk_val is None:
            skipped_missing_pk += 1
            continue

        current_val = item.get(ATTRIBUTE_NAME)
        if args.dry_run:
            # Count items that would change; we set to TARGET_DATE regardless
            changed += 1
            continue

        ok = update_item_with_retry_two_attrs(
            table,
            {PRIMARY_KEY: pk_val},
            ATTRIBUTE_NAME,
            TARGET_DATE,
            VALIDATION_RESULTS_ATTR,
            "[]",
        )
        if ok:
            changed += 1
            if changed % 100 == 0:
                print(f"Updated {changed} items so far...")
        else:
            print(f"Failed to update item with {PRIMARY_KEY}={pk_val}", file=sys.stderr)

    print("\nSummary:")
    print(f"  Scanned items: {total}")
    print(f"  Updated items: {changed}{' (dry-run)' if args.dry_run else ''}")
    if skipped_missing_pk:
        print(f"  Skipped (missing {PRIMARY_KEY}): {skipped_missing_pk}")


if __name__ == "__main__":
    main()
