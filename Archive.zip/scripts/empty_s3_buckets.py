#!/usr/bin/env python3
from __future__ import annotations

import argparse
from typing import List

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError


ver = "1.0.0"
BUCKET = "eqa-udcrm-datalake-bucket-dev"


def batched(keys: List[dict], size: int):
    for i in range(0, len(keys), size):
        yield keys[i : i + size]


def empty_bucket(prefix: str | None, region: str | None, profile: str | None, dry_run: bool) -> None:
    session_kwargs = {}
    if profile:
        session_kwargs["profile_name"] = profile
    session = boto3.Session(**session_kwargs)
    s3 = session.client("s3", region_name=region, config=Config(retries={"max_attempts": 10, "mode": "standard"}))

    deleted = 0
    paginator = s3.get_paginator("list_objects_v2")
    kwargs = {"Bucket": BUCKET}
    if prefix:
        kwargs["Prefix"] = prefix

    print(f"Bucket: {BUCKET}")
    if prefix:
        print(f"Prefix: {prefix}")
    if dry_run:
        print("Dry-run: listing only, no deletes will be made.")

    for page in paginator.paginate(**kwargs):
        contents = page.get("Contents", [])
        keys = [{"Key": obj["Key"]} for obj in contents]
        if not keys:
            continue
        if dry_run:
            continue
        for chunk in batched(keys, 1000):
            s3.delete_objects(Bucket=BUCKET, Delete={"Objects": chunk, "Quiet": True})
            deleted += len(chunk)

    print(f"Deleted objects: {deleted}" + (" (dry-run)" if dry_run else ""))


def main() -> int:
    ap = argparse.ArgumentParser(description="Empty the datalake S3 bucket (non-versioned)")
    ap.add_argument("--prefix", default=None, help="Optional key prefix to limit deletions")
    ap.add_argument("--region", default=None)
    ap.add_argument("--profile", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    try:
        empty_bucket(prefix=args.prefix, region=args.region, profile=args.profile, dry_run=args.dry_run)
    except ClientError as e:
        print(f"AWS error: {e}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
