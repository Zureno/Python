#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple

import boto3
from botocore.config import Config

TABLE_NAME = "eqa-cdr-processing-table"
CONTROL_NAME = "CDR-NSS3.4.2 - App01"
DEFAULT_REGION = "us-east-1"


def iter_scan(table, page_limit: int | None = None, projection_expression: Optional[str] = None) -> Iterable[Dict[str, Any]]:
    exclusive_start_key = None
    pages = 0

    while True:
        scan_kwargs: Dict[str, Any] = {}
        if exclusive_start_key is not None:
            scan_kwargs["ExclusiveStartKey"] = exclusive_start_key
        if projection_expression:
            scan_kwargs["ProjectionExpression"] = projection_expression

        resp = table.scan(**scan_kwargs)
        for item in resp.get("Items", []):
            yield item

        exclusive_start_key = resp.get("LastEvaluatedKey")
        pages += 1
        if page_limit is not None and pages >= page_limit:
            break
        if not exclusive_start_key:
            break


def _parse_json_list(raw: Any) -> List[Dict[str, Any]]:
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str):
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                return data
        except Exception:
            return []
    return []


def parse_validation_results(raw: Any) -> List[Dict[str, Any]]:
    return _parse_json_list(raw)


def _build_control_name_set(control_arg: str) -> set[str]:
    s = {control_arg}
    raw = control_arg.strip()
    if not raw:
        return s
    if raw.startswith("SSDF") and not raw.startswith("CDR-"):
        s.add(f"CDR-{raw}")
    # digits with dots -> SSDF number
    if raw[0].isdigit() and all(ch.isdigit() or ch == '.' for ch in raw):
        ssdf = f"SSDF{raw}"
        s.add(ssdf)
        s.add(f"CDR-{ssdf}")
    return s


def pick_latest_pass_status(results: List[Dict[str, Any]], control_names: set[str]) -> Tuple[Optional[bool], Optional[Dict[str, Any]]]:
    latest_entry: Optional[Dict[str, Any]] = None
    for entry in results:
        if not isinstance(entry, dict):
            continue
        control = entry.get("control")
        if control in control_names:
            latest_entry = entry
    if latest_entry is None:
        return None, None
    passed = latest_entry.get("passed")
    if isinstance(passed, bool):
        return passed, latest_entry
    vals = latest_entry.get("validations")
    if isinstance(vals, list) and vals:
        statuses = [v.get("status") for v in vals if isinstance(v, dict)]
        if any(s == "FAIL" for s in statuses):
            return False, latest_entry
        if any(s == "PASS" for s in statuses):
            return True, latest_entry
    return None, latest_entry


def collect_identifier(item: Dict[str, Any]) -> Optional[str]:
    ident = item.get("identifier")
    if isinstance(ident, str):
        return ident
    if ident is None:
        return None
    return str(ident)


def main(argv: List[str]) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--table", default=TABLE_NAME)
    parser.add_argument("--region", default=DEFAULT_REGION)
    parser.add_argument("--profile", default=None)
    parser.add_argument("--output-csv", default=None)
    parser.add_argument("--page-limit", type=int, default=None)
    parser.add_argument("--show-details", action="store_true")
    parser.add_argument("--control", default=CONTROL_NAME)

    args = parser.parse_args(argv)

    session_kwargs: Dict[str, Any] = {}
    if args.profile:
        session_kwargs["profile_name"] = args.profile
    session = boto3.Session(**session_kwargs)

    config = Config(retries={"max_attempts": 10, "mode": "adaptive"})
    resource = session.resource("dynamodb", region_name=args.region, config=config)
    table = resource.Table(args.table)

    projection = "identifier, validation_results, last_processed, updated_at"
    control_names = _build_control_name_set(args.control)

    found = 0
    passed_count = 0
    failed_count = 0
    not_prescribed_count = 0

    rows: List[Tuple[str, Optional[bool], Optional[str], Optional[int]]] = []

    for item in iter_scan(table, page_limit=args.page_limit, projection_expression=projection):
        ident = collect_identifier(item)
        results = parse_validation_results(item.get("validation_results"))
        passed, entry = pick_latest_pass_status(results, control_names)
        last_processed = item.get("last_processed") if isinstance(item.get("last_processed"), str) else None
        updated_at = item.get("updated_at")
        if isinstance(updated_at, (int, float)):
            updated_at_val = int(updated_at)
        else:
            try:
                from decimal import Decimal
                if isinstance(updated_at, Decimal):
                    updated_at_val = int(updated_at)
                else:
                    updated_at_val = None
            except Exception:
                updated_at_val = None

        if entry is not None:
            found += 1
            if passed is True:
                passed_count += 1
            elif passed is False:
                failed_count += 1
            else:
                not_prescribed_count += 1
        else:
            not_prescribed_count += 1

        rows.append((ident or "", passed, last_processed, updated_at_val))

    # Prepare CSV output path
    output_csv = args.output_csv
    if not output_csv:
        base_dir = os.path.dirname(os.path.dirname(__file__))
        out_dir = os.path.join(base_dir, "reports")
        os.makedirs(out_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        output_csv = os.path.join(out_dir, f"ssdf249_pass_fail_{ts}.csv")

    # Write CSV
    with open(output_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["identifier", "passed", "last_processed", "updated_at_epoch"])
        for ident, passed, last_processed, updated_at in rows:
            writer.writerow([ident, {True: "true", False: "false"}.get(passed, "not_prescribed"), last_processed or "", updated_at or ""])

    # Console summary
    print("Control:", args.control)
    print(f"Found entries: {found}")
    print(f"Passed: {passed_count}")
    print(f"Failed: {failed_count}")
    print(f"Not prescribed: {not_prescribed_count}")
    print(f"Wrote CSV: {output_csv}")

    if args.show_details:
        print("\nDetails:")
        for ident, passed, last_processed, updated_at in rows:
            status = {True: "PASS", False: "FAIL"}.get(passed, "NOT PRESCRIBED")
            print(f"{ident}: {status} (last_processed={last_processed or ''}, updated_at={updated_at or ''})")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
