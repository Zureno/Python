import sys
import os
import unittest

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.shared.ssm import get_ssm_parameter

class TestInitConfigSSM(unittest.TestCase):
    def test_get_ssm_parameter(self):
        # Check that get_ssm_parameter was called with the expected paths
        mock_table_name = get_ssm_parameter('/eqa/udcrm-control-automation/config/dynamodb-table-name')
        mock_sns_message = get_ssm_parameter('/eqa/udcrm-control-automation/config/servicenow-sns-topic-arn')

        # Assertions
        self.assertEqual(mock_table_name, "eqa-processing-table", "The function should return the specific value.")
 
if __name__ == '__main__':
    unittest.main()