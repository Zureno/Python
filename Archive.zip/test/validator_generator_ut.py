import sys
import os
import json
import unittest

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.shared.validator_generator import ValidatorGenerator
from validation.validator.findings_validator import FindingsValidator
from validation.validator.sbom_validator import SbomValidator
from validation.validator.source_validator import SourceValidator
from validation.validator.salt_validator import SaltValidator
from validation.validator.pipeline_validator import PipelineValidator
from validation.validator.wiz_validator import WizValidator

class TestValidatorGenerator(unittest.TestCase):
    def test_validator_generator(self):
        with open(os.path.join(os.path.dirname(__file__), 'mock_data.json')) as f:
            controls = json.load(f)['mock_get_enabled_controls']

        expected_types = [
           FindingsValidator.__name__,
           SbomValidator.__name__,
           SourceValidator.__name__,
           SaltValidator.__name__,
           PipelineValidator.__name__,
           WizValidator.__name__
        ]

        validator_generator = ValidatorGenerator()
        validators = json.loads(controls[0]["validators"]["S"])
        validator = validators[0]
        validator_type = validator["type"]
        result = validator_generator.get_validator(validator_type)

        # Assertions
        self.assertIsNotNone(result, f"get_validator() returned None for vtype {validator_type}") # Ensure that validator object in the result is not returning as NoneType
        if result is not None:
            self.assertIn(type(result).__name__, expected_types, f"Unexpected validator type: {type(result).__name__}") # Ensure the validator returned contains at least one of the expected types
        
if __name__ == '__main__':
    unittest.main()