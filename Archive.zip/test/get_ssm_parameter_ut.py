import sys
import os
import unittest

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.shared.ssm import get_ssm_parameter

class TestInitConfigSSM(unittest.TestCase):
    def test_get_ssm_parameter(self):
        # Mock variable (env) from athena_integration.py
        mock_env = get_ssm_parameter('/eqa/udcrm-control-automation/config/env')
        # Mock variable (TABLE_NAME) from main.py
        mock_table_name = get_ssm_parameter('/eqa/udcrm-control-automation/config/dynamodb-table-name')

        # Assertions
        self.assertEqual(mock_env, "dev", "The function should return the specific value.")
        self.assertEqual(mock_table_name, "eqa-processing-table", "The function should return the specific value.")
 
if __name__ == '__main__':
    unittest.main()