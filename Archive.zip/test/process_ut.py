import sys
import os
import unittest
import json

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.shared.process import process_validation

class TestProcessValidation(unittest.TestCase):
    def test_process_validation(self):
        with open(os.path.join(os.path.dirname(__file__), 'mock_data.json')) as f:
            control = json.load(f)['mock_get_enabled_control_source']
        result = process_validation("CWU", True, True, control)
        
        # Assertions
        self.assertIsInstance(result, list, "The function should return a list.")
        self.assertGreater(len(result), 0, "The function should return at least one control status.")
        self.assertIn('control', result[0], "Each item in the result should contain a 'control' key.")
        self.assertIn('passed', result[0], "Each item in the result should contain a 'passed' key.")
        self.assertIsInstance(result[0]['evidence'], str, "Evidence should be a string.")

if __name__ == '__main__':
    unittest.main()