import sys
import os
import unittest

os.environ['AWS_DEFAULT_REGION']="us-east-1"
os.environ['AWS_REGION']="us-east-1"

# Append project root directories
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.shared.process import process_validation
from mock_data import mock_get_enabled_control, mock_get_enabled_control_sbom, mock_get_enabled_control_pipeline_github, mock_get_enabled_control_pipeline_harness, mock_get_enabled_control_source, mock_get_enabled_control_findings_dast

class TestProcessValidation(unittest.TestCase):
    def test_process_validation(self):
        results = []
        
        # Sast Validator
        control = mock_get_enabled_control() # Get mock controls data
        result = process_validation("CWU", True, True, control)
        
        self.assertIsInstance(result, list, "The function should return a list.")
        self.assertGreater(len(result), 0, "The function should return at least one control status.")
        self.assertIn('control', result[0], "Each item in the result should contain a 'control' key.")
        self.assertIn('passed', result[0], "Each item in the result should contain a 'passed' key.")
        # self.assertIn('True', result[0]["passed"], "The control should pass")
        self.assertIsInstance(result[0]['evidence'], str, "Evidence should be a string.")
        
        # Github Actions validator
        control = mock_get_enabled_control_pipeline_github() # Get mock controls data
        result = process_validation("ELT", True, True, control)

        self.assertIsInstance(result, list, "The function should return a list.")
        self.assertGreater(len(result), 0, "The function should return at least one control status.")
        self.assertIn('control', result[0], "Each item in the result should contain a 'control' key.")
        self.assertIn('passed', result[0], "Each item in the result should contain a 'passed' key.")
        # self.assertIn('True', result[0]["passed"], "The control should pass")
        self.assertIsInstance(result[0]['evidence'], str, "Evidence should be a string.")
        
        # Harness Validator
        control = mock_get_enabled_control_pipeline_harness() # Get mock controls data
        result = process_validation("CWU", True, True, control)
        
        self.assertIsInstance(result, list, "The function should return a list.")
        self.assertGreater(len(result), 0, "The function should return at least one control status.")
        self.assertIn('control', result[0], "Each item in the result should contain a 'control' key.")
        self.assertIn('passed', result[0], "Each item in the result should contain a 'passed' key.")
        # self.assertIn('True', result[0]["passed"], "The control should pass")
        self.assertIsInstance(result[0]['evidence'], str, "Evidence should be a string.")
        
        # Source validator
        control = mock_get_enabled_control_source() # Get mock controls data
        result = process_validation("CWU", True, True, control)
        
        self.assertIsInstance(result, list, "The function should return a list.")
        self.assertGreater(len(result), 0, "The function should return at least one control status.")
        self.assertIn('control', result[0], "Each item in the result should contain a 'control' key.")
        self.assertIn('passed', result[0], "Each item in the result should contain a 'passed' key.")
        # self.assertIn('True', result[0]["passed"], "The control should pass")
        self.assertIsInstance(result[0]['evidence'], str, "Evidence should be a string.")
        
        
        # Dast validator
        control = mock_get_enabled_control_findings_dast() # Get mock controls data
        result = process_validation("CWU", True, True, control)
        
        self.assertIsInstance(result, list, "The function should return a list.")
        self.assertGreater(len(result), 0, "The function should return at least one control status.")
        self.assertIn('control', result[0], "Each item in the result should contain a 'control' key.")
        self.assertIn('passed', result[0], "Each item in the result should contain a 'passed' key.")
        # self.assertIn('True', result[0]["passed"], "The control should pass")
        self.assertIsInstance(result[0]['evidence'], str, "Evidence should be a string.")
        
        # SBOM validator
        control = mock_get_enabled_control_sbom() # Get mock controls data
        result = process_validation("DMZ", True, True, control)
        
        self.assertIsInstance(result, list, "The function should return a list.")
        self.assertGreater(len(result), 0, "The function should return at least one control status.")
        self.assertIn('control', result[0], "Each item in the result should contain a 'control' key.")
        self.assertIn('passed', result[0], "Each item in the result should contain a 'passed' key.")
        # self.assertIn('True', result[0]["passed"], "The control should pass")
        self.assertIsInstance(result[0]['evidence'], str, "Evidence should be a string.")

if __name__ == '__main__':
    unittest.main()