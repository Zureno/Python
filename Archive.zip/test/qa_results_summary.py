import json
import sys
import re
import boto3
from botocore.exceptions import ClientError
 
results_prefix = "results"
 
s3 = boto3.client("s3")
 
summary_stats = {
    "total_controls": 0,
    "total_appcis": 0,
    "total_passes": 0,
    "total_failures": 0,
    "total_errors": 0
}

def extract_control_from_branch(branch_name):
    # Extract control from branch name
    split_branch_name = branch_name.split("-")
    control_number = split_branch_name[3].replace('.', '-')
    control_name ="CDR-"+ split_branch_name[2] + control_number
    return control_name
 
def process_control_results(control_prefix):
    summary_stats = {
        "total_controls": 1,
        "total_appcis": 0,
        "total_passes": 0,
        "total_failures": 0
    }
 
    try:
        response = s3.list_objects_v2(Bucket="eqa-udcrm-qa-bucket-dev", Prefix=control_prefix)
        if "Contents" not in response:
            return
 
        for obj in response["Contents"]:
            key = obj["Key"]
            if not key.endswith(".json"):
                continue
            
            result_obj = s3.get_object(Bucket="eqa-udcrm-qa-bucket-dev", Key=key)
            result_data = json.loads(result_obj["Body"].read().decode("utf-8"))
 
            for entry in result_data:
                result = entry.get("results", [])
                summary_stats["total_appcis"] += 1
 
                if isinstance(result, dict) and "error" in result:
                    summary_stats["total_errors"] += 1
                else:
                    passed = result[0].get("passed") if result else None
                    if passed is True:
                        summary_stats["total_passes"] += 1
                    else:
                        summary_stats["total_failures"] += 1
 
    except ClientError as e:
        print(f"Error: {e}")
        summary_stats["total_errors"] = 1

    return summary_stats
 
def main():
    summary_stats = {}

    try:
        if len(sys.argv) < 2:
            print("Usage: python qa_results_summary.py <branch_name> <appci>")
            sys.exit(1)
    
        branch_name = sys.argv[1]
        safe_control_name = extract_control_from_branch(branch_name)
        control_prefix = f"{results_prefix}/{safe_control_name}/"
    
        summary_stats = process_control_results(control_prefix)
    
        passed_appcis = summary_stats["total_passes"]
        failed_appcis = summary_stats["total_failures"]
    
        if passed_appcis > 0 and failed_appcis > 0:
            print("QA RESULTS: PASS. There is at least one passed and one failed appci.")
            sys.exit(0)
        elif passed_appcis == 0 and failed_appcis > 0:
            print(f"QA RESULTS: MANUAL REVIEW REQUIRED. All appcis have failed.")
            print(f"Review results in s3://eqa-udcrm-qa-bucket-dev/{results_prefix}/{safe_control_name}, and manually validate that this control can be passed.")
            sys.exit(1)
        elif failed_appcis == 0 and passed_appcis > 0:
            print(f"QA RESULTS: MANUAL REVIEW REQUIRED. All appcis have passed.")
            print(f"Review results in s3://eqa-udcrm-qa-bucket-dev/{results_prefix}/{safe_control_name}, and manually validate that this control can be failed.")
            sys.exit(1)
        else:
            print("QA RESULTS: No valid results found (all failed to load or were missing).")
            sys.exit(1)

    except Exception as e:
        print(f"Error: {e}")
        print("QA RESULTS: No valid results found (all failed to load or were missing).")
        sys.exit(1)
 
if __name__ == "__main__":
    main()