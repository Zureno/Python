import sys
import os
import unittest
from unittest.mock import patch, MagicMock
import json

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.main import send_to_standard_sns

class TestSendToStandardSNS(unittest.TestCase):
 
    @patch('validation.main.boto3.client') #This patch temporarily function fakes/mocks the boto3.client() difined inside the function we are testing
    def test_send_to_standard_sns_success(self, mock_boto_client):
        # Arrange
        mock_sns = MagicMock() #Fakes a SNS client
        mock_boto_client.return_value = mock_sns #
        mock_response = {'MessageId': '12345'} #Fakes message from AWS if the message was sent succesfully
        mock_sns.publish.return_value = mock_response #If .publish() is called return the mock response
 
        topic_arn = 'arn:aws:sns:us-east-1:123456789012:MyTopic'
        message = {'event': 'user_signup'}
 
        # Act
        send_to_standard_sns(topic_arn, message)

        mock_sns.publish.assert_called_once_with(
            TopicArn=topic_arn,
            Message=json.dumps(message)
        )

if __name__ == '__main__':
    unittest.main()