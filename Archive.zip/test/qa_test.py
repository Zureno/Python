import json
import os
import sys
import boto3
from botocore.config import Config
import re
import time

# Hardcoded data
lambda_name = "eqa-qa-validation-lambda"

def extract_control_from_branch(branch_name):
    # Extract control from branch name
    split_branch_name = branch_name.split("-")
    control_name ="CDR-"+ split_branch_name[2] + split_branch_name[3]
    standard=split_branch_name[2]
    return control_name, standard

def get_qa_control(control):
    # Align control data with dynamodb json format
    return {
        "enabled": {"BOOL": True},
        "control": {"S": control["control"]},
        "definition": {"S": control["definition"]},
        "confidence": {"S": "medium"},
        "description": {"S": control["description"]},
        "validators": {"S": json.dumps(control["validators"])}
    }

def extract_appci_from_branch(branch_name):
    appcis = branch_name.split(",")
    return appcis

def get_accepted_standards():
    # Get safe filenames of all standards in the controls folder so we can validate input
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), f"../src/control/cdr"))
    valid_standards = set()

    for filename in os.listdir(base_dir):
        if filename.endswith(".json"):
            # Extract standard from filename
            name = os.path.splitext(filename)[0]
            valid_standards.add(name)
    
    return list(valid_standards)

def main():
    all_results = []
    passed_appcis = 0
    failed_appcis = 0
    max_retries = 3
    passing_appcis = []
    failing_appcis = []
    accepted_standards = get_accepted_standards()

    # If no branch name provided, exit with error
    if len(sys.argv) < 2:
        print("Usage: python qa_test.py <branch_name> <appcis>")
        sys.exit(1)

    # If branch name present, extract control from branch name
    branch_name = sys.argv[1]
    control_name, standard = extract_control_from_branch(branch_name)

    if not control_name:
        print(f"Branch name '{branch_name}' does not contain a control. Skipping validation.")
        sys.exit(0)

    # Check if standard name is an acceptable input
    if not standard or standard not in accepted_standards:
        print(f"No standard found. Skipping validation.")

    # Get control data from controls.json
    controls_path = os.path.abspath(os.path.join(os.path.dirname(__file__), f"../src/control/cdr/{standard}.json"))
    with open(controls_path, 'r', encoding='utf-8') as json_data:
        content = json.load(json_data)
    for control in content:
        if control_name in control["control"]: # Search for the control specified in branch name
            control_details = get_qa_control(control) # Cast the data to the expected DynamoDB format
            break

    if not control_details:
        print(f"Control '{control_name}' not found in {standard}.json. Skipping test and exiting with failure.")
        sys.exit(1)

    # Sanitize control name (e.g. IAM3.1.11->IAM-3-1-11) for upload to S3
    safe_control_name = re.sub(r"\.", "-", control_name)

    # Extract appcis as an array and sanitize their names for name
    appcis = extract_appci_from_branch(sys.argv[2])
    safe_appci_name = re.sub(r"\,", "-", sys.argv[2])

    # Configure lambda client
    lambda_config = Config(
        read_timeout = 300,
        connect_timeout = 10,
        retries = {'max_attempts': 3}
    )
    lambda_client = boto3.client("lambda", config = lambda_config)

    # Invoke the validation lambda for each appci
    for appci in appcis:
        qa_payload = {
            "appci": appci,
            "qa_control": control_details
        }

        # Results to append
        appci_result = None
        
        for attempt in range(max_retries):
            try:
                # Trigger lambda function using QA payload
                response = lambda_client.invoke(
                    FunctionName = lambda_name,
                    InvocationType = "RequestResponse",
                    Payload = json.dumps(qa_payload)
                )

                # Parse response payload
                response_payload = response['Payload'].read().decode('utf-8')
                lambda_result = json.loads(response_payload)

                appci_result = {
                    "appci": appci,
                    "results": lambda_result
                }

                # Check if the appci passed or failed
                passed = lambda_result[0]["passed"]
                if passed is True:
                    passed_appcis += 1
                    passing_appcis.append(appci)
                else:
                    failed_appcis += 1
                    failing_appcis.append(appci)
                break

            except Exception as e:
                print(f"Error invoking lambda for {appci}, attempt {attempt + 1}: {str(e)}")
                if attempt < max_retries - 1:
                    print("Retrying in 2 seconds...")
                    time.sleep(2)
                else:
                    print("Max retries reached. Skipping this appci.")
                    # Avoid adding duplicate error entries
                    existing_appci_errors = [r for r in all_results if r["appci"] == appci and "error" in r["results"]]
                    if not existing_appci_errors:
                        appci_result=({
                            "appci": appci,
                            "results": {
                                "error": f"An error occurred: {str(e)}",
                                "status": "FAILED"
                            }
                        })           
        
        all_results.append(appci_result)
        print("Sleeping 3 seconds before next invocation...")
        time.sleep(3)

        # Local testing for lambda function 
        '''
        src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src"))
        validation_path = os.path.join(src_path, "validation")
        sys.path.append(src_path)
        sys.path.append(validation_path)
        from validation.main import handler

        results = handler(qa_payload, None)
        print(results)

        appci_result = {
            "appci": appci,
            "results": results
        }
        all_results.append(appci_result)
        print(results)

        # Check if the appci passed or failed
        if results[0]["passed"]:
            passed_appcis += 1
        else:
            failed_appcis += 1
        '''

    # Set the S3 path
    s3_results_key = f"results/{safe_control_name}/{safe_appci_name}-results.json"
    
    # Upload the test results to S3
    s3 = boto3.client('s3')
    try:
        s3.put_object(
            Bucket = "eqa-udcrm-qa-bucket-dev",
            Key = s3_results_key,
            Body = json.dumps(all_results),
            ContentType = "application/json"
        )
    except Exception as e:
        print(f"Error uploading results data to eqa-udcrm-qa-bucket-dev: {e}")
    
    # Provide QA test results as message
    # Success (exit code 0) = mix of pass and failed appcis, no need for manual review
    # Failure (exit code 1) = all appcis have passed or failed, manual review required
    if passed_appcis == 0:
        print("\n No appcis are passing")
    else:
        print(f'\n Number of AppCIs passing {passed_appcis}: {passing_appcis}')
    
    if failed_appcis == 0:
        print("\n No appcis are failing")
    else:
        print(f'\n Number of AppCIs failing {failed_appcis}: {failing_appcis} \n')
        
    if passed_appcis > 0 and failed_appcis > 0:
        print("QA RESULTS: PASS. There is at least one passed and one failed appci.")
        sys.exit(0)
    elif passed_appcis == 0:
        print(f"QA RESULTS: MANUAL REVIEW REQUIRED. All appcis have failed. Review results in eqa-udcrm-qa-bucket-dev/{s3_results_key}, and manually validate that this control can be passed.")
        sys.exit(1)
    elif failed_appcis == 0:
        print(f"QA RESULTS: MANUAL REVIEW REQUIRED. All appcis have passed. Review results in eqa-udcrm-qa-bucket-dev/{s3_results_key}, and manually validate that this control can be failed.")
        sys.exit(1)

if __name__ == "__main__":
    main()