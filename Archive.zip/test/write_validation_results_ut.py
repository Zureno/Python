import sys
import os
import json
import unittest

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.main import write_validation_results, init_config

class TestProcessValidation(unittest.TestCase):
    def test_process_validation(self):
        init_config()
        with open(os.path.join(os.path.dirname(__file__), 'mock_data.json')) as f:
            control_status = json.load(f)['mock_control_status']
        results = write_validation_results("DMZ", control_status)

        self.assertIn('Attributes', results, "The results should contain the 'Attributes' key.")
        self.assertIn('validation_results', results['Attributes'], "The 'Attributes' should contain 'validation_results'.")
    
        validation_results = results['Attributes']['validation_results']
        self.assertIsInstance(validation_results, str, "The 'validation_results' should be a string.")
    
        # Decode the string into a list
        validation_data = json.loads(validation_results)
        self.assertIsInstance(validation_data, list, "The 'validation_results' should be a list after decoding.")
    
        # Validate keys within each result
        for item in validation_data:
            self.assertIn('control', item, "Each result should contain the 'control' key.")
            self.assertIn('passed', item, "Each result should contain the 'passed' key.")
            self.assertIn('validations', item, "Each result should contain the 'validations' key.")
        
            # Validate validations structure
            validations = item.get('validations', [])
            self.assertIsInstance(validations, list, "The 'validations' field should be a list.")
            for validation in validations:
                self.assertIn('type', validation, "Each validation should contain the 'type' key.")
                self.assertIn('criteria', validation, "Each validation should contain the 'criteria' key.")
                self.assertIn('tool', validation, "Each validation should contain the 'tool' key.")
                self.assertIn('status', validation, "Each validation should contain the 'status' key.")
        
            # Validate raw_evidence structure
            raw_evidence = item.get('raw_evidence', [])
            self.assertIsInstance(raw_evidence, list, "The 'raw_evidence' field should be a list.")
            for evidence in raw_evidence:
                self.assertIsInstance(evidence, dict, "Each evidence should be a dictionary.")
                self.assertTrue(len(evidence) > 0, "Each evidence dictionary should have data.")
        
            # Validate evidence string
            self.assertIn('evidence', item, "Each result should contain the 'evidence' key.")
            self.assertIsInstance(item['evidence'], str, "The 'evidence' field should be a string.")
        
            # Validate the expected values for specific fields
            self.assertEqual(item['control'], 'OWASP-V5.3.9', "The control should be 'OWASP-V5.3.9'.")
            self.assertEqual(item['confidence'], 'high', "The confidence should be 'high'.")
            self.assertTrue(item['passed'], "The 'passed' field should be True.")
        
if __name__ == '__main__':
    unittest.main()