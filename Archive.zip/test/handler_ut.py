import sys
import os
import unittest
import json

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.main import handler

class TestHandlerSuccess(unittest.TestCase):
    def test_handler(self):
        sample_event = {
            "body": {
                "Records": [
                    {
                        "Sns": {
                            "Message": "{\"appci\":\"BBS\"}",
                            "MessageGroupId": "\"mid_12345\""
                        }
                    }
                ]
            }
            }
        result = handler(sample_event, {})
 
        # Then: response is correct

        self.assertIsNotNone(result["status"], "All validators found. Sent to service_now SNS.")

if __name__ == '__main__':
    unittest.main()