import sys
import os
import unittest
import json

os.environ['AWS_DEFAULT_REGION'] = "us-east-1"
os.environ['AWS_REGION'] = "us-east-1"

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'validation')))

from validation.shared.controls import Control as Controlclass

class TestGetValidationTypes(unittest.TestCase):
    def test_get_validation_types(self):
        with open(os.path.join(os.path.dirname(__file__), 'mock_data.json')) as f:
            controls = json.load(f)['mock_get_enabled_controls']
        result = Controlclass.get_all_validation_types(self, controls)

        # Assertions
        self.assertGreater(len(result), 0, f"get_all_validation_types() returned an empty list unexpectedly") # Ensure we get at least one validation type in the result
        self.assertIsNotNone(result, f"get_all_validation_types() returned None") # Ensure that validation type in the result is not returning as NoneType
        if result is not None and len(result) > 0:
            self.assertEqual(len(result), len(set(result)), f"get_all_validation_types() returned duplicate values") # Ensure result doesn't include duplicate validation types            
            for validation_type in result:
                self.assertIn(validation_type, ["findings", "salt", "sbom", "source", "pipeline", "wiz", "onboarded"], f"Unexpected validator type: {str(validation_type)}") # Ensure the validation type matches one of the expected values
        
        self.assertEqual(Controlclass.get_all_validation_types(self, []), [], f"get_all_validation_types() returned unexpected output for empty input") # Ensure if no controls passed, function returns empty list
        
if __name__ == '__main__':
    unittest.main()