import sys
import os
import boto3
import pytest
from src.validation.shared.athena_integration import AthenaIntegration
from unittest.mock import patch, MagicMock


@pytest.fixture
def mock_boto3_client():
    with patch('boto3.client') as mock_client:
        yield mock_client.return_value


@pytest.fixture
def athena_instance():
    return AthenaIntegration()


def test_execute_athena_query_success(mock_boto3_client, athena_instance):
    # Mock the responses
    mock_boto3_client.start_query_execution.return_value = {'QueryExecutionId': 'test_id'}
    mock_boto3_client.get_query_execution.return_value = {'QueryExecution': {'Status': {'State': 'SUCCEEDED'}}}
    mock_boto3_client.get_query_results.return_value = {
        'ResultSet': {
            'ResultSetMetadata': {'ColumnInfo': [{'Name': 'col1'}, {'Name': 'col2'}]},
            'Rows': [
                {'Data': [{'VarCharValue': 'col1'}, {'VarCharValue': 'col2'}]},  # Header row
                {'Data': [{'VarCharValue': 'value1'}, {'VarCharValue': 'value2'}]}
            ]
        }
    }

    # Construct a query using the new method
    query = AthenaIntegration.construct_secure_query(
        'test_table',
        columns=['col1', 'col2'],
        where_clauses=[{'column': 'col1', 'operator': '=', 'value': 'test'}],
        limit=10
    )

    # Call the function
    result = athena_instance.execute_athena_query('test_db', query)

    # Assert the results
    assert result == [{'col1': 'value1', 'col2': 'value2'}]
    mock_boto3_client.start_query_execution.assert_called_once()
    mock_boto3_client.get_query_execution.assert_called()
    mock_boto3_client.get_query_results.assert_called_once()


def test_execute_athena_query_failure(mock_boto3_client, athena_instance):
    # Mock a failed query execution
    mock_boto3_client.start_query_execution.return_value = {'QueryExecutionId': 'test_id'}
    mock_boto3_client.get_query_execution.return_value = {
        'QueryExecution': {
            'Status': {
                'State': 'FAILED'
            }
        }
    }

    # Construct a query
    query = AthenaIntegration.construct_secure_query('test_table', columns=['col1'])

    # Call the function and assert it raises an exception
    with pytest.raises(Exception) as exec_info:
        athena_instance.execute_athena_query('test_db', query)
    error_message = str(exec_info.value)
    assert 'Query failed with state: FAILED' in error_message


def test_construct_secure_query():
    test_table = 'test_table'
    columns = ["col1", "col2", "updated on"]
    where_clauses = [
        {'column': 'col1', 'operator': '=', 'value': 'test'},
        {'column': 'col2', 'operator': 'in', 'value': ['value1', 'value2']},
        {'column': 'updated on', 'operator': '>=', 'value': '2023-01-01'}
    ]
    order_by_clauses = [{'column': 'updated on', 'ascending': False}]
    limit = 10

    query = AthenaIntegration.construct_secure_query(test_table, columns, where_clauses, order_by_clauses, limit)

    # Assert query structure
    assert 'SELECT' in query
    assert 'FROM test_table' in query
    assert "WHERE" in query
    assert "test_table.col1 = 'test'" in query
    assert "test_table.col2 IN ('value1', 'value2')" in query
    assert "test_table.\"updated on\" >= '2023-01-01'" in query
    assert 'ORDER BY test_table."updated on" DESC' in query
    assert 'LIMIT 10' in query


def test_execute_athena_query_constructs_query_correctly(mock_boto3_client, athena_instance):
    # Mock the responses
    mock_boto3_client.start_query_execution.return_value = {'QueryExecutionId': 'test_id'}
    mock_boto3_client.get_query_execution.return_value = {'QueryExecution': {'Status': {'State': 'SUCCEEDED'}}}
    mock_boto3_client.get_query_results.return_value = {
        'ResultSet': {
            'ResultSetMetadata': {'ColumnInfo': []}, 'Rows': []
        }
    }

    # Construct a query
    query = AthenaIntegration.construct_secure_query(
        'test_table',
        columns=['col1', 'col2'],
        where_clauses=[{'column': 'col1', 'operator': '=', 'value': 'test'}],
        limit=10
    )

    # Call the function
    athena_instance.execute_athena_query('test_db', query)

    # Assert the query execution
    mock_boto3_client.start_query_execution.assert_called_once()
    call_args = mock_boto3_client.start_query_execution.call_args[1]
    assert 'QueryString' in call_args
    assert 'SELECT' in call_args['QueryString']
    assert 'FROM test_table' in call_args['QueryString']
    assert "WHERE test_table.col1 = 'test'" in call_args['QueryString']
    assert 'LIMIT 10' in call_args['QueryString']
    assert call_args['QueryExecutionContext'] == {'Database': 'test_db'}
    assert 'ResultConfiguration' in call_args
    assert 'OutputLocation' in call_args['ResultConfiguration']
    assert isinstance(call_args['ResultConfiguration']['OutputLocation'], str)
    assert call_args['ResultConfiguration']['OutputLocation'].startswith('s3://')