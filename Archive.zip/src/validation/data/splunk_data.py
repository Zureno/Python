from shared.athena_integration import AthenaIntegration
from datetime import datetime, timedelta
import logging
import os
import boto3
from .logger import logger


class SplunkData(AthenaIntegration):

    def __init__(self):
        self.database = super()
        self.athena_client = boto3.client('athena')

    def get_splunk_status(self, hostname):
        query_results = []
        hostname = hostname.lower() # set hostname to lowercase for querying

        try:
            if hostname is None:
                raise Exception('Parameter hostname is mandatory')
            
            safe_database = self.database.sanitize_identifier("appsec_database_for_datalake_shared_resources")
            safe_table_name = self.database.sanitize_identifier("armis_device_data_shared")
            one_year_ago = datetime.now() - timedelta(days=365)
            one_year_ago_str = one_year_ago.strftime('%Y-%m-%d')

            #In the future, pull additional data columns here
            columns = ["name", "customproperties", "partition_0"]
            where_clauses = [
                {'column': 'name', 'operator': 'LIKE', 'value': f'{hostname}%'},
                {'column': 'customproperties', 'operator': 'REGEXP', 'value': f"'SPLUNK_ACCEPTABLE_VERSION_GAUGE':"},
                {'column': 'partition_0', 'operator': '>=', 'value': one_year_ago_str}
            ]
            order_by_clauses = [
                {'column': 'partition_0', 'ascending': False}
            ]

            sql_query = self.database.construct_secure_query(safe_table_name,
                                                    columns,
                                                    where_clauses,
                                                    order_by_clauses , limit=1)

            query_results = self.database.execute_athena_query(safe_database, sql_query)
            return query_results

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get findings for hostname: {hostname}. Error={error}")
        