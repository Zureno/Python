from shared.athena_integration import AthenaIntegration
from datetime import datetime, timedelta
import logging
import os
import boto3
from .logger import logger


class WizData(AthenaIntegration):

    def __init__(self):
        self.database = super()
        self.athena_client = boto3.client('athena')

    def get_wiz_findings(self, appci):
        try:
            if appci is None:
                raise Exception('Parameter appci is mandatory')
            
            safe_database = self.database.sanitize_identifier("appsec_database_for_datalake_shared_resources")
            safe_table_name = self.database.sanitize_identifier("wiz_issues_current_state")
            one_year_ago = datetime.now() - timedelta(days=365)
            one_year_ago_str = one_year_ago.strftime('%Y-%m-%d %H:%M:%S')

            #In the future, pull additional data columns here
            columns = ["appci", "status", "updated_at", "title"]
            
            where_clauses = [
                {'column': 'appci', 'operator': '=', 'value': appci},
                {'column': 'status', 'operator': '=', 'value': 'OPEN'},
                {'column': 'updated_at', 'operator': '>=', 'value': one_year_ago_str}\
            ]

            order_by_clauses = [
                {'column': 'updated_at', 'ascending': False}
            ]

            sql_query = self.database.construct_secure_query(safe_table_name,
                                                    columns,
                                                    where_clauses,
                                                    order_by_clauses)
            
            query_results = self.database.execute_athena_query(safe_database, sql_query)
            return query_results

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get findings for appci: {appci}. Error={error}")