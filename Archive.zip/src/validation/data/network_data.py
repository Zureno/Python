import os, sys
# ssys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),'..', '..', 'validation')))
from integrations.asvs.skynet import NetworkIntegration
import json
from .logger import logger

class NetworkData(NetworkIntegration):

    def __init__(self):
        self.network_api = NetworkIntegration()
    
    def merge_json_dicts(self, dict1, dict2):
        nc1 = dict1.get("Non_Compliant_json")
        nc2 = dict2.get("Non_Compliant_json")

        if nc2 == []:
                merged_nc = nc1
        else:
                merged_nc = nc1 + nc2

        return {
            "Failure_Message": f'{dict1["Failure_Message"]}; {dict2["Failure_Message"]}',
            "Non_Compliant_json": merged_nc
        }

    #Given a policy ID, perform 3 API calls to extract data
    def get_network_compliance(self, controls):
            results = ""
            current_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'shared', 'CDR-to-NSSpolicy.json'))
            with open(current_dir, 'r') as file:
                policy_json = json.load(file)

            #get controls with type network
            policy_list = self.network_api.get_policies(policy_json, controls)

            for policy in policy_list:
                    executionID = self.network_api.kickoff(policy)
                    if executionID == None:
                            logger.warning(f"No execution ID received for policy {policy}")
                            continue
                    else:
                            network_compliance = self.network_api.monitor_and_extract(executionID)
                            network_compliance["Non_Compliant_json"] = json.loads(network_compliance.get("Non_Compliant_json"))
                            logger.info(f"Non-compliant items: {len(network_compliance.get('Non_Compliant_json'))}")
                            if results:
                                    results = self.merge_json_dicts(results, network_compliance)
                                    logger.info(f"Total non-compliant items after merge: {len(results.get('Non_Compliant_json'))}")
                            else: 
                                    results = network_compliance
                                    
            return results