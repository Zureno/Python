from shared.athena_integration import AthenaIntegration
from shared.config import CONFIG
from integrations.legacy.veracode import LegacyVeracodeIntegration
from datetime import datetime, timezone, timedelta
import time
import os
from datetime import datetime, timedelta
import boto3
from .logger import logger


def get_ual_env():
    return os.getenv("UAL_ENV", "").lower()

ual_env = None if CONFIG.get("ENV", "").lower() == "local" else get_ual_env()

class FindingsData(AthenaIntegration):

    def __init__(self):
        self.database = super()
        self.athena_client = boto3.client('athena')
        self.veracode = LegacyVeracodeIntegration()

    def get_scan_compliance(self, appci, sast_enabled, dast_enabled):
        try:
            if appci is None or sast_enabled is None or dast_enabled is None:
                raise Exception('Parameters appci, sast and dast are mandatory')

            safe_database = self.sanitize_identifier("appsec_database_for_datalake_shared_resources")

            # Default to None so we can cover not applicable
            sast_compliant = None
            dast_compliant = None
            dast_query_results = None
            sast_query_results = None
            dast_query_execution_id = None
            sast_query_execution_id = None
            sast_metadata = []
            dast_metadata = []
            sast_invaracode = None
            dast_isonboarded = None
            
            if sast_enabled:
                safe_table_name = self.sanitize_identifier("veracode_sast_scan_profile_all_shared")
                columns = ["appci", "profile_name", "compliant_scan", "last_scan_date", "in_veracode", "operational_status", "last_scan_age"]
                # Athena SQL supports date functions like current_date and date_add
                # To get yesterday's date: date_add('day', -1, current_date)
                where_clauses = [
                    {'column': 'appci', 'operator': '=', 'value': appci},
                    {'column': 'operational_status', 'operator': '=', 'value': 'Production'},
                    {'column': 'last_scan_date', 'operator': '<>', 'value': 'NA'},
                    {'custom': "(compliant_scan = 'Yes' OR compliant_scan = 'Scan present') AND (in_veracode = 'onBoarded' OR in_veracode = 'Onboarded')"}
                ]

                order_by_clauses = [
                    {'column': 'last_scan_date', 'ascending': False}
                ]

                sast_sql_query = self.construct_secure_query(
                    safe_table_name,
                    columns,
                    where_clauses,
                    order_by_clauses, 
                    limit=1
                )
                # Use Lake Formation workgroup for shared resource links
                sast_query_execution_id = self.execute_athena_query(safe_database, sast_sql_query, False, workgroup='primary')
                logger.info("Athena sast query was executed successfully")

            if dast_enabled:
                safe_table_name = self.database.sanitize_identifier("netsparker_scan_profile_shared")
                columns = ["appci", "last_scan_date", "has_compliant_scan", "operational_status","is_onboarded"]
                where_clauses = [
                    {'column': 'appci', 'operator': '=', 'value': appci},
                    {'column': 'operational_status', 'operator': '=', 'value': 'Production'},
                    {'column': 'has_compliant_scan', 'operator': '=', 'value': 'true'},
                    {'column': 'is_onboarded', 'operator': '=', 'value': 'true'}
                ]

                order_by_clauses = [
                    {'column': 'last_scan_date', 'ascending': False}
                ]

                dast_sql_query = self.construct_secure_query(
                    safe_table_name,
                    columns,
                    where_clauses,
                    order_by_clauses,
                    limit=1
                )
                # Use Lake Formation workgroup for shared resource links
                dast_query_execution_id = self.execute_athena_query(safe_database, dast_sql_query, False, workgroup='primary')
                logger.info("Athena dast query was executed successfully")

            if sast_enabled or dast_enabled:
                time.sleep(30)

            if not sast_query_execution_id and not dast_query_execution_id:
                return sast_compliant, dast_compliant, sast_metadata, dast_metadata

            # all profiles in sast must be compliant for the app ci to be compliant
            if sast_query_execution_id:
                self.wait_for_query_to_finish(sast_query_execution_id)
                sast_query_results = self.get_query_results(sast_query_execution_id)
                if len(sast_query_results) > 0:
                    for record in sast_query_results:
                        try:
                            last_scan_age_check = int(record['last_scan_age'])
                        except ValueError:
                                logger.warning(f"Invalid format for last_scan_age")
                                sast_compliant = None

                        if ((str(record['compliant_scan']).lower() == "scan present" or 
                            str(record['compliant_scan']).lower() == "yes") and 
                            str(record['in_veracode']).lower() == "onboarded" and
                            int(record['last_scan_age']) <= 365):
                            sast_compliant = True
                        else:
                            sast_compliant = False
                            if record not in sast_metadata:
                                sast_metadata.append(record)

                else:
                    sast_compliant = False
            logger.info("Sast compliance evaluation is done")
            
            # get recent scan date and then check all profiles with that date
            if dast_query_execution_id:
                self.wait_for_query_to_finish(dast_query_execution_id)
                dast_query_results = self.get_query_results(dast_query_execution_id)

                if len(dast_query_results) > 0:
                    latest_date = dast_query_results[0]['last_scan_date']
                    for record in dast_query_results:
                        if record['last_scan_date'] == latest_date and dast_compliant is not False:
                            if str(record['has_compliant_scan']).lower() == "true":
                                dast_compliant = True 
                            else:
                                dast_compliant = False
                                if record not in dast_metadata:
                                    dast_metadata.append(record)
                        # all profiles must be onboarded for the app ci to be onboarded
                        if (str(record['is_onboarded']).lower() == "onboarded"):
                            if dast_isonboarded is not False:
                                    dast_isonboarded = True
                        else:
                            dast_isonboarded = False
                        if dast_compliant is not False and (CONFIG.get("ENV", "").lower() != "local" or ual_env != "dev"):
                            last_scan_str = record['last_scan_date']
                            try:
                                last_scan_date = datetime.strptime(last_scan_str, "%Y-%m-%d").date()
                                # Calculate the cutoff date (90 days ago)
                                cutoff_date = datetime.today().date() - timedelta(days=90)
                                if last_scan_date >= cutoff_date:
                                    dast_compliant = True
                                else:
                                    dast_compliant = False
                            except ValueError:
                                logger.warning(f"Invalid date format for last_scan_age: {last_scan_str}")
                                dast_compliant = False
                else:
                    dast_compliant = False
            logger.info("Dast compliance evaluation is done")
            logger.info(f'Appci: {appci} has sast_compliant = {sast_compliant} and dast_compliant = {dast_compliant}')

            return sast_compliant, dast_compliant, sast_metadata, dast_metadata, sast_invaracode, dast_isonboarded

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get findings for appci: {appci}. Error={error}")

    def get_scan_compliance_by_api(self, appci, sast_enabled, dast_enabled):
        sast_compliant = None
        dast_compliant = None
        sast_metadata = []
        dast_metadata = []
        
        if sast_enabled:
            response = self.veracode.get_profiles_by_appci(appci, self.veracode.vid, self.veracode.vkey)
            if isinstance(response, dict) and response.get("error"):
                logger.error(f"Can't fetch profiles: {response['details']}")
                return False
            sast_metadata = response['_embedded']['applications']
            
            one_year_ago_str = datetime.now(timezone.utc) - timedelta(days=365)
            
            sast_compliant = True
 
            for application in sast_metadata:
                raw = application.get('last_completed_scan_date')
    
                # No date at all → non-compliant
                if not raw:
                    sast_compliant = False
                    application['compliance_reason'] = 'No completed scan date'
                    break
    
                # Parse safely
                try:
                    datetime.strptime(raw, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)
                    if scan_dt.tzinfo is None:
                        # Treat naive as UTC
                        scan_dt = scan_dt.replace(tzinfo=timezone.utc)
                except Exception as e:
                    sast_compliant = False
                    application['compliance_reason'] = f'Invalid date format: {raw} ({e})'
                    break
    
                # Older than 1 year → non-compliant
                if scan_dt < one_year_ago_str:
                    sast_compliant = False
                    application['compliance_reason'] = f'Last scan {scan_dt.isoformat()} is >1y old'
                    break
                
        if dast_enabled:
            dast_compliant = False
            dast_metadata = []
        
        return sast_compliant, dast_compliant, sast_metadata, dast_metadata


    def get_datalake_findings(self, appci, scan):
        try:
            if appci is None:
                raise Exception('Parameters appci are mandatory')
            
            # Yesterday's date for partition filter
            yesterday_ymd = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            
            safe_database = self.sanitize_identifier("appsec_database_for_datalake_shared_resources")
            safe_table_name = self.sanitize_identifier("vipr_findings_shared")
            tools = []

            if scan == "sast":
                tools.append("Veracode")
                one_year_ago = datetime.now() - timedelta(days=365)
                date = one_year_ago.strftime('%Y-%m-%d %H:%M:%S')

            if scan == "dast":
                tools.append("Netsparker")
                tools.append("Invicti")
                three_months_ago = datetime.now() - timedelta(days=90)
                date = three_months_ago.strftime('%Y-%m-%d %H:%M:%S')

            columns = [
                "Appci",
                "remediation_description",
                "source",
                "closed_timestamp",
                "cwes",
                "severity",
                "scan_type",
                "display_name"
            ]

            now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            where_clauses = [
                {'column': 'Appci', 'operator': '=', 'value': appci},
                {'column': 'source', 'operator': 'in', 'value': tools},
                {'custom': f"(closed_timestamp IS NULL OR closed_timestamp = 'NA' OR closed_timestamp >= '{now_str}')"}
            ]
            
            if CONFIG.get("ENV", "").lower() == "local":
                columns.append("partition_0")
                where_clauses.append({'column':'partition_0', 'operator': '=', 'value': "2025-10-28"})
            elif ual_env == "dev":
                where_clauses.append({'column':'partition_0', 'operator': '=', 'value': "2025-10-28"})
            else:
                columns.append("partition_0")
                where_clauses.append({'column': 'partition_0', 'operator': '=', 'value': yesterday_ymd})

            sql_query = self.construct_secure_query(
                safe_table_name,
                columns,
                where_clauses,
                distinct=True
            )
            # Use Lake Formation workgroup for shared resource links
            query_results = self.execute_athena_query(safe_database, sql_query, blocking=True, workgroup='primary')

            # Rate Limit Log
            if query_results is False:
                logger.error(f"Athena query returned False (appci={appci}, scan={scan}). Rate limit may have been exceeded, returning AppCI back to the weekly pool.")
                logger.info(f"The query was: {sql_query}")
                logger.info(f"the results were: {query_results}")

            # output_filename = f"findings_{appci}_{scan}_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
            # with open(output_filename, "w") as f:
            #     for row in query_results:
            #         f.write(str(row) + "\n")

            return query_results
    
        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get findings for appci: {appci}. Error={error}")
