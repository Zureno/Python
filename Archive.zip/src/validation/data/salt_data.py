from shared.athena_integration import AthenaIntegration
from integrations.asvs.salt import SaltIntegration
from datetime import datetime, timedelta
import logging
import os
import boto3
from shared.config import CONFIG
from .logger import logger


class SaltData(AthenaIntegration):
    
    def __init__(self):
        self.database = super()
        self.athena_client = boto3.client('athena')
        self.salt_api = SaltIntegration()

    def datalake_is_onboarded(self, appci):
        try:
            if appci is None:
                raise Exception('Parameter appci is mandatory')
            
            safe_database = self.database.sanitize_identifier("appsec_database_for_datalake_shared_resources")
            safe_table_name = self.database.sanitize_identifier("salt_security_endpoints_shared")
            one_year_ago = datetime.now() - timedelta(days=365)
            one_year_ago_str = one_year_ago.strftime('%Y-%m-%d')

            #In the future, pull additional data columns here
            columns = ["appci", "partition_0"]
            
            where_clauses = [
                {'column': 'appci', 'operator': 'LIKE', 'value': f'%{appci.lower()}%'},
                {'column': 'partition_0', 'operator': '>=', 'value': one_year_ago_str}
            ]

            order_by_clauses = [
                {'column': 'partition_0', 'ascending': False}
            ]

            sql_query = self.database.construct_secure_query(safe_table_name,
                                                    columns,
                                                    where_clauses,
                                                    order_by_clauses)
            
            query_results = self.database.execute_athena_query(safe_database, sql_query)
            
            return bool(query_results)

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get findings for appci: {appci}. Error={error}")

    def get_datalake_posture_gaps(self, appci):
        try:
            if appci is None:
                raise Exception('Parameter appci is mandatory')
            
            safe_database = self.database.sanitize_identifier("appsec_database_for_datalake_shared_resources")
            safe_table_name = self.database.sanitize_identifier("salt_security_gaps_shared")
            one_year_ago = datetime.now() - timedelta(days=365)
            one_year_ago_str = one_year_ago.strftime('%Y-%m-%d')

            #In the future, pull additional data columns here
            columns = ["appci", "status", "partition_0", "posturegapname"]
            
            where_clauses = [
                {'column': 'appci', 'operator': 'LIKE', 'value': f'%{appci.lower()}%'},
                {'column': 'status', 'operator': '=', 'value': 'Open'},
                {'column': 'partition_0', 'operator': '>=', 'value': one_year_ago_str}\
            ]

            order_by_clauses = [
                {'column': 'partition_0', 'ascending': False}
            ]

            sql_query = self.database.construct_secure_query(safe_table_name,
                                                    columns,
                                                    where_clauses,
                                                    order_by_clauses)
            query_results = self.database.execute_athena_query(safe_database, sql_query)

            #For consistency, rename to match API posture gap field
            if any("posturegapname" in res for res in query_results):
                for res in query_results:
                    if "posturegapname" in res:
                        res["postureGapName"] = res.pop("posturegapname")
            return query_results

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get findings for appci: {appci}. Error={error}")
        
    def get_posture_gaps(self, appci):
        posture_gaps = []
        
        if CONFIG["USE_API"] is True:
                logger.info("Using API")
                is_onboarded = self.salt_api.is_onboarded(appci)
                if is_onboarded is True:
                        posture_gaps = self.salt_api.posture_gaps(appci)
                        return posture_gaps      
                        
        # If USE_API = False or is_onboarded = False, we assume datalake
        is_onboarded = self.datalake_is_onboarded(appci)
        if is_onboarded is True:
                posture_gaps = self.get_datalake_posture_gaps(appci)
        else:
                posture_gaps = ["NA"]
        
        return posture_gaps