from aws_lambda_powertools import Logger

# Singleton logger for validation-lambda
logger = Logger(service="validation-lambda-data")
