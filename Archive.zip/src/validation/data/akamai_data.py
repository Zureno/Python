from datetime import datetime, timedelta
import boto3
import logging
import os
from shared.athena_integration import AthenaIntegration, S3_BUCKET
from .logger import logger

class AkamaiData(AthenaIntegration):

    def __init__(self):
        super().__init__()
        self.athena_client = boto3.client('athena')

    def _execute_athena_query_with_workgroup(self, database, query, blocking=True):
        start_params = {
            'QueryString': query,
            'QueryExecutionContext': {'Database': database},
            'ResultConfiguration': {'OutputLocation': S3_BUCKET},
            'WorkGroup': 'primary',  # hardcoded for AWS
        }
        response = self.athena_client.start_query_execution(**start_params)
        qid = response.get('QueryExecutionId')
        if blocking:
            self.wait_for_query_to_finish(qid)
            return self.get_query_results(qid)
        return qid

    def _run_query(self, database, table, columns, where, order_by, limit=10, distinct=True):
        sql = self.construct_secure_query(
            table, columns, where, order_by, distinct=distinct, limit=limit
        )
        qid = self.execute_athena_query(database, sql, False)
        if not qid:
            return []
        self.wait_for_query_to_finish(qid)
        return self.get_query_results(qid)

    # Quote helper for Athena identifiers
    def _q(self, name: str) -> str:
        return f'"{name}"'

    def get_akamai_onboarding_compliance(self, appci):
        """
        Rules in last 14 days:
          - Bot Manager fails if any covered = 'No'
          - WAF fails if any onboarding_canidate = 'No'
          - If no 'No', pass if at least one 'Yes'
        """
        metadata = []
        

        try:
            if not appci:
                logger.warning('Athena query for akamai validator not executed because an appci is missing')
                raise Exception('Parameter appci is mandatory')

            # Base summarized source (avoid Glue view StorageDescriptor issue)
            db = "appsec_database_for_datalake_shared_resources"
            tbl = "akamai_onboarding_shared"

            cutoff = (datetime.utcnow() - timedelta(days=14)).strftime("%Y-%m-%d")
            safe_appci = str(appci).replace("'", "''")
            
            # Yesterday's date in two formats
            yesterday_ymd = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            yesterday_mdy = (datetime.now() - timedelta(days=1)).strftime("%m-%d-%Y")

            sql = (
                f'WITH base_filtered AS ( '
                f'  SELECT * '
                f'  FROM {self._q(db)}.{self._q(tbl)} '
                f'  WHERE {self._q("appci")} = \'{safe_appci}\' '
                f'), '
                f'latest_p0 AS ( '
                f'  SELECT max({self._q("partition_0")}) AS p0 '
                f'  FROM base_filtered '
                f'), '
                f'latest_period AS ( '
                f'  SELECT date_format( '
                f'           max(date_parse({self._q("period")}, \'%m-%d-%Y\')), '
                f'           \'%m-%d-%Y\' '
                f'         ) AS per '
                f'  FROM base_filtered '
                f'  WHERE {self._q("partition_0")} = (SELECT p0 FROM latest_p0) '
                f'), '
                f'filtered_latest AS ( '
                f'  SELECT * '
                f'  FROM base_filtered '
                f'  WHERE {self._q("partition_0")} = (SELECT p0 FROM latest_p0) '
                f'    AND {self._q("period")} = (SELECT per FROM latest_period) '
                f') '
                f'SELECT *'
                f'FROM filtered_latest '
                f'ORDER BY {self._q("partition_0")} DESC '
            )

            qid = self._execute_athena_query_with_workgroup(db, sql, False)
            if not qid:
                msg = f"Athena query failed to start for Akamai validator (appci={appci})"
                logger.warning(msg)
                raise Exception(msg)

            self.wait_for_query_to_finish(qid)
            logger.info(f'Athena query for akamai validator (id = {qid}) executed successfully')
            rows = self.get_query_results(qid)

        #    if not rows:
        #        logger.info(f"No Akamai rows found for {appci}; skipping Akamai validation")
        #        return None 

            has_failing_combination = False
            valid_combinations = []
            pass_records = 0
            fail_records = 0
            special_pass = 0


            for record in rows:
                onboarding_candidate = str(record.get("onboarding_canidate", "")).strip().lower()
                covered = str(record.get("covered", "")).strip().lower()
                acronym = str(record.get("acronym", "")).strip()
                operational_status = str(record.get("operational_status", "")).strip()
                hosting_type = str(record.get("hosting_type", "")).strip()
                dns = str(record.get("dns", "")).strip()
                source = str(record.get("source", "")).strip()
                network_exposure = str(record.get("network_exposure", "")).strip()
                third_party = str(record.get("third_party", "")).strip()

                if (
                    acronym == "" or acronym.upper() == "RETIRED"
                    or operational_status == "" or operational_status == "Retired" 
                    or hosting_type == "SaaS" 
                    or hosting_type == "NA"  
                    or dns == "" 
                    or "ualaki" in dns.lower()
                    or "acme-challenge" in dns.lower()
                    or source in ("docker-sidecar", "docker-sidecar,gigamon")
                    or network_exposure != "External facing (Available on Internet)" 
                    or third_party == "" 
                    or third_party == "Yes" 
                ):
                    special_pass += 1
                    logger.info(f"Record passes special conditions for AppCI {appci}")
                    continue

                
                elif onboarding_candidate == "yes" and covered == "no" or \
                   (onboarding_candidate == "no" and covered == "yes"):
                    fail_records += 1
                    logger.info(f"Failing combination found for AppCI {appci}")
                 
                
                elif (onboarding_candidate == "yes" and covered == "yes") or \
                   (onboarding_candidate == "no" and covered == "no"):
                    pass_records += 1
                   # valid_combinations.append((onboarding_candidate, covered))

                else:
                    fail_records += 1
            

            if pass_records == 0 and fail_records == 0 and special_pass == 0:
                compliant = False
            elif fail_records == 0:
                compliant = True
            else:
                compliant = False

            if compliant:
                metadata.extend(["akamai"])
                compliance_status = "PASS"
            else:
                compliance_status = "FAIL"


            logger.info(f"Akamai onboarding & coverage compliance for {appci}: {compliance_status}")
                
            return metadata

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get Akamai onboarding findings for appci: {appci}. Error={error}"
            )