import copy
import json
import logging
import os
import boto3
# import time
from botocore.exceptions import ClientError
from shared.ssm import get_ssm_parameter
from shared.process import process_validation
from shared.config import CONFIG
from datetime import datetime

if CONFIG["ENV"] == "dev":
    REGION = os.environ['AWS_REGION']
else:
    REGION = "us-east-1"

dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

logger = logging.getLogger(__name__)
logger.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))

# Global variables to store configuration
TABLE_NAME = None
table = None
ENV = CONFIG["ENV"]
QA_BUCKET_NAME = f"eqa-udcrm-qa-bucket-dev"


def init_config():
    # gets configuration items from ssm
    global TABLE_NAME, table
    if TABLE_NAME is None:
        TABLE_NAME = "eqa-cdr-processing-table"
        table = dynamodb.Table(TABLE_NAME)

def write_validation_results(identifier, validation_results):
    # writes results to our processing table
    try:
        current_date = datetime.now().strftime("%m/%d/%Y")

        if validation_results:
            response = table.update_item(
                Key={'identifier': identifier},
                UpdateExpression="SET validation_results = :val, last_processed = :date, enabled = :enabled",
                ExpressionAttributeValues={
                    ':val': json.dumps(validation_results),
                    ':date': current_date,
                    ':enabled': False
                },
                ReturnValues="UPDATED_NEW"
            )
            logger.info(f"Successfully wrote validation results for identifier: {identifier}")
            return response
        else:
            logger.info(f"No validation results to write for identifier: {identifier}")
            return None
    except ClientError as e:
        error = f"Error writing validation results to DynamoDB: {e.response['Error']['Message']}"
        raise ValueError(error)

def send_to_standard_sns(topic_arn, message):
    # function that writes data to sns topics for next steps
    sns_client = boto3.client('sns')

    publish_params = {
        'TopicArn': topic_arn,
        'Message': json.dumps(message)
    }

    try:
        response = sns_client.publish(**publish_params)
        logger.info(f"Message sent to SNS. MessageId: {response['MessageId']}")
    except Exception as e:
        logger.warning(f"Sending message to SNS: {str(e)}")
def handler(event, context):
    # reads from validation sns topic
    # processes results
    # writes results to the processing table for final servicenow
    init_config()  # Initialize configuration if not already done

    qa_test = False

    try:
        if CONFIG["ENV"] == 'local':
            # Change here for local testing other AppCI, mac address, OT infra etc
            # Examples: 'AAW' for applications,  'VCLD34GPAHBAP13' for hostnames, 'BHS - OT Infra' for OT infra
            identifier = "CDC"
        else:
            logger.info(f"Event Received: {event}")
            # Lambda payload for normal validation run
            if "Records" in event:
                sns_message = event["Records"][0]["Sns"]
                body = json.loads(sns_message["Message"])
                identifier = body.get('identifier')
            # Lambda payload for QA run
            else: 
                qa_test = True
                identifier = event.get("appci")  # TODO: edit qa testing approach to support non-appci entities?
                qa_control = event.get("qa_control")
                
            logger.info(f"Retrieved body: {body}")

        if not identifier:
            raise ValueError("No 'identifier' provided in the event")

        try:
            response = table.get_item(Key={'identifier': identifier})
        except ClientError as e:
            logger.warning(f"Querying DynamoDB: {e.response['Error']['Message']}")
            raise

        # Check if the item exists
        if 'Item' not in response:
            logger.error(f"No item found in DynamoDB for identifier: {identifier}")
            raise ValueError(f"No item found in DynamoDB for identifier: {identifier}")
        
        sast = response["Item"]["sast_scannable"]
        dast = response["Item"]["dast_scannable"]

        # Run validation as usual
        if not qa_test:
            control_status = process_validation(identifier, sast, dast)
            if "error" in control_status:
                return {
                    "message": f"Validation queue is empty for identifier {identifier}",
                    "identifier": identifier
                }

            # Write validation results to DynamoDB
            if CONFIG["ENV"] == 'local':
                logger.info('Running Testing Locally..') #uncomment below for the json results
                # with open (f'validation_results_output.json', 'w') as file:
                #    json.dump(control_status, file, indent=4)  # Format JSON output
            else:
                write_validation_results(identifier, control_status)



        # Run validation as QA test
        else:
            # Run the validation on only the control to QA test
            control_status = process_validation(identifier, sast, dast, qa_control=qa_control)
            return control_status


    except Exception as e:
        # Log the error and return an error response
        error_message = f"An error occurred: {str(e)}"
        logger.warning(error_message)
        return {
            "error": error_message,
            "status": "FAILED"
        }


class MinimalContext:
    def __init__(self):
        self.invoked_function_arn = "arn.aws.lambda:us-east-1:123456789012:function:test"


# Sample json payload that is expected to be in DynamoDb
sample_json_payload = {
    "control": "OWASP-V14.4.4",
    "appci": "BBS",
    "control_data": "{\"control\": \"OWASP-V14.4.4\", \"chapter_name\": \"Configuration\", \"enabled\": true, \"definition\": \"all\", \"validators\": [{\"criteria\": [\"Missing X-Content-Type-Options Header\"], \"cwe\": 116, \"type\": \"findings\", \"tool\": \"sast\"}, {\"criteria\": [\"Missing Content-Type Header\"], \"cwe\": 116, \"type\": \"findings\", \"tool\": \"sast\"}]}"
}

# Sample SNS payload
sample_sns_payload = {
    "Records": [
        {
            "Sns": {
                "Message": "{\"identifier\":\"BHS\"}",
                "MessageGroupId": "\"mid_12345\""
            }
        }
    ]
}

sample_event = {
    "body": sample_sns_payload
}

# Sample qa payload
qa_payload = {
    "appci": "BBS",
    "qa_control": {
        'enabled': {'BOOL': True}, 
        'control': {'S': 'CDR-IAM3.1.11'}, 
        'definition': {'S': 'all'}, 
        'confidence': {'S': 'medium'}, 
        'description': {'S': 'Upon password generation, system and service accounts shall be configured with a randomly generated password through the PAM tool that is at least thirty (30) characters in length, and that meets password complexity requirements.\xa0'}, 
        'validators': {'S': '[{\"type\": \"findings\", \"tool\": \"dast\", \"criteria\": [\"Weak Basic Authentication Credentials\"]}]'}}
}

if __name__ == '__main__':
    # start_time = time.time()
    result = handler({}, {})
    # result = handler(sample_sns_payload, {})
    # end_time = time.time()
    # elapsed = end_time - start_time
    # minutes = int(elapsed // 60)
    # seconds = elapsed % 60
    # print(f"Handler runtime: {minutes} minutes {seconds:.2f} seconds")
    # print("Handler result:", result)
