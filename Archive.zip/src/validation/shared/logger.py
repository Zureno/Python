from aws_lambda_powertools import Logger

# Singleton logger for validation-lambda-shared
logger = Logger(service="validation-lambda-shared")
