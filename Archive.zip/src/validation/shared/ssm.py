
import boto3
from .logger import logger
import os
from functools import lru_cache
from botocore.exceptions import ClientError

ssm = boto3.client('ssm')

@lru_cache(maxsize=None)
def get_ssm_parameter(param_name):
    try:
        response = ssm.get_parameter(Name=param_name, WithDecryption=True)
        return response['Parameter']['Value']
    except ClientError as e:
        logger.warning(f"Fetching parameter {param_name}: {e}")
        raise
    except Exception as e:
        logger.warning(f"Fetching parameter {param_name}: {e}")
        raise