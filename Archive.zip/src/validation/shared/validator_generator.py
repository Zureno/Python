from validator.findings_validator import FindingsValidator
from validator.source_validator import SourceValidator
from validator.pipeline_validator import PipelineValidator
from validator.kong_validator import KongValidator
from validator.sbom_validator import SbomValidator
from validator.wiz_validator import WizValidator
from validator.splunk_validator import SplunkValidator
from validator.salt_validator import SaltValidator
from validator.saltonboard_validator import SaltonboardValidator
from validator.ot_validator import OTValidator
from validator.network_validator import NetworkValidator
from validator.splunkot_validator import SplunkotValidator
from validator.onboarded_validator import onboardedValidator
from validator.akamai_validator import AkamaiValidator
from validator.codeql_validator import CodeqlValidator
from integrations.asvs.veracode import VeracodeIntegration
from integrations.asvs.kong import KongIntegration
from integrations.legacy.veracode import LegacyVeracodeIntegration
from integrations.legacy.netsparker import NetsparkerIntegration
from data.findings_data import FindingsData
from data.wiz_data import WizData
from data.salt_data import SaltData
from data.ot_data import OTData
from data.splunkot_data import SplunkotData
from data.splunk_data import SplunkData
from data.network_data import NetworkData
from data.akamai_data import AkamaiData
from data.codeql_data import CodeqlData

class ValidatorGenerator:
        def __init__(self):
                self.findings = FindingsData()
                self.wiz = WizData()
                self.ot = OTData()
                self.splunk = SplunkData()
                self.splunkot = SplunkotData()
                self.salt = SaltData()
                self.network = NetworkData()
                self.kong = KongIntegration()
                self.akamai = AkamaiData()
                self.codeql = CodeqlData() 

        def bootstrap_findings_validator(self, appci, sast_compliant, dast_compliant, USE_API, sast_scannable, dast_scannable):
                legacyVeracode = LegacyVeracodeIntegration()
                netsparker = NetsparkerIntegration()
                vulns = []
                if sast_scannable or dast_scannable:
                        if USE_API:
                                if  sast_scannable:
                                    vulns += legacyVeracode.get_findings_by_cwe(appci)
                                if  dast_scannable:
                                    vulns += netsparker.get_findings(appci)
                        else:
                                if sast_compliant: 
                                        vulns += self.findings.get_datalake_findings(appci, "sast")
                                if dast_compliant: 
                                        vulns += self.findings.get_datalake_findings(appci, "dast")
                return vulns
        
        def bootstrap_kong_validator(self, appci):
                result = self.kong.get_kong_status(appci)
                return result
        
        def bootstrap_wiz_validator(self, appci):
                wiz_vulns = []
                wiz_vulns = self.wiz.get_wiz_findings(appci)
                return wiz_vulns
        
        def bootstrap_ot_validator(self, appci):
                ot_vulns = []
                ot_vulns = self.ot.get_ot_findings(appci)
                return ot_vulns

        def bootstrap_splunkot_validator(self, appci):
                splunkot_vulns = []
                splunkot_vulns = self.splunkot.get_splunkot_findings(appci)
                return splunkot_vulns          

        def bootstrap_splunk_validator(self, hostname):
                splunk_status = []
                splunk_status = self.splunk.get_splunk_status(hostname)
                return splunk_status
        
        def bootstrap_sbom_validator(self, appci, sast_compliance):
                libraries = []
                sbom = []
                veracode = VeracodeIntegration()
                if sast_compliance:
                        libraries, sbom = veracode.get_libraries(appci)
                return libraries, sbom

        def bootstrap_salt_validator(self, appci):
                posture_gaps = []
                posture_gaps = self.salt.get_posture_gaps(appci)
                return posture_gaps

        def bootstrap_saltonboard_validator(self, appci):
                results = []
                results = self.salt.datalake_is_onboarded(appci)
                return results
        
        def bootstrap_network_validator(self, controls):
                network_compliance = []
                network_compliance = self.network.get_network_compliance(controls)
                return network_compliance
        
        def bootstrap_akamai_validator(self, appci):
                result = self.akamai.get_akamai_onboarding_compliance(appci)
                return result
        def bootstrap_codeql_validator(self, appci):
                codeql_vulns = []
                codeql_vulns = self.codeql.get_codeql_findings(appci)
                return codeql_vulns
        def get_validator(self, vtype):
                # add types here as we expand
                if vtype == "findings":
                        return FindingsValidator()
                if vtype == "source":
                        return SourceValidator()
                if vtype == "sbom":
                        return SbomValidator()
                if vtype == "pipeline":
                        return PipelineValidator()
                if vtype == "kong":
                        return KongValidator()
                if vtype == "salt":
                        return SaltValidator()
                if vtype == "saltonboard":
                        return SaltonboardValidator()
                if vtype == "wiz":
                        return WizValidator()
                if vtype == "ot":
                        return OTValidator()
                if vtype == "splunkot":
                        return SplunkotValidator()
                if vtype == "splunk":
                        return SplunkValidator()
                if vtype == "network":
                        return NetworkValidator()
                if vtype == "onboarded":
                        return onboardedValidator()
                if vtype == "akamai":
                        return AkamaiValidator()
                if vtype == "codeql":
                        return CodeqlValidator()
                
