from .logger import logger

def get_entity_class(template_ids_from_snow):
    entity_classes = []
    # Get entity class of asset being processed, from SNOW
    for template in template_ids_from_snow:
        if "entityClass" in template:
            if "displayName" in template["entityClass"]:
                entity_classes.append(template["entityClass"]["displayName"])

    entity_classes = list(set(entity_classes))
    return entity_classes

def process_identifier(identifier, entity_classes):
    # If entity is OT Infrastructure, set the query string (identifier) to AppCI key
    # e.g., BHS - OT Infra -> BHS
    # Since OT devices are grouped by AppCI, we need to query them from Armis using AppCI
    if "OT Infrastructure" in entity_classes:
        identifier = identifier.split('-')[0].strip()
    return identifier

def get_validator_entity_classes(details):
    # Get entity classes that validations should run on
    validator_entity_classes = []
    if "entity_classes" in details:
        validator_entity_classes = details["entity_classes"]
    return validator_entity_classes

def determine_skipped_entity(validator_entity_classes, asset_entity_classes):
    # If asset entity class doesn't match any of the validator entity classes, skip validation
    skipped = False
    if not any(entity in validator_entity_classes for entity in asset_entity_classes):
        skipped = True
        logger.warning(f"Validation skipped. Validation expects entity classes {validator_entity_classes}, but entity is {asset_entity_classes}")
    return skipped