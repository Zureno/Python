import asyncio
from aiohttp import ClientSession, ClientResponseError


def execute(requests):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    responses = loop.run_until_complete(make_requests(requests))
    return responses

async def get_request(session, url, headers):
    async with session.get(url, headers=headers) as response:
        return await response.json()

async def make_requests(requests):
    async with ClientSession() as session:
        tasks = [asyncio.ensure_future(get_request(session, request["url"], request["headers"])) for request in requests]
        responses = await asyncio.gather(*tasks)
        return responses