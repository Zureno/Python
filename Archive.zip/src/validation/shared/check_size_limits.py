"""Checks length of raw evidence against SNOW limit (4000 characters) and
   DynamoDB limit (400,000 characters), and removes it if the limit is exceeded"""

limit_exceeded_msg = "Size limit exceeded. Review output in Value field for more information about this control validation."

def check_snow_limit(control_status):
    if "raw_evidence" in control_status:
        raw_length = len(str(control_status["raw_evidence"]))
        if raw_length > 4000:
            control_status["raw_evidence"] = limit_exceeded_msg
    return control_status

def check_dynamo_limit(merged_status):
    merged_status_length = len(str(merged_status))
    if merged_status_length > 399000: # set to 399k to leave buffer for other fields in dynamo tables
        for status in merged_status:
            if "raw_evidence" in status:
                status["raw_evidence"] = limit_exceeded_msg
    
    return merged_status