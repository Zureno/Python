from typing import Any, Dict, List, Optional
from datetime import datetime
from pydantic import BaseModel, Field

# ─── Sbom‐Related Models ────────────────────────────────────────────
class Application(BaseModel):
    guid: Optional[str] = Field(None, description="Unique identifier for the application.")

class EmbeddedApplications(BaseModel):
    applications: Optional[List[Application]] = Field(None, description="List of application objects.")

class License(BaseModel):
    id: Optional[str] = Field(None, description="SPDX license identifier, if provided.")
    name: Optional[str] = Field(None, description="License name if SPDX id is not available.")
    url: Optional[str] = Field(None, description="URL to the license text.")

class LicenseEntry(BaseModel):
    license: Optional[License] = Field(None, description="License information for a component.")

class Supplier(BaseModel):
    name: Optional[str] = Field(None, description="Supplier or vendor name.")
    url: Optional[List[str]] = Field(None, description="List of URLs for the supplier.")

class Property(BaseModel):
    name: Optional[str] = Field(None, description="Name of the custom property.")
    value: Optional[str] = Field(None, description="Value of the custom property.")

class Component(BaseModel):
    bom_ref: Optional[str] = Field(None, alias="bom-ref", description="The BOM reference string (component identifier).")
    licenses: Optional[List[LicenseEntry]] = Field(None, description="List of license entries (if present).")
    supplier: Optional[Supplier] = Field(None, description="Supplier information (if present).")
    properties: Optional[List[Property]] = Field(None, description="List of custom properties (if present).")

class SbomResponse(BaseModel):
    embedded: Optional[EmbeddedApplications] = Field(None, alias="_embedded", description="Container for `applications` list.")
    components: Optional[List[Component]] = Field(None, alias="components")
    component: Optional[List[Component]] = Field(None, description="List of SBOM components.")
    component: Optional[Component] = Field(None, description="List of SBOM components.")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Top-level SBOM metadata (e.g. format, version, serialNumber).")

    class Config:
        validate_by_name = True
        json_schema_extra = {
            "example": {
                "_embedded": {"applications": [{"guid": "12345-abcdef-67890"}]},
                "components": [
                    {"bom-ref": "org.example:libraryA:1.2.3", "licenses": [{"license": {"id": "MIT"}}], "supplier": {"name": "ExampleCorp"}, "properties": [{"name": "language", "value": "Java"}]}
                ],
                "metadata": {"bomFormat": "CycloneDX", "specVersion": "1.4", "serialNumber": "urn:uuid:1111-2222-3333-4444"}
            }
        }

# ─── Findings Models ───────────────────────────────────────────────────
class FindingApplication(BaseModel):
    guid: str = Field(..., description="Unique identifier for the application.")
    last_completed_scan_date: Optional[datetime] = Field(None, description="Timestamp of the most recent completed SAST scan, if available.")

class EmbeddedFindings(BaseModel):
    applications: List[FindingApplication] = Field(..., description="List of applications with their last_completed_scan_date.")

class FindingsResponse(BaseModel):
    embedded: EmbeddedFindings = Field(..., alias="_embedded", description="Container for `applications` list in findings.")

    class Config:
        validate_by_name = True
        json_schema_extra = {
            "example": {
                "_embedded": {"applications": [
                    {"guid": "12345-abcdef-67890", "last_completed_scan_date": "2024-05-01T15:30:00Z"},
                    {"guid": "98765-fedcba-43210", "last_completed_scan_date": "2025-02-12T10:15:45Z"}
                ]}
            }
        }
        
# ─── Harness Models ────────────────────────────────────────────────────
class EntityRef(BaseModel):
    versionLabel: Optional[str] = Field(None, description="Template version label")
    identifier: Optional[str] = Field(None, description="Template identifier")
    projectIdentifier: Optional[str] = Field(None, description="Project in which the template is used")
    orgIdentifier: Optional[str] = Field(None, description="Organization owning the project")
 
class ReferredByEntity(BaseModel):
    type: Optional[str] = Field(None, description="Entity type, e.g. 'Template'")
    entityRef: Optional[EntityRef] = Field(None, description="Reference to the template entity")
 
class TemplateUsageItem(BaseModel):
    referredByEntity: ReferredByEntity
 
class TemplateUsageData(BaseModel):
    totalPages: int
    totalItems: int
    pageItemCount: int
    pageSize: int
    empty: bool
    pageToken: Optional[Any]
    content: List[TemplateUsageItem]
 
class TemplateUsageResponse(BaseModel):
    status: str
    data: TemplateUsageData
    metaData: Optional[Any] = None
    correlationId: str
 
    class Config:
        validate_by_name = True
 
class VersionsListItem(BaseModel):
    versionLabel: str
 
class VersionsData(BaseModel):
    content: List[VersionsListItem]
 
class VersionsListResponse(BaseModel):
    data: VersionsData
 
class ProjectTags(BaseModel):
    tags: dict
 
class ProjectDetailResponse(BaseModel):
    project: ProjectTags

# ─── Github Models ──────────────────────────────────────────────────────────────────────────────────────────
class GitHubRepoSummary(BaseModel):
    name: str
    description: Optional[str]
 
class GitHubCodeItem(BaseModel):
    name: str
    path: str
    html_url: str
    repository: GitHubRepoSummary
 
class GitHubCodeSearchResponse(BaseModel):
    total_count: int
    incomplete_results: bool
    items: List[GitHubCodeItem]
 
    class Config:
        json_schema_extra = {
            "example": {
                "total_count": 6,
                "incomplete_results": False,
                "items": [
                    {
                        "name": "README.md",
                        "path": "README.md",
                        "html_url": "https://github.com/United-Airlines-Org/AirportOps.AAP.AAP-JET-UI/blob/.../README.md",
                        "repository": {
                            "name": "AirportOps.AAP.AAP-JET-UI",
                            "description": None
                        }
                    }
                ]
            }
        }

