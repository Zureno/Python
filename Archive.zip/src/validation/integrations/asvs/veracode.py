import requests
from shared.athena_integration import AthenaIntegration
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC
from shared.secrets_manager import get_secret
from integrations.asvs.input_validation.input_validation import validate_findings_payload, validate_sbom_payload
from .logger import logger

HEADERS = {'Content-Type': 'application/json'}

class VeracodeIntegration:
    def __init__(self):
        logger.debug("VeracodeIntegration: Initializing integration")
        self.athena_integration = AthenaIntegration()
        evidence_secrets = get_secret()
        self.api_base = "https://api.veracode.com/appsec/v1"
        self.sbom_base = "https://api.veracode.com/srcclr/sbom/v1"
        self.size = 200
        self.vid = evidence_secrets["VERACODE_VID"]
        self.vkey = evidence_secrets["VERACODE_VKEY"]
        logger.debug("VeracodeIntegration: Initialization complete")

    def get_profiles_by_appci(self, appCi: str):
        url = (
            f"{self.api_base}/applications"
            f"?custom_field_names=Application Key"
            f"&custom_field_values={appCi}"
            f"&size={self.size}"
        )
        logger.debug(f"get_profiles_by_appci: url={url}")
        try:
            response = requests.get(
                url,
                auth=RequestsAuthPluginVeracodeHMAC(
                    api_key_id=self.vid,
                    api_key_secret=self.vkey
                ),
                headers=HEADERS
            )
            response.raise_for_status()
            raw = response.json()
            logger.debug(f"get_profiles_by_appci: response received, status={response.status_code}")
        except requests.exceptions.HTTPError as http_err:
            logger.error(f"get_profiles_by_appci: HTTP error occurred: {http_err}")
            return {"error": "HTTP error occurred", "details": str(http_err)}
        except ValueError:
            logger.error("get_profiles_by_appci: Invalid JSON returned from Veracode")
            return {"error": "Invalid JSON returned from Veracode"}
        except Exception as e:
            logger.error(f"get_profiles_by_appci: Unexpected error during request: {e}")
            return {"error": "Unexpected error during request", "details": str(e)}

        # Validate payload
        validation = validate_findings_payload(raw)
        if not validation["ok"]:
            logger.error(f"get_profiles_by_appci: Validation failed for findings: {validation.get('errors')}")
            return {"error": "Validation failed for findings", "details": validation.get("errors")}
        logger.debug("get_profiles_by_appci: Validation successful")
        return validation["data"]

    def get_sbom(self, appUUID: str):
        url = f"{self.sbom_base}/targets/{appUUID}/cyclonedx?type=application"
        logger.debug(f"get_sbom: url={url}")
        try:
            response = requests.get(
                url,
                auth=RequestsAuthPluginVeracodeHMAC(
                    api_key_id=self.vid,
                    api_key_secret=self.vkey
                ),
                headers=HEADERS
            )
            response.raise_for_status()
            raw = response.json()
            logger.debug(f"get_sbom: response received, status={response.status_code}")
            if response.status_code >= 500:
                logger.error(f"get_sbom: Server error {response.status_code}: {response.text}")
                return {"error": f"Server error {response.status_code}", "details": response.text}
        except requests.exceptions.HTTPError as http_err:
            logger.error(f"get_sbom: HTTP error occurred: {http_err}")
            return {"error": "HTTP error occurred", "details": str(http_err)}
        except ValueError:
            logger.error("get_sbom: Invalid JSON returned from Veracode")
            return {"error": "Invalid JSON returned from Veracode"}
        except Exception as e:
            logger.error(f"get_sbom: Unexpected error during request: {e}")
            return {"error": "Unexpected error during request", "details": str(e)}

        # Validate payload
        validation = validate_sbom_payload(raw)
        if not validation["ok"]:
            logger.error(f"get_sbom: Validation failed for SBOM: {validation.get('errors')}")
            return {"error": "Validation failed for SBOM", "details": validation.get("errors")}
        logger.debug("get_sbom: Validation successful")
        return {"data": validation["data"]}

    def get_libraries(self, appci: str):
        logger.debug(f"get_libraries: start appci={appci}")
        libraries = []
        sbom_metadata = []

        profiles = self.get_profiles_by_appci(appci)
        if isinstance(profiles, dict) and profiles.get("error"):
            logger.error(f"get_libraries: Error fetching profiles: {profiles['details']}")
            return libraries, sbom_metadata

        apps = profiles.embedded.applications
        logger.debug(f"get_libraries: Found {len(apps)} applications")
        for application in apps:
            guid = application.guid
            logger.debug(f"get_libraries: Fetching SBOM for guid={guid}")
            sbom_resp = self.get_sbom(guid)
            if "error" in sbom_resp:
                logger.error(f"get_libraries: Error fetching SBOM for {guid}: {sbom_resp['details']}")
                continue
            sbom_data = sbom_resp["data"]

            # get components
            components = []
            if getattr(sbom_data, "components", None) is not None:
                components = sbom_data.components
            elif getattr(sbom_data, "component", None) is not None:
                comp = sbom_data.component
                if isinstance(comp, list):
                    components = comp
                else:
                    components = [comp]

            logger.debug(f"get_libraries: Found {len(components)} components for guid={guid}")
            for component in components:
                libraries.append({
                    "library": component.bom_ref or "",
                    "licenses": component.licenses or [],
                    "suppliers": component.supplier or {},
                    "properties": component.properties or []
                })

            if sbom_data.metadata:
                sbom_metadata.append(sbom_data.metadata)

        logger.debug(f"get_libraries: end libraries_count={len(libraries)}, sbom_metadata_count={len(sbom_metadata)}")
        return libraries, sbom_metadata

if __name__ == '__main__':
    logger.info("VeracodeIntegration: Running as main")
    veracode = VeracodeIntegration()

    # Example usage of get_libraries:
    libraries, metadata = veracode.get_libraries('AAP')
    logger.info(f"Libraries: {libraries}")
    logger.info(f"Metadata: {metadata}")