import requests
import json
from urllib.parse import quote

from shared.secrets_manager import get_secret
from shared.ssm import get_ssm_parameter
from .logger import logger

class SaltIntegration:
    '''Class to integrate with Salt'''


    def __init__(self):
        evidence_secrets = get_secret()
        self.api_base = "https://api.secured-api.com/"
        self.size = 200
        self.api_key = evidence_secrets["SALT_KEY"]
        access = f'Bearer {self.api_key}'
        self.HEADERS = {'Authorization': access, 'Content-Type': 'application/json'}


    def is_onboarded(self, appci):
        url = f"{self.api_base}v1/inventory/endpoints"
        query_params = f"label=AppCI:{appci.lower()}"
        full_url = f"{url}?{query_params}"
        try:
            response = requests.get(full_url, headers=self.HEADERS)
        except Exception as e:
            return (e)
        data = response.json()
        if not data['response']:
            return False
        else:
            return True

    def posture_gaps(self, appci):
        '''Function to the list the companys posture gaps for an appci'''
        url = f"{self.api_base}v1/apigovern/posture/gaps"
        posture_gaps = []
        offset_value = 0
        limit_value = 100
        label_value = f"AppCI:{appci.lower()}"

        while True:
            query_params = f"offset={offset_value}&limit={limit_value}&label={label_value}"
            full_url = f"{url}?{query_params}"
            try:
                response = requests.get(full_url, headers=self.HEADERS)
            except Exception as e:
                return (e)
            data = response.json()
            parsed_data = data['response']

            if not parsed_data:
                logger.info(f'No posture gaps found for {appci}')
                break

            posture_gaps.extend(parsed_data)
            offset_value += limit_value

        return posture_gaps
    