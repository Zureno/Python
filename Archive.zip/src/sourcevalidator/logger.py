from aws_lambda_powertools import Logger

logger = Logger(service="source-validator-lambda")
