import os
import json
import boto3
from boto3.dynamodb.conditions import Attr
from datetime import datetime, timedelta, timezone


TABLE_NAME = "eqa-ucas-manager-table"
SCHEDULE_DIR = os.path.join(os.path.dirname(__file__), "schedule")
RETENTION_DAYS = 90


def to_iso_utc(date_str, time_str):
	if not time_str.endswith("Z"):
		raise ValueError(f"time must end with 'Z' (UTC), got: {time_str}")
	base = time_str[:-1]
	try:
		dt = datetime.fromisoformat(f"{date_str}T{base}")
	except ValueError:
		dt = datetime.strptime(f"{date_str}T{base}", "%Y-%m-%dT%H:%M:%S")
	return dt.replace(tzinfo=timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def ingest_schedule_files(directory):
	entries = []
	for file in os.listdir(directory):
		path = os.path.join(directory, file)
		if os.path.isfile(path) and file.endswith(".json"):
			with open(path, "r") as f:
				data = json.load(f)
				schedule = data.get("schedule", [])
				entries.extend(schedule)
	return entries


def build_item(entry):
	# entry: { taskname, date, time, arguments?, directory? }
	scheduled_iso = to_iso_utc(entry["date"], entry["time"])
	pk = f"{entry['taskname']}#{scheduled_iso}"
	item = {
		"TaskName": pk,
		"Task": entry["taskname"],
		"ScheduledAt": scheduled_iso,
		"Status": "scheduled",
		"Date": entry["date"],
		"Time": entry["time"],
	}
	# Optional arguments from schedule JSON
	if "arguments" in entry and entry["arguments"] is not None:
		item["Arguments"] = entry["arguments"]
	# Optional directory from schedule JSON
	if "directory" in entry and entry["directory"]:
		item["Directory"] = entry["directory"]
	return item


def write_items(table, items):
	created = 0
	skipped = 0
	for item in items:
		# Pre-check to avoid raising ConditionalCheckFailedException during debug
		existing = table.get_item(
			Key={"TaskName": item["TaskName"]},
			ProjectionExpression="TaskName",
			ConsistentRead=True,
		).get("Item")
		if existing:
			skipped += 1
			print(f"Exists  {item['TaskName']}")
			continue
		table.put_item(Item=item)
		created += 1
		print(f"Created {item['TaskName']}")
	print(f"Done. Created: {created}, Skipped (exists): {skipped}.")


def handler(event, context):
	dynamodb = boto3.resource("dynamodb")
	table = dynamodb.Table(TABLE_NAME)
	entries = ingest_schedule_files(SCHEDULE_DIR)
	items = [build_item(e) for e in entries]
	print(f"Discovered {len(items)} schedule item(s) from '{SCHEDULE_DIR}'.")
	for it in items:
		print(f"- {it['Task']} @ {it['ScheduledAt']} -> PK={it['TaskName']}")
	write_items(table, items)
	# Always prune after load
	prune_table(table)


def prune_table(table):
	# Delete items whose ScheduledAt is older than RETENTION_DAYS
	cutoff = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
	cutoff_iso = cutoff.replace(microsecond=0).isoformat().replace("+00:00", "Z")
	print(f"Pruning items with ScheduledAt < {cutoff_iso}")

	deleted = 0
	last_key = None
	while True:
		scan_args = {
			"FilterExpression": Attr("ScheduledAt").lt(cutoff_iso),
			"ProjectionExpression": "TaskName",
		}
		if last_key:
			scan_args["ExclusiveStartKey"] = last_key
		resp = table.scan(**scan_args)
		items = resp.get("Items", [])
		if items:
			with table.batch_writer() as batch:
				for it in items:
					batch.delete_item(Key={"TaskName": it["TaskName"]})
					deleted += 1
		last_key = resp.get("LastEvaluatedKey")
		if not last_key and not items:
			break
	print(f"Pruned {deleted} item(s).")


def prune(event, context):
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(TABLE_NAME)
    prune_table(table)


if __name__ == "__main__":
	handler({}, {})

