from aws_lambda_powertools import Logger

# Singleton logger for ucasmanager-lambda
logger = Logger(service="ucasmanager-lambda")
