import json
import importlib
from datetime import datetime, timezone
import boto3
from boto3.dynamodb.conditions import Attr
from loadschedule import handler as loadschedule_handler
from extnettest import handler as extnettest_handler

TABLE_NAME = "eqa-ucas-manager-table"


def _now_iso_z():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _refresh_schedule():
    try:
        loadschedule_handler({}, {})
        print("Schedule refreshed and pruned.")
    except Exception as e:
        print(f"Schedule refresh failed: {e}")


def _scan_due_items(table, now_iso):
    items = []
    filt = Attr("Status").eq("scheduled") & Attr("ScheduledAt").lte(now_iso)
    kwargs = {
        "FilterExpression": filt,
        "ProjectionExpression": "TaskName, #t, ScheduledAt, Arguments, Directory, #d, #tm",
        "ExpressionAttributeNames": {"#t": "Task", "#d": "Date", "#tm": "Time"},
    }
    resp = table.scan(**kwargs)
    items.extend(resp.get("Items", []))
    while "LastEvaluatedKey" in resp:
        resp = table.scan(ExclusiveStartKey=resp["LastEvaluatedKey"], **kwargs)
        items.extend(resp.get("Items", []))
    return items


def _upsert_full_item(table, item, status):
    new_item = dict(item)
    new_item["Status"] = status
    table.put_item(Item=new_item)
    print(f"Upserted {item.get('TaskName')} -> {status}")


def _resolve_directory(task_module_name, directory):
    # Default directories for backward compatibility
    if directory:
        return directory
    # Prefer shared for callstatemachine, else default to ucasreset
    if task_module_name == "callstatemachine":
        return "shared"
    return "ucasreset"


def _run_task(task_module_name, args=None, directory=None):
    module_dir = _resolve_directory(task_module_name, directory)
    mod = importlib.import_module(f"{module_dir}.{task_module_name}")
    fn = getattr(mod, "main")
    # Backward-compatible invocation: try args, fall back to no-arg
    try:
        if args is not None:
            return fn(args)
        return fn()
    except TypeError:
        # Target function may not accept arguments
        return fn()


def handler(event=None, context=None):
    _refresh_schedule()
    table = boto3.resource("dynamodb").Table(TABLE_NAME)
    now_iso = _now_iso_z()
    due = _scan_due_items(table, now_iso)
    print(f"Found {len(due)} due item(s) at {now_iso}")

    completed = 0
    failed = 0

    for it in due:
        task_name = it.get("TaskName")
        task = it.get("Task")
        when = it.get("ScheduledAt")
        args = it.get("Arguments")
        directory = it.get("Directory")
        print(f"Running {task_name} ({task}) scheduled {when}")
        try:
            _run_task(task, args, directory)
            _upsert_full_item(table, it, "complete")
            completed += 1
        except Exception as e:
            print(f"Task {task_name} failed: {e}")
            _upsert_full_item(table, it, "failed")
            failed += 1

    out = {
        "status": "ok",
        "scheduled_count": len(due),
        "completed": completed,
        "failed": failed,
        "timestamp": now_iso,
    }
    
    # # Run external network tests after normal flow
    # try:
    #     extnettest_result = extnettest_handler()
    #     out["extnettest"] = extnettest_result
    #     print(f"External network test completed: {extnettest_result.get('statusCode')}")
    # except Exception as e:
    #     print(f"External network test failed: {e}")
    #     out["extnettest"] = {"statusCode": 500, "error": str(e)}
    
    return out


if __name__ == "__main__":
    res = handler()
    print(json.dumps(res))
