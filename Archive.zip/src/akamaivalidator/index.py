#placeholder code for IaC deployment
def handler(event, context):
    print("Lambda IaC infrastructure test successful")
    return {
        "message": "hello world"
    }
