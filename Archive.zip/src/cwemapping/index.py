import json
import os
from typing import List, Dict, Set
import boto3
from botocore.exceptions import ClientError
from logger import logger

TABLE_NAME = 'eqa-cwe-mappings-table'

def scan_all(table):
    # Scan all items from a DynamoDB table.
    items: List[Dict] = []
    response = table.scan()
    items.extend(response.get('Items', []))
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response.get('Items', []))
    return items

def delete_items_not_in_set(table, valid_ids: Set[str]):
    # Delete any cwe_id is not present in valid_ids.
    existing_items = scan_all(table)
    with table.batch_writer() as batch:
        for item in existing_items:
            key = item.get('cwe_id')
            if key is not None and key not in valid_ids:
                batch.delete_item(Key={'cwe_id': key})

def ingest_files(directory: str):
    # Load all JSON arrays from *.json files in a directory and concatenate entries.
    entries: List[Dict] = []
    if not os.path.isdir(directory):
        logger.warning(f"Provided cwemap directory does not exist: {directory}")
        return entries
    for file in os.listdir(directory):
        path = os.path.join(directory, file)
        if os.path.isfile(path) and file.endswith('.json'):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if isinstance(data, list):
                    source_name, _ = os.path.splitext(file)
                    for entry in data:
                        if isinstance(entry, dict):
                            entry = {**entry, '__source_file': source_name}
                            entries.append(entry)
                        else:
                            logger.warning(f"Skipping non-dict entry in {file}")
                else:
                    logger.warning(f"Skipping {file}: root JSON is not a list")
            except Exception as e:  
                logger.error(f"Error reading {file}: {e}")
    return entries

def prepare_item(raw: Dict):
    # Validate and transform a raw mapping entry into DynamoDB item form.
    if 'cwe_id' not in raw or 'cwe_name' not in raw:
        raise ValueError(f"Entry missing required keys: {raw}")
    cwe_id_val = raw['cwe_id']
    if isinstance(cwe_id_val, int):
        cwe_id_str = str(cwe_id_val)
    else:
        cwe_id_str = str(cwe_id_val).strip()
    cwe_name_val = str(raw['cwe_name']).strip()
    source_file = str(raw.get('__source_file', '')).strip()
    item = {
        'cwe_id': cwe_id_str,
        'cwe_name': cwe_name_val,
    }
    if source_file:
        item['source'] = source_file
    return item

def upsert_items(table, items: List[Dict]):
    # Perform PutItem for each prepared item
    with table.batch_writer() as batch:
        for itm in items:
            batch.put_item(Item=itm)

def handler(event, context):  
    logger.info("Starting CWE mappings ingest/update process")
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(TABLE_NAME)

    # Locate cwemap directory relative to this file.
    base_dir = os.path.dirname(__file__)
    cwemap_dir = os.path.join(base_dir, 'cwemap')

    # Ingest all entries from JSON files.
    raw_entries = ingest_files(cwemap_dir)
    if not raw_entries:
        logger.info("No entries found; nothing to process.")
        return {'status': 'no_data'}

    # Prepare items and deduplicate by cwe_id (last occurrence wins).
    prepared_map: Dict[str, Dict] = {}
    for raw in raw_entries:
        try:
            item = prepare_item(raw)
            prepared_map[item['cwe_id']] = item
        except ValueError as ve:
            logger.error(f"Skipping invalid entry: {ve}")

    prepared_items = list(prepared_map.values())
    valid_ids = set(prepared_map.keys())

    # Delete items not present in files.
    delete_items_not_in_set(table, valid_ids)

    # Upsert current items.
    try:
        upsert_items(table, prepared_items)
    except ClientError as e:
        logger.error(f"ClientError during batch upsert: {e}")
        raise

    logger.info(f"Successfully processed {len(prepared_items)} CWE mapping entries.")
    return {
        'status': 'ok',
        'count': len(prepared_items)
    }

if __name__ == '__main__': 
    handler({}, {})

