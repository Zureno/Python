from aws_lambda_powertools import Logger

# Singleton logger for scoring-lambda
logger = Logger(service="scoring-lambda")
