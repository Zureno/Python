import requests
from logger import logger



def close_snow_ticket(sys_id, comments, snow_url, username, password):
    base = f"{snow_url}/api/sn_compliance/aws_control_automation/ucas_override_ritm_results"
    url = f"{base}/{sys_id}"
    payload = {"stage": "Closed", "state": "Closed Complete", "comments": comments}
    response = requests.post(url, auth=(username, password), json=payload)
    logger.info(f"Response after closing the ticket: {response}")
    if response.status_code in [200, 201, 204]:
        logger.info(f"Successfully closed ticket {sys_id}")
        return True
    logger.error(f"Failed to close ticket {sys_id}: {response.status_code} {response.text}")
    return False

