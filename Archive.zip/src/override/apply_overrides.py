import json
import boto3
from boto3.dynamodb.types import TypeDeserializer
from logger import logger

STATUS_TABLE = "eqa-status-overwrite-table"
PROCESSING_TABLE = "eqa-cdr-processing-table"

def _scan_all(table):
    items = []
    resp = table.scan()
    items.extend(resp.get("Items", []))
    while resp.get("LastEvaluatedKey"):
        resp = table.scan(ExclusiveStartKey=resp["LastEvaluatedKey"])
        items.extend(resp.get("Items", []))
    return items

def _to_bool(result):
    val = (result or "").strip().lower()
    return val in ("pass", "passed", "true")

def _parse_results(raw):
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except Exception:
            return []
    if isinstance(raw, list):
        return raw
    if isinstance(raw, dict):
        try:
            val = TypeDeserializer().deserialize(raw)
        except Exception:
            val = raw.get("S")
        if isinstance(val, str):
            try:
                return json.loads(val)
            except Exception:
                return []
        if isinstance(val, list):
            return val
        return []
    return []

def _norm_control_id(v):
    if not v:
        return ""
    return str(v).strip().lower()

def apply_overrides():
    dynamo = boto3.resource("dynamodb")
    status_table = dynamo.Table(STATUS_TABLE)
    processing_table = dynamo.Table(PROCESSING_TABLE)

    overrides = _scan_all(status_table)
    total = len(overrides)
    updated = 0
    skipped = 0

    for o in overrides:
        identifier = o.get("identifier")
        control_id = o.get("control")
        override_result = o.get("override_result")
        if not identifier or not control_id:
            skipped += 1
            continue
        passed = _to_bool(override_result)
        norm_control = _norm_control_id(control_id)

        resp = processing_table.get_item(Key={"identifier": identifier})
        item = resp.get("Item")
        if not item:
            skipped += 1
            continue

        results = _parse_results(item.get("validation_results"))

        found = False
        for r in results:
            ctrl = r.get("control")
            if _norm_control_id(ctrl) == norm_control:
                r["passed"] = True if passed else False
                r["review_required"] = "No"
                found = True
                break

        if not found:
            # If control entry is missing, leave unchanged per requirement
            skipped += 1
            continue

        processing_table.update_item(
            Key={"identifier": identifier},
            UpdateExpression="SET #validation_results = :results",
            ExpressionAttributeNames={"#validation_results": "validation_results"},
            ExpressionAttributeValues={":results": json.dumps(results)},
        )
        updated += 1

    summary = {"status": "apply_overrides", "total": total, "updated": updated, "skipped": skipped}
    logger.info(summary)
    return summary

if __name__ == "__main__":
    print(json.dumps(apply_overrides(), indent=2))
