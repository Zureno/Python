import os
import json
import boto3
from botocore.exceptions import ClientError
from config import CONFIG
from logger import logger

from fetch_api_data import fetch_active_overrides
from write_overrides_to_table import write_overrides_to_table
from apply_overrides import apply_overrides
from update_ticket import close_snow_ticket

def get_snow_secrets():
    if CONFIG["ENV"] == "dev":
        REGION = os.environ['AWS_REGION']
    else:
        REGION = "us-east-1"
    secret_name = "eqa-snow-secret"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        logger.error("In get_secret function")
        raise e
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

def handler(event=None, context=None):
    secrets = get_snow_secrets()
    snow_url = secrets.get("snow_url")
    username = secrets.get("snow_user")
    password = secrets.get("snow_password")

    overrides = fetch_active_overrides(snow_url, username, password)

    for o in overrides:
        logger.info({
            "status": "received_ticket",
            "sys_id": o.get("sys_id"),
            "ritm": o.get("ritm"),
            "control_id": o.get("control_id"),
            "identifier": o.get("identifier"),
        })

    write_result = write_overrides_to_table(overrides)

    written_items = write_result.get("written_items", []) if isinstance(write_result, dict) else []
    closed = 0
    for item in written_items:
        sys_id = item.get("sys_id")
        if not sys_id:
            continue
        comment = (
            f"Override recorded for control {item.get('control_id')} on "
            f"identifier {item.get('identifier')} (RITM {item.get('ritm')}). Closing as processed."
        )
        try:
            if close_snow_ticket(sys_id, comment, snow_url, username, password):
                closed += 1
                logger.info({
                    "status": "closed_ticket",
                    "sys_id": sys_id,
                    "ritm": item.get("ritm"),
                    "control_id": item.get("control_id"),
                    "identifier": item.get("identifier"),
                })
        except Exception as e:
            logger.error({"status": "close_ticket_error", "sys_id": sys_id, "error": str(e)})

    result = apply_overrides()
    print("override processing summary:", json.dumps({**result, "tickets_closed": closed}))



if __name__ == "__main__":
    handler({}, {})
