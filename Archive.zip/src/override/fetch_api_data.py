import requests
from requests.auth import HTTPBasicAuth
from datetime import datetime, timezone
from logger import logger

API_PATH = "/api/sn_compliance/aws_control_automation/get_ucas_override_request_data"

# moved current date computation into function to avoid local-time and warm-start issues

def extract_control_id(variables):
    standard = variables.get("control_standard_to_augment")
    if not standard:
        return None
    control_obj = variables.get(f"{standard.lower()}_control_objective")
    return control_obj.split(" - ")[-1] if control_obj else None

def fetch_active_overrides(snow_url, username, password):
    now_formatted = datetime.now(timezone.utc).date().isoformat()
    url = f"{snow_url}{API_PATH}"
    params = {
        "active": "true",
        "state": "2"
        }
    response = requests.get(
        url,
        params=params,
        auth=HTTPBasicAuth(username, password),
        headers={"Accept": "application/json"},
        timeout=30,
    )
    response.raise_for_status()
    data = response.json().get("result", {}).get("data", [])
    return [
        {
            "ritm": r.get("ritm_number"),
            "sys_id": r.get("sys_id"),
            "identifier": (r.get("variables") or {}).get("identifier"),
            "control_id": extract_control_id(r.get("variables") or {}),
            "override_result": (r.get("variables") or {}).get("desired_result"),
            "description": r.get("description") or (r.get("variables") or {}).get("description"),
            "opened_at": r.get("opened_at"),
            "state": r.get("state"),
            "last_processed": now_formatted,
        }
        for r in data
    ]

