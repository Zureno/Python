#placeholder code for IaC deployment
import json
import logging
import os
import boto3
import sys
from botocore.exceptions import ClientError
from datetime import datetime

#Add parent directory to path to import from validation module

parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) 
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)


from validation.shared.process import process_validation ## this is main boss function.
from validation.shared.config import CONFIG ## this is the settings menu: dev vs prod, API vs datanase etc 
from validation.shared.validator_generator import ValidatorGenerator   # decides what should we drive to data lake or call an API.
from validation.shared.controls import Control # Grabs control definition from DynamoDB.
from validation.data.findings_data import FindingsData #Grabs findings data from Athena. This is the data we want to validate.
from validation.validator.findings_validator import FindingsValidator # This is the actual validation engine that takes in the controls and the findings and runs the validation logic.

from logger import logger
from config import CONFIG as LOCAL_CONFIG

if CONFIG["ENV"] == "dev":
    REGION = os.environ.get('AWS_REGION', 'us_east-1')
else:
    REGION ="us-east-1"

## AWS Power tools

dynamodb = boto3.resource('dynamodb', region_name=REGION) #our database
logger.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))# Turn up the volumes of the logs.

TABLE_NAME = None
table = None
ENV = CONFIG["ENV"]

def inint_config():

    # Connect DynamoDB

    global TABLE_NAME, table
    if TABLE_NAME is None:
        TABLE_NAME = "eqa-cdr-processing-table"
        table = dynamodb.Table(TABLE_NAME)

def write_validation_results(identifier, validation_results):
    # 

#def handler(event, context):
#    print("Lambda IaC infratsructure test successfull")
#    return {
#        "message": "hello world"
#    }
 