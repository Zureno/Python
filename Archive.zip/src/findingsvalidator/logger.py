from aws_lambda_powertools import Logger

logger = Logger(service="findings-validator-lambda")
