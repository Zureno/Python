import requests
import json
import boto3
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from botocore.exceptions import ClientError
from config import CONFIG
from datetime import datetime
from logger import logger

def get_snow_secrets():
    if CONFIG["ENV"] == "dev":
        REGION = os.environ['AWS_REGION']
    else:
        REGION = "us-east-1"
    secret_name = "eqa-snow-secret"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        logger.error("In get_secret function")
        raise e
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

def get_entities_and_supporting_data(secrets, params=None):
    snow_url = secrets['snow_url']
    username = secrets['snow_user']
    password = secrets['snow_password']
    url = f"{snow_url}/api/sn_compliance/aws_control_automation/get_entities_and_supporting_data"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    if params is None:
        params = {}
    page_no = 0
    page_size = params.get("page_size", 1000)
    all_results = []
    while True:
        page_params = params.copy()
        page_params["page_no"] = page_no
        page_params["page_size"] = page_size
        response = requests.get(
            url,
            headers=headers,
            params=page_params,
            auth=(username, password)
        )
        if response.status_code == 200:
            data = response.json()
            results = data.get("result", [])
            if not results:
                break
            all_results.extend(results)
            if len(results) < page_size:
                break
            page_no += 1
        else:
            logger.warning(f"Error: {response.status_code} - {response.text}")
            break
    return {"result": all_results}

def to_bool(val):
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        return val.strip().lower() in ["true", "yes", "1"]
    if isinstance(val, int):
        return val == 1
    return False

def get_ot_identifier(name):
    # If entity is OT infra, appci is unique identifier, parsed from entity name
    # Example entity name for OT infra: "OT Infra for Baggage Handling System (BHS)"
    # Make output BHS - OT so it doesn't overwrite application entity record
    match = re.search(r'\(([^)]+)\)', name)
    if match:
        identifier = match.group(1) + ' - OT Infra'
    else: 
        identifier = ""
    return identifier

def extract_fields(data, entity_types_lookup=None):
    if isinstance(data, dict) and "result" in data:
        entities = data["result"]
    else:
        entities = data
    extracted = []
    for item in entities:
        entitySysID = item.get("entitySysID")
        Obj = item.get("Obj", {})
        Entity = item.get("entity", {})
        dast_scannable = Obj.get("u_dast_scannable", "")
        sast_scannable = Obj.get("u_sast_scannable", "")

        ot_name = Entity.get("name", "")
        is_ot = 'OT Infrastructure' in ot_name
        if is_ot and ot_name:
            identifier = get_ot_identifier(ot_name)
        else:
            identifier = Obj.get("u_application_key", "")
        

        if not (len(identifier) == 3 or "OT Infra" in identifier):
            continue        

        dast_scannable_bool = to_bool(dast_scannable)
        sast_scannable_bool = to_bool(sast_scannable)

        # Extract and map fields
        operational_status = Obj.get("Operational status", "") # "In Production", "Retired", "Implementing"
        source_code_ownership = Obj.get("Source Code Ownership", "") # "Internal UAL", "Vendor"
        inherent_risk_value = Obj.get("Security Level", "") # "SL1", "SL2", "SL3", "Unknown Missing Data"
        app_hosting = Obj.get("u_app_hosting", "")
        consumption_method = Obj.get("u_consumption_method", "")
        data_classification = Obj.get("u_data_classification", "")
        consumer_type = Obj.get("consumer_type", "")
        service_classification = Obj.get("service_classification", "")
        sia_application_exposure = Obj.get("u_sia_application_exposure", "")
        connectivity = Obj.get("u_connectivity", "")
        structure = Obj.get("u_structure", "")
        regulatory_application = Obj.get("u_regulatory_application", "") # True/False
        aossp = Obj.get("AOSSP", "") # "Yes", "No"
        faa_true = Obj.get("u_faa", "") # True/False
        aircraft_data = Obj.get("u_aircraft_data", "") # True/False
        sox = Obj.get("u_sox", "") # True/False

        # Build attributes as a list of dicts with field names as keys
        attributes = []
        field_map = {
            "operationalstatus": operational_status,
            "sourcecodeownership": source_code_ownership,
            "inherentriskvalue": inherent_risk_value,
            "apphosting": app_hosting,
            "consumptionmethod": consumption_method,
            "dataclassification": data_classification,
            "consumertype": consumer_type,
            "serviceclassification": service_classification,
            "siaapplicationexposure": sia_application_exposure,
            "connectivity": connectivity,
            "structure": structure,
            "regulatoryapplication": regulatory_application,
            "aossp": aossp,
            "faatrue": faa_true,
            "aircraftdata": aircraft_data,
            "sox": sox,
            "dastscannable": dast_scannable,
            "sastscannable": sast_scannable
        }
        for key, val in field_map.items():
            if val:
                attributes.append({"name": key, "value": val})

        # Extract tags, default to blank array if not present
        tags = Obj.get("tags", [])
        if not isinstance(tags, list):
            tags = []

        if is_ot:
            attributes = [{"name": "OT Infrastructure (Automation)", "value": "OT Infrastructure (Automation)"}]

        if identifier and entitySysID:
            extracted.append({
                "identifier": identifier,
                "dast_scannable": dast_scannable_bool,
                "entitySysID": entitySysID,
                "attributes": attributes,
                "tags": tags,
                "sast_scannable": sast_scannable_bool
            })
    return extracted


def scan_all(dynamo, table_name):
    items = []
    response = dynamo.scan(TableName=table_name)
    items.extend(response.get('Items', []))
    while 'LastEvaluatedKey' in response:
        response = dynamo.scan(
            TableName=table_name,
            ExclusiveStartKey=response['LastEvaluatedKey']
        )
        items.extend(response.get('Items', []))
    return items

def write_to_processing_table(items, table_name="eqa-cdr-processing-table", max_workers=20):
    dynamo = boto3.client('dynamodb')
    existing_items = scan_all(dynamo, table_name)
    existing_identifiers = {item['identifier']['S'] for item in existing_items if 'identifier' in item}
    updated_at = str(int(datetime.now().timestamp()))

    def upsert_item(item):
        identifier = item["identifier"]
        # Convert attributes to DynamoDB format: [{'M': {'name': {'S': ...}, 'value': {'S': ...}}}, ...]
        attributes_list = [{'M': {'name': {'S': et['name']}, 'value': {'S': et['value']}}} for et in item["attributes"]]
        # Convert tags to DynamoDB format: [{'S': tag}, ...]
        tags_list = [{'S': tag} for tag in item.get("tags", [])]
        if identifier in existing_identifiers:
            update_expr = "SET dast_scannable = :dast, attributes = :attrs, tags = :tags, sast_scannable = :sast, enabled = :enabled"
            expr_attr_values = {
                ":dast": {'BOOL': item["dast_scannable"]},
                ":attrs": {'L': attributes_list},
                ":tags": {'L': tags_list},
                ":sast": {'BOOL': item["sast_scannable"]},
                ":enabled": {'BOOL': False}
            }
            dynamo.update_item(
                TableName=table_name,
                Key={'identifier': {'S': identifier}},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=expr_attr_values
            )
        else:
            dynamo.put_item(
                TableName=table_name,
                Item={
                    "identifier": {'S': identifier},
                    "dast_scannable": {'BOOL': item["dast_scannable"]},
                    "enabled": {'BOOL': False},
                    "entitySysID": {'S': item["entitySysID"]},
                    "attributes": {'L': attributes_list},
                    "tags": {'L': tags_list},
                    "sast_scannable": {'BOOL': item["sast_scannable"]},
                    "validation_queue": {'S': "[]"},
                    "validation_results": {'S': "[]"},
                    "updated_at": {'N': updated_at},
                    "last_processed": {'S': "01/01/1900"}
                }
            )

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(upsert_item, item) for item in items]
        for future in as_completed(futures):
            future.result()


def handler(event=None, context=None):
    secrets = get_snow_secrets()
    data = get_entities_and_supporting_data(secrets)

    # with open("entities_supporting_data_dump.json", "w", encoding="utf-8") as f:
    #     json.dump(data, f, indent=2)
    # print("Raw API data dumped to entities_supporting_data_dump.json")

    # REMOVED: entity_types_lookup and build_entity_types_lookup
    extracted = extract_fields(data)
    max_workers = 20
    write_to_processing_table(extracted, max_workers=max_workers)
    logger.info({"status": "success", "processed": len(extracted)})

if __name__ == "__main__":
    event = {}
    context = {}
    handler(event, context)