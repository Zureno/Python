import boto3
from boto3.dynamodb.conditions import Attr
from botocore.exceptions import ClientError
import json
import logging
import os
from logger import logger

logger = logging.getLogger(__name__)
logger.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))

HEADERS = {'Content-Type': 'application/json'}

CONFIG = {
    "ENV": "local" # Change to local for local testing 
}

if CONFIG["ENV"] == "dev":
    REGION = os.environ['AWS_REGION']
else:
    REGION = "us-east-1"

def get_secret(secret_name):
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        logger.error("In get_secret function")
        raise e
    
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)


def handler(event, context):

    logger.info("Starting dispatch lambda..")

    sns = boto3.client('sns')
    service_now_secrets = get_secret("eqa-snow-secret")
    datalake_arn = service_now_secrets['datalake_topic_arn']

    dynamo = boto3.resource('dynamodb')
    processing_table = dynamo.Table("eqa-cdr-processing-table")
    items = []

    # Retrieve identifier & controls that need to be validated
    response = processing_table.scan(
        ProjectionExpression = "identifier, validation_queue",

        #Only pull if there are controls to validate
        FilterExpression=Attr("validation_queue").exists() & Attr("validation_queue").ne("[]")
    )
    items.extend(response.get("Items", []))

    # Avoid 1MB limit via pagination
    while "LastEvaluatedKey" in response:
        response = processing_table.scan(
            ProjectionExpression = "identifier, validation_queue",

            #Only pull if there are controls to validate
            FilterExpression=Attr("validation_queue").exists() & Attr("validation_queue").ne("[]"),
            ExclusiveStartKey=response["LastEvaluatedKey"]
        )
        items.extend(response["Items"])

    #Send each entity to SNS queue for validation
    for item in items:
        # Build message to send to validation SNS queue
        validation_message = {
            "identifier": item["identifier"],
            "controls": item["validation_queue"]
        }
        
        json_data = json.dumps({"default": json.dumps(validation_message)})

        sns.publish(
            TargetArn=datalake_arn,
            Message=json_data,
            MessageStructure='json'
        )
    logger.info(f"Successfully published {len(items)}")

if __name__ == '__main__':
    handler({}, {})

