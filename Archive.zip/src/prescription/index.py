import boto3
import json
from botocore.exceptions import ClientError
import boto3
from datetime import datetime, timedelta
import math
import secrets
from collections import defaultdict
from logger import logger

print("Loading prescription Lambda...")
HEADERS = {'Content-Type': 'application/json'}

def extract_entity_types(item):
    logger.debug("extract_entity_types: start")
    # For both processing and control tables: attributes is a DynamoDB list of maps with name, value, and groupId
    key = 'attributes' if 'attributes' in item else None
    if key and key in item and item[key]:
        attr_field = item[key]
        if 'L' in attr_field and attr_field['L']:
            try:
                attributes = []
                for et in attr_field['L']:
                    if 'M' in et and 'name' in et['M'] and 'value' in et['M']:
                        name = et['M']['name']['S']
                        value = et['M']['value']['S']
                        groupId = int(et['M']['groupId']['N']) if 'groupId' in et['M'] and 'N' in et['M']['groupId'] else 1
                        if ',' in value:
                            for v in [v.strip() for v in value.split(',') if v.strip()]:
                                attributes.append({'name': name, 'value': v, 'groupId': groupId})
                        else:
                            attributes.append({'name': name, 'value': value, 'groupId': groupId})
                logger.debug("extract_entity_types: end")
                return attributes
            except Exception:
                logger.debug("extract_entity_types: end (exception)")
                return []
        logger.debug("extract_entity_types: end (no attributes)")
        return []
    logger.debug("extract_entity_types: end (no key)")
    return []

def match_by_group(entity_types, control_types):
    logger.debug("match_by_group: start")
    # Helper normalization: case-insensitive + trim whitespace
    def _norm(val):
        return str(val).strip().lower()

    # Flatten entity attributes with normalization for matching
    entity_attr_set = set((_norm(et['name']), _norm(et['value'])) for et in entity_types)

    # For each group in control, at least one attribute in that group must match with entity (AND across groups, OR within group)
    control_groups = defaultdict(list)
    for ct in control_types:
        control_groups[ct['groupId']].append(ct)

    entity_groups = defaultdict(list)
    for et in entity_types:
        entity_groups[et.get('groupId', 1)].append(et)

    for group_id, control_attrs in control_groups.items():
        # OR logic within group: any normalized attribute in control group matches any in entity attributes (ignoring groupId)
        group_match = any(
            (_norm(ca['name']), _norm(ca['value'])) in entity_attr_set
            for ca in control_attrs
        )
        if not group_match:
            logger.debug("match_by_group: end (no match)")
            return False
    logger.debug("match_by_group: end (match)")
    return True

def scan_all(dynamo, table_name):
    logger.debug(f"scan_all: start table={table_name}")
    items = []
    response = dynamo.scan(TableName=table_name)
    items.extend(response.get('Items', []))
    while 'LastEvaluatedKey' in response:
        response = dynamo.scan(
            TableName=table_name,
            ExclusiveStartKey=response['LastEvaluatedKey']
        )
        items.extend(response.get('Items', []))
    logger.debug(f"scan_all: end table={table_name} items={len(items)}")
    return items

def filter_recent_entities(entities):
    logger.debug("filter_recent_entities: start")
    one_week_ago = datetime.now() - timedelta(days=7)
    filtered = []
    for entity in entities:
        last_processed = entity.get('last_processed', {}).get('S')
        if last_processed:
            try:
                
                dt = datetime.strptime(last_processed, "%m/%d/%Y")
                if dt < one_week_ago:
                    filtered.append(entity)
            except Exception:
                continue

    logger.debug(f"filter_recent_entities: end filtered={len(filtered)}")
    return filtered

def filter_enabled_controls(controls):
    logger.debug("filter_enabled_controls: start")
    filtered = []
    for control in controls:
        enabled = control.get('enabled', {}).get('BOOL')
        if enabled is True:
            filtered.append(control)
    logger.debug(f"filter_enabled_controls: end filtered={len(filtered)}")
    return filtered

def filter_entities_to_run(entities, max_entities_to_run):
    logger.debug(f"filter_entities_to_run: start max_entities_to_run={max_entities_to_run}")
    entity_map = {}
    for entity in entities:
        enabled_field = entity.get('enabled', {})
        enabled = enabled_field.get('BOOL')
        identifier = entity.get('identifier', {}).get('S')
        if enabled is True and identifier:
            entity_map[identifier] = entity

    if len(entity_map) >= max_entities_to_run:
        logger.debug("filter_entities_to_run: end (enough enabled)")
        return list(entity_map.values())[:max_entities_to_run]

    remaining_entities = [
        entity for entity in entities
        if entity.get('identifier', {}).get('S') not in entity_map
    ]
    recent_entities = filter_recent_entities(remaining_entities)

    for i in range(len(recent_entities) - 1, 0, -1):
        j = secrets.randbelow(i + 1)
        recent_entities[i], recent_entities[j] = recent_entities[j], recent_entities[i]
    for entity in recent_entities:
        identifier = entity.get('identifier', {}).get('S')
        if identifier and identifier not in entity_map:
            entity_map[identifier] = entity
            if len(entity_map) >= max_entities_to_run:
                break

    logger.debug(f"filter_entities_to_run: end total={len(entity_map)}")
    return list(entity_map.values())

def clear_all_validation_queues(dynamo, table_name, entities):
    logger.debug(f"clear_all_validation_queues: start table={table_name} entities={len(entities)}")
    for entity in entities:
        identifier = entity.get('identifier', {}).get('S')
        if identifier:
            dynamo.update_item(
                TableName=table_name,
                Key={'identifier': {'S': identifier}},
                UpdateExpression='SET #vq = :empty',
                ExpressionAttributeNames={'#vq': 'validation_queue'},
                ExpressionAttributeValues={':empty': {'S': '[]'}}
            )
    logger.debug(f"clear_all_validation_queues: end table={table_name}")

def handler(event, context):
    logger.debug("handler: start")
    dynamo = boto3.client('dynamodb')
    try:
        entities = scan_all(dynamo, 'eqa-cdr-processing-table')
        clear_all_validation_queues(dynamo, 'eqa-cdr-processing-table', entities) # Comment out for single identifer test
        # entities = [e for e in entities if e.get('identifier', {}).get('S') == "EGU"] # Comment in for single identifer test
        # max_entities_to_run = math.ceil(len(entities) / 7)  
        # entities = filter_entities_to_run(entities, max_entities_to_run) # Comment out for single identifer test
        controls = scan_all(dynamo, 'eqa-control-table')
        controls = filter_enabled_controls(controls)
        for entity in entities:
            identifier = entity['identifier']['S']
            entity_types = extract_entity_types(entity)
            control_list = []
            if entity_types:
                for control in controls:
                    control_entity_types = extract_entity_types(control)
                    # Match by groupId logic: OR within group, AND across groups
                    if control_entity_types:
                        match_found = match_by_group(entity_types, control_entity_types)
                        if match_found:
                            try:
                                validators = json.loads(control['validators']['S'])
                            except Exception:
                                validators = []
                            control_entry = {
                                "control": control['control']['S'],
                                "validators": validators
                            }
                            control_list.append(control_entry)
            dynamo.update_item(
                TableName='eqa-cdr-processing-table',
                Key={'identifier': {'S': identifier}},
                UpdateExpression='SET #vq = :queue',
                ExpressionAttributeNames={
                    '#vq': 'validation_queue'
                },
                ExpressionAttributeValues={
                    ':queue': {'S': json.dumps(control_list)}
                }
            )
        logger.info({"status": "success", "processed": len(entities)})
    except ClientError as e:
        logger.info({"status": "client error", "error": str(e)})
    except Exception as e:
        logger.info({"status": "error", "error": str(e)})
    logger.debug("handler: end")

if __name__ == "__main__":
    event = {}
    context = {}
    handler(event, context)

