#placeholder code for IaC deployment
def handler(event, context):
    print("Lambda IaC infratsructure test successfull")
    return {
        "message": "hello world"
    }
 