CONFIG = {
    "ENV": "dev" # Change to local for local testing
}
