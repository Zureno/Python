import boto3
import logging
import os
from config import CONFIG
from snow import NewSnowIntegration
from helpers.processor import process_one_identifier
from helpers.entity_handling import extract_app_key_from_entity_name, get_ot_identifier

"""
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..', 'src')))
from SourceDataLayer.snow import NewSnowIntegration
"""

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if not logger.handlers:
    h = logging.StreamHandler()
    h.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    h.setFormatter(formatter)
    logger.addHandler(h)

HEADERS = {"Content-Type": "application/json"}

if CONFIG["ENV"] == "dev":
    REGION = os.environ["AWS_REGION"]
else:
    REGION = "us-east-1"


def _identifier_from_snow(snow: NewSnowIntegration):
  """
  Fetch identifiers and their associated controls from ServiceNow.
  Returns a dictionary mapping identifiers to lists of controls.
  """
  
  # Pull indicators from ServiceNow and extract identifiers and controls
  indicators = snow.get_indicators() or []
    # logger.debug(indicators)
  identifier_to_controls = {}
  for ind in indicators:
    if ind.get("hasNext") is False:
        break
    entity_class = ind.get("entityClass", {}).get("displayName", "")
    entity_name = ind.get("entityName", "")
    if entity_class == "OT Infrastructure (Automation)":
        identifier = get_ot_identifier(entity_name)
    elif entity_class in ["Application", "Cloud Applications", "Non-Cloud Applications"]:
        identifier = extract_app_key_from_entity_name(entity_name)
    else:
        identifier = ""
    control = ind.get("controlReference", "").strip()
    if not identifier or not control:
        continue
    bucket = identifier_to_controls.setdefault(identifier, set())
    bucket.add(control)
  return identifier_to_controls


def handler(event, context):
    """Main Lambda handler to process identifiers from ServiceNow:"""
    try:
        dynamo = boto3.resource("dynamodb")
        snow = NewSnowIntegration()
    except Exception as e:
    # logger.error(f"Failed to initialize resources: {e}")
        return {"status": "error", "error": str(e)}
    
    try:
        indicators = snow.get_indicators() or []
        # with open("fetched_indicators.json", "w", encoding="utf-8") as f:
        #     json.dump(indicators, f, indent=2)
        identifier_to_controls = _identifier_from_snow(snow)
    except Exception as e:
        # logger.error(f"Error fetching identifiers: {e}")
        return {"status": "error", "error": str(e)}

    if not identifier_to_controls:
        # logger.info("No identifiers to process.")
        return {"status": "no_identifiers", "processed": 0}

    summaries = {"processed": 0, "skipped": 0}
    details = []

    for identifier, allowed_controls in identifier_to_controls.items():
        try:
            result = process_one_identifier(dynamo, snow, identifier, allowed_controls)
        except Exception as e:
            # logger.error(f"Error processing identifier '{identifier}': {e}")
            result = {"identifier": identifier, "status": "error", "error": str(e)}
            summaries["skipped"] += 1
            details.append(result)
            continue

        details.append(result)
        if isinstance(result, dict) and result.get("status") == "completed":
            summaries["processed"] += 1
        else:
            summaries["skipped"] += 1

    return {"status": "ok", "summary": summaries, "details": details}


if __name__ == "__main__":
    event = {}
    context = {}
    handler(event, context)