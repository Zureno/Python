from config import CONFIG
import logging
from helpers.filters import is_cdr       
from helpers.dynamo_ops import control_exists, read_control_definition, upsert_result_item, reset_processing_item 
from helpers.pipeline import early_filter_identifier
from snow import NewSnowIntegration
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

if not logger.handlers:
    h = logging.StreamHandler()
    h.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    h.setFormatter(formatter)
    logger.addHandler(h)

def process_one_identifier(dynamo, snow, identifier, controls):
    """
    Process a single identifier: fetch validation results, filter, send to ServiceNow, and update the processing table.
    Returns a summary dict of the processing outcome.
    """

    # Early filtering based on identifier and controls returns a tuple (ok: bool, reason: str, item: dict)
    ok, reason, item = early_filter_identifier(dynamo, identifier, controls)
    if not ok:
        # logger.info(f"[SKIP] {identifier}: {reason}")
        return {"identifier": identifier, "status": f"skipped_{reason}"}
    
    asset = item.get("entitySysID") or item.get("entitySysId")
    attributes = item.get("attributes")
    try:
        validation_results = item.get("validation_results", [])
    except Exception as e:
        # logger.error(f"Error parsing validation_results for identifier='{identifier}': {e}")
        validation_results = []
    
    allowed_controls = set(ctrl.strip() for ctrl in (controls or []) if isinstance(ctrl, str))
    all_results = []
    indicators_found = []
    indicators_not_found = []
    sent_any = False 

    for results in validation_results:
        control = results.get("control")
        passed = results.get("passed")
        avit = results.get("avit")
        evidence = results.get("evidence")
        raw = results.get("raw_evidence")
        template_sys_id = None
        # Further filtering non-existing controls
        if allowed_controls and control not in allowed_controls:
            # print(f"[SKIP] Control '{control}' not in allowed controls for identifier '{identifier}', skipping.")
            continue
        # if not is_cdr(control):
        #     logger.info(f"[SKIP] Control '{control}' is not a CDR control, skipping.")
        #     continue
        if isinstance(control, dict) and "S" in control:
            control = control["S"]
        if not isinstance(control, str) or not control:
            # print(f"[SKIP] Control '{control}' is not a valid string, skipping.")
            continue
        if passed in ("SKIP_FAILURE", "SKIP_PASS"):
            # print(f"[SKIP] Control '{control}' has passed='{passed}', skipping.")
            continue
        # Enrich with control definition
        control_def = read_control_definition(dynamo, control) or {}
        description = control_def.get("description", "")
        chapter = control_def.get("chapter_name", "")
        result = {
            "control": {"S": control},
            "description": {"S": description},
            "chapter_name": {"S": chapter},
            "avit": {"S": avit},
            "indicator_id": {"S": ""}, # Update below if template found
            "pass": {"BOOL": bool(passed)},
            "evidence": {"S": evidence},
            "raw_evidence": {"S": raw},
        }
        all_results.append(result)
        # Map to ServiceNow template sys_id and send when valid (not SKIP_*)
        # For now, use a dummy template mapping for local testing [{control: "name", template_sys_id: "id"}], 
        template_sys_ids = snow.get_template_sys_ids(asset)

        for entry in template_sys_ids:
            if "controlReference" in entry and entry["controlReference"] == control:
                template_sys_id = entry["indicatorTemplateSysID"]
                break
                
        if template_sys_id:
            logger.info(f"[SNOW SEND] asset={asset} control={control} template={template_sys_id} pass={passed}, evidence={evidence}")
            snow.send_compliance_status(asset, control, template_sys_id, bool(passed), evidence, str(raw))
            indicators_found.append(control)
            sent_any = True
        else:
            indicators_not_found.append(control)

    # Upsert results into results table(idempotent) and reset processing item
    #TODO: The upsert_result_item is to be deleted in next release
    # upsert_result_item(dynamo, identifier, attributes, asset, all_results)
    reset_processing_item(dynamo, identifier)
    # logger.info(f"[DONE] Processed identifier='{identifier}': sent {len(indicators_found)} indicators, skipped {len(indicators_not_found)}")
    return {
        "identifier": identifier,
        "status": "completed",
        "sent": sent_any,
        "indicators_sent": indicators_found,
        "indicators_skipped": indicators_not_found
    }