import re
# Extracts the application key (e.g., BFM) from entityName string like '... (BFM)'
def extract_app_key_from_entity_name(entity_name):
    # Look for last set of parentheses
    match = re.search(r'\(([^)]+)\)\s*$', entity_name)
    if match:
        return match.group(1)
    return ""


def get_indicator_entity(indicator):
    entity_class = indicator.get("entityClass", {}).get("displayName", "")
    return entity_class

def get_entity_name(indicator):
    name = indicator.get("entityName", {})
    return name

def get_sast_scannable(indicator):
    sast_scannable = indicator.get("Obj", {}).get("u_sast_scannable", False) == "yes"
    return sast_scannable

def get_dast_scannable(indicator):
    dast_scannable = indicator.get("Obj", {}).get("u_dast_scannable", False) == "yes"
    return dast_scannable

def get_app_identifier(indicator):
    # If entity is application, appci is unique identifier
    identifier = indicator.get("Obj", {}).get("u_application_key", "")
    return identifier

def get_ot_identifier(name):
    # If entity is OT infra, appci is unique identifier, parsed from entity name
    # Example entity name for OT infra: "OT Infra for Baggage Handling System (BHS)"
    # Make output BHS - OT so it doesn't overwrite application entity record
    match = re.search(r'\(([^)]+)\)', name)
    if match:
        identifier = match.group(1) + ' - OT Infra'
    else: 
        identifier = ""
    return identifier

def get_hostname(indicator):
     # If entity class is not Apps/OT Infra, try to pull the hostname as the unique identifier
    identifier = indicator.get("Obj", {}).get("name", "")
    return identifier

# Unique identifier is the datapoint that's used to query security metadata for the entity
# from Github, Harness, other security tool APIs, and Athena tables
def derive_unique_identifier(indicator, entity_types):
    # Handle entity classes for applications
    scannable = ["Application", "Non-Cloud Applications", "Cloud Applications"]
    ot = ["OT Infrastructure (Automation)"]
    if any(sub in item["name"] for item in entity_types for sub in scannable):
       identifier = get_app_identifier(indicator)       

    # Handle entity class for OT infrastructure
    
    elif any(sub == item["name"] for item in entity_types for sub in ot):
        entity_name = get_entity_name(indicator)
        identifier = get_ot_identifier(entity_name)
    
    # Handle non-app / OT entity classes
    # TODO: Make separate conditional statements with more explicit entity class checks  (pending info from GRC)
    else:
        identifier = get_hostname(indicator)

    return identifier
        


                
                                   