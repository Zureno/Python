from __future__ import annotations
from datetime import datetime, timedelta
import logging
import os

logger = logging.getLogger(__name__)
logger.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))

if not logger.handlers:
    h = logging.StreamHandler()
    h.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    h.setFormatter(formatter)
    logger.addHandler(h)

# Functions to check freshness and control existence (moved inside handler to avoid global scope issues)
def is_fresh(date_str, days=14):
    """Return True if the date string s (MM/DD/YYYY) is within the last 'days'."""
    if not date_str:
        return False
    try:
        dt = datetime.strptime(date_str, "%m/%d/%Y")
    except Exception as e:
        logger.warning(f"[SKIP] invalid last_processed='{date_str}' ({e})")
        return False
    return (datetime.now() - dt) <= timedelta(days=days)

def is_cdr(control_name):
    """Check if control name starts with 'CDR-'"""
    return isinstance(control_name, str) and control_name.startswith("CDR-")