from __future__ import annotations
import json
from datetime import datetime
from typing import Any, Dict, Optional
from helpers.filters import is_fresh
from logger import logger

# Table names
PROCESSING_TABLE = "eqa-cdr-processing-table"
CONTROLS_TABLE = "eqa-control-table"
RESULTS_TABLE = "eqa-cdr-results-table"

# Reads
def get_processing_item(dynamo_resource, identifier: str) -> Dict[str, Any] | None:
    """Fetch one row from the processing table by identifier."""
    table = dynamo_resource.Table(PROCESSING_TABLE)
    response = table.get_item(Key={"identifier": identifier})
    return response.get("Item")

# def list_candidate_identifiers(dynamo_resource) -> list[str]:
#     """List all identifiers from the processing table that are fresh."""
#     table = dynamo_resource.Table(PROCESSING_TABLE)
#     response = table.scan()
#     items = response.get("Items", [])
#     candidates = []
#     for item in items:
#         if item.get("enabled") is True and is_fresh(item.get("last_processed", "")):
#             candidates.append(item["identifier"])
#     return candidates

def _load_control_set(dynamo_resource) -> set[str]:
    """Load all control names from the controls table into a set for quick lookup."""
    table = dynamo_resource.Table(CONTROLS_TABLE)
    controls = set()
    response = table.scan(ProjectionExpression="#C", ExpressionAttributeNames={"#C": "control"})
    for item in response.get("Items", []):
        if isinstance(item.get("control"), str):
            controls.add(item["control"])
    while "LastEvaluatedKey" in response:
        response = table.scan(
            ProjectionExpression="#C",
            ExpressionAttributeNames={"#C": "control"},
            ExclusiveStartKey=response["LastEvaluatedKey"],
        )
        for item in response.get("Items", []):
            if isinstance(item.get("control"), str):
                controls.add(item["control"])
    return controls

def control_exists(dynamo_resource, controls: list[str]) -> bool:
    """return True if all controls exist in the controls table."""
    if not controls:
        logger.warning("Control_exists got empty controls list")
        return False
    valid_controls = _load_control_set(dynamo_resource)

    for control in controls:
        if not isinstance(control, str) or not control.strip() or control.strip() not in valid_controls: 
            logger.warning(f"Control_exists: {control} ({type(control)})")
            return False
    return True


def read_control_definition(dynamo_resource, control_name: str) -> Dict[str, Any] | None:
    """
    Fetch the control definition by control name.
    Returns None if not found or on error, otherwise returns the item dict."""
    if not isinstance(control_name, str) or not control_name:
        logger.warning(f"Read_control_definition got non-string control_name: {control_name} ({type(control_name)})")
        return None
    table = dynamo_resource.Table(CONTROLS_TABLE)
    response = table.get_item(Key={"control": control_name})
    return response.get("Item")

# Writes
def upsert_result_item(dynamo_resource, identifier: str, attributes, asset: str, results: list[Dict[str, Any]]) -> None:
    """
    Insert or update the results row in RESULTS_TABLE.
    Uses a simple "upsert" pattern: update if exists, else insert
    """
    table = dynamo_resource.Table(RESULTS_TABLE)
    now_str = datetime.now().isoformat(timespec="seconds")

    existing = table.get_item(Key={"identifier": identifier})
    if "Item" in existing:
        # Update existing item
        table.update_item(
            Key={"identifier": identifier},
            UpdateExpression="SET  results = :r, last_updated = :lu",
            ExpressionAttributeValues={
                ":r": results,
                ":lu": now_str,
            },
        )
    else:
        # Insert new item
        table.put_item(
            Item={
                "identifier": identifier,
                "attributes": attributes,
                "asset": asset,
                "results": results,
                "created_at": now_str,
                "last_updated": now_str,
            }
        )

def reset_processing_item(dynamo_resource, identifier: str) -> None:
    """
    idempotent reset after successful processing:
    - set enabled to False
    - leave validation_results intact and reset validation_queue
    """
    table = dynamo_resource.Table(PROCESSING_TABLE)
    table.update_item(
        Key={"identifier": identifier},
        UpdateExpression="SET validation_queue = :queue",
        ExpressionAttributeValues={":queue": []},
    )