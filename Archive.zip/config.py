CONFIG = {
    "ENV": "local" # Change to local for local testing 
}
