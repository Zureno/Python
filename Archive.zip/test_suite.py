"""
FindingsValidator Test Suite
Tests multiple AppCIs automatically

Usage:
    python test_suite.py                    # Run all test cases
    python test_suite.py EQA                # Test specific AppCI
    python test_suite.py EQA BFM EBP        # Test multiple specific AppCIs
"""

import sys
import json
from index import handler

# All AppCIs from results.csv
ALL_APPCIS = [
    'AAP', 'ACZ', 'AJZ', 'AMP', 'ANU', 'AOU', 'AZF', 'AZK', 'BDZ', 'BEX',
    'BFM', 'BJB', 'BTR', 'BUM', 'BUZ', 'CBU', 'CEA', 'CNT', 'CQC', 'CQD',
    'CQO', 'CRH', 'CSP', 'CUZ', 'CZX', 'DHW', 'DTB', 'DVB', 'EAN', 'EBG',
    'EBP', 'EDS', 'EHF', 'EHO', 'EKH', 'ELE', 'ELV', 'EMI', 'EQA', 'EQC',
    'ESM', 'ETR', 'EUH', 'EWJ', 'EWL', 'EXQ', 'EYG', 'FEC', 'RDL', 'TOB'
]

# Test cases with known controls
# Add more test cases as you discover control mappings for each AppCI
TEST_CASES = [
    # Test Event 1: EQA (from your team)
    {
        "name": "EQA - OWASP-V12.5.2 - Invicti CWE 434",
        "identifier": "EQA",
        "control": "OWASP-V12.5.2",
        "validator": [{
            "type": "findings",
            "tool": "invicti",
            "scope": "CWE",
            "criteria": ["434"]
        }]
    },
    
    # Test Event 2: EBP (from your team)
    {
        "name": "EBP - OWASP-V5.5.4 - Veracode CWE 95 (skip_failure)",
        "identifier": "EBP",
        "control": "OWASP-V5.5.4",
        "skip_failure": True,
        "validator": [{
            "type": "findings",
            "tool": "veracode",
            "scope": "CWE",
            "criteria": ["95"]
        }]
    },
    
    # Test Event 3: BFM (example - adjust control and criteria as needed)
    {
        "name": "BFM - OWASP-V14.4.6 - Invicti CWE 79",
        "identifier": "BFM",
        "control": "OWASP-V14.4.6",
        "validator": [{
            "type": "findings",
            "tool": "invicti",
            "scope": "CWE",
            "criteria": ["79"]
        }]
    },
    
    # Add more test cases here as you discover control mappings
    # Format:
    # {
    #     "name": "APPCI - CONTROL - Description",
    #     "identifier": "APPCI",
    #     "control": "CONTROL_NAME",
    #     "validator": [{...}]
    # }
]


def run_test(test_case):
    """Run a single test case and return results"""
    test_name = test_case.pop('name')
    
    print("=" * 80)
    print(f" Running: {test_name}")
    print("=" * 80)
    print(f" Test Event:")
    print(json.dumps(test_case, indent=2))
    print()
    
    try:
        result = handler(test_case, None)
        print(f" Result:")
        print(json.dumps(result, indent=2))
        print()
        print(f" {test_name} - PASSED")
        return True
        
    except Exception as e:
        print(f" {test_name} - FAILED")
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_single_appci(appci, control=None, tool="invicti", criteria=None):
    """
    Quick test for a single AppCI with default or custom parameters
    
    Args:
        appci: AppCI identifier (e.g., "EQA")
        control: Control name (default: "OWASP-V12.5.2")
        tool: Tool name (default: "invicti")
        criteria: CWE criteria list (default: ["434"])
    """
    control = control or "OWASP-V12.5.2"
    criteria = criteria or ["434"]
    
    test_case = {
        "name": f"{appci} - {control} - {tool} CWE {criteria}",
        "identifier": appci,
        "control": control,
        "validator": [{
            "type": "findings",
            "tool": tool,
            "scope": "CWE",
            "criteria": criteria
        }]
    }
    
    return run_test(test_case)


def main():
    """Main test runner"""
    print()
    print(" FindingsValidator Test Suite")
    print("=" * 80)
    print()
    
    # Check if specific AppCIs were requested
    if len(sys.argv) > 1:
        requested_appcis = [arg.upper() for arg in sys.argv[1:]]
        
        # Validate requested AppCIs
        invalid = [a for a in requested_appcis if a not in ALL_APPCIS]
        if invalid:
            print(f" Invalid AppCI(s): {', '.join(invalid)}")
            print(f"Available AppCIs: {', '.join(ALL_APPCIS)}")
            return
        
        print(f" Testing specific AppCIs: {', '.join(requested_appcis)}")
        print()
        
        # Run quick tests for requested AppCIs
        results = []
        for appci in requested_appcis:
            success = test_single_appci(appci)
            results.append((appci, success))
        
    else:
        # Run all predefined test cases
        print(f" Running {len(TEST_CASES)} test case(s)")
        print()
        
        results = []
        for test_case in TEST_CASES:
            success = run_test(test_case.copy())
            results.append((test_case['name'], success))
            print()
    
    # Summary
    print()
    print("=" * 80)
    print(" Test Summary")
    print("=" * 80)
    
    passed = sum(1 for _, success in results if success)
    failed = len(results) - passed
    
    for name, success in results:
        status = " PASS" if success else " FAIL"
        print(f"{status} - {name}")
    
    print()
    print(f"Total: {len(results)} | Passed: {passed} | Failed: {failed}")
    print("=" * 80)
    
    # List all available AppCIs
    print()
    print(" Available AppCIs in results.csv:")
    print(", ".join(ALL_APPCIS))
    print()
    print(f" Tip: Run 'python test_suite.py EQA BFM' to test specific AppCIs")
    print()


if __name__ == "__main__":
    main()
