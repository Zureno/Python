"""
Findings validation — compare collected findings against validator criteria
"""

import re
from logger import logger


def validate_findings(validator: dict, findings_data: list[dict]) -> bool:
    """
    Determine whether the findings validator passes or fails.
    
    Args:
        validator:      The validator definition dict, e.g.
                        {"type": "findings", "tool": "invicti", "scope": "CWE", "criteria": ["434"]}
        findings_data:  List of findings returned by data.get_findings_data()
    
    Returns:
        True  → PASS (no matching vulnerabilities found)
        False → FAIL (matching vulnerabilities exist)
    
    Logic:
        - If criteria matches findings → FAIL (vulnerabilities exist)
        - If no matches → PASS (secure)
    """
    criteria = validator.get("criteria", [])
    scope = validator.get("scope", "").lower()
    tool = validator.get("tool", "").lower()
    
    if not criteria:
        logger.warning("No criteria specified in validator, defaulting to PASS")
        return True
    
    # Check each finding
    matching_findings = []
    
    for finding in findings_data:
        cwes_raw = finding.get("cwes", "")
        remediation = finding.get("remediation_description", "")
        scan_type_raw = finding.get("scan_type", "").upper()
        
        # Normalize scan type
        if scan_type_raw in ['STATIC', 'SAST', 'SCA']:
            scan_type = 'veracode'
        elif scan_type_raw in ['DYNAMIC', 'DAST']:
            scan_type = 'invicti'
        else:
            scan_type = scan_type_raw.lower()
        
        # Skip if tool doesn't match
        if tool != "both" and tool != scan_type:
            continue
        
        # CWE-based validation
        if scope == "cwe":
            # Extract CWE numbers from cwes field
            cwes_str = str(cwes_raw).replace('[', '').replace(']', '').replace("'", '').replace('"', '')
            cwe_numbers = []
            for part in cwes_str.split(','):
                part = part.strip()
                match = re.search(r'(?:CWE-)?(\d+)', part)
                if match:
                    cwe_numbers.append(match.group(1))
            
            # Check if any criteria CWE matches
            for crit in criteria:
                crit_str = str(crit).strip()
                crit_match = re.search(r'(?:CWE-)?(\d+)', crit_str)
                if crit_match:
                    crit_num = crit_match.group(1)
                    if crit_num in cwe_numbers:
                        matching_findings.append(finding)
                        logger.info(
                            f"CWE match found - CWE: {crit_num}, "
                            f"display_name: {finding.get('display_name', 'N/A')}"
                        )
                        break
        
        # Remediation description-based validation
        else:
            remediation_norm = str(remediation).strip().lower()
            for crit in criteria:
                crit_norm = str(crit).strip().lower()
                if crit_norm in remediation_norm:
                    matching_findings.append(finding)
                    logger.info(
                        f"Remediation match found - criteria: {crit}, "
                        f"display_name: {finding.get('display_name', 'N/A')}"
                    )
                    break
    
    # Determine pass/fail
    if matching_findings:
        logger.info(f"Findings validation FAILED — {len(matching_findings)} matching vulnerabilities found")
        return False
    else:
        logger.info("Findings validation PASSED — no matching vulnerabilities found")
        return True
