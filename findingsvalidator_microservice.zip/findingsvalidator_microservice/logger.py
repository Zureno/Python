"""
FindingsValidator Logger Configuration

Uses AWS Lambda Powertools for structured JSON logging
with automatic context injection (request_id, function_name, etc.)
"""

from aws_lambda_powertools import Logger

logger = Logger(service="findings-validator-lambda")
