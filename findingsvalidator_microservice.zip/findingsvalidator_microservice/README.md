# FindingsValidator Microservice

## Overview
Standalone microservice Lambda that validates security findings (SAST/DAST vulnerabilities) against control requirements.

## Architecture Pattern

This follows the **microservice pattern** (not the process_validation() pattern):

```
index.py (orchestrator)
  ↓
input.py (parse event)
  ↓
data.py (query Athena for findings)
  ↓
validate.py (run validation logic)
  ↓
output.py (build result & write to DynamoDB)
  ↓
helpers.py (Athena utilities)
```

## Files in This Folder

| File | Purpose |
|------|---------|
| `index.py` | Main Lambda handler - orchestrates the workflow |
| `input.py` | Parse event (SNS or direct invocation) |
| `data.py` | Query Athena for findings data |
| `validate.py` | Findings validation logic (CWE matching) |
| `output.py` | Build result dict & write to DynamoDB |
| `helpers.py` | Athena query utilities |
| `config.py` | Environment configuration |
| `logger.py` | AWS Lambda Powertools logger |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container build instructions |
| `__init__.py` | Python package marker |

## Input Format

### Test Event 1: Basic Validation
```json
{
  "identifier": "EQA",
  "control": "OWASP-V12.5.2",
  "validator": [
    {
      "type": "findings",
      "tool": "invicti",
      "scope": "CWE",
      "criteria": ["434"]
    }
  ]
}
```

### Test Event 2: With skip_failure
```json
{
  "identifier": "EBP",
  "control": "OWASP-V5.5.4",
  "skip_failure": true,
  "validator": [
    {
      "type": "findings",
      "tool": "veracode",
      "scope": "CWE",
      "criteria": ["95"]
    }
  ]
}
```

## Expected Output Format

```json
{
  "control": "OWASP-V12.5.2",
  "passed": true,
  "avit": [],
  "number": 1,
  "confidence": "medium",
  "validations": [{
    "type": "findings",
    "tool": "invicti",
    "scope": "CWE",
    "criteria": ["434"],
    "identifier": "EQA",
    "name": "OWASP-V12.5.2",
    "status": "PASS"
  }],
  "raw_evidence": "Validation of requirement OWASP-V12.5.2 for AppCI EQA has passed because the following criteria passed: ['434']",
  "evidence": "This requirement has passed; no action is required.",
  "finding_ids": "",
  "review_required": "No"
}
```

## Testing

### Local Testing
```bash
# Set environment to dev
# Edit config.py: CONFIG = {"ENV": "dev"}

# Install dependencies
pip install -r requirements.txt

# Configure AWS credentials
aws configure

# Run the handler
python index.py
```

The test events are already configured in `index.py` at the bottom.

### Comparing Results

1. Run the Lambda with test event
2. Check output matches expected output **exactly**
3. Query DynamoDB `eqa-validation-results-table` to verify write
4. Compare against production results

## Key Differences from Process_Validation Pattern

| Feature | Microservice (This) | Process_Validation |
|---------|---------------------|-------------------|
| Entry point | `index.py` handler | Calls `process_validation()` |
| Data source | `data.py` (Athena queries) | Shared modules |
| Validation | `validate.py` (standalone) | Shared validators |
| Output table | `eqa-validation-results-table` | `eqa-cdr-processing-table` |
| Result format | Microservice format | Monolith format |

## DynamoDB Tables

### eqa-validation-results-table
**Keys:**
- `identifier` (PK) - AppCI identifier
- `control#validator` (SK) - Composite sort key

**Attributes:**
- `result` - JSON string of validation result
- `last_processed` - Date string

## Required IAM Permissions

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:UpdateItem"
      ],
      "Resource": "arn:aws:dynamodb:*:*:table/eqa-validation-results-table"
    },
    {
      "Effect": "Allow",
      "Action": [
        "athena:StartQueryExecution",
        "athena:GetQueryExecution",
        "athena:GetQueryResults"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject"
      ],
      "Resource": "arn:aws:s3:::eqa-udcrm-datalake-bucket-*/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "ssm:GetParameter"
      ],
      "Resource": "arn:aws:ssm:*:*:parameter/eqa/udcrm-control-automation/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
```

## Lambda Configuration

```yaml
Function Name: findingsvalidator
Runtime: Python 3.13 (Container)
Memory: 1024 MB
Timeout: 900 seconds (15 minutes)
```

## Deployment

```bash
# Build Docker image
docker build -t findingsvalidator .

# Tag for ECR
docker tag findingsvalidator:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/findingsvalidator:latest

# Push to ECR
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/findingsvalidator:latest

# Update Lambda
aws lambda update-function-code \
  --function-name findingsvalidator \
  --image-uri <account-id>.dkr.ecr.us-east-1.amazonaws.com/findingsvalidator:latest
```

## Validation Logic

**PASS Criteria:**
- No vulnerabilities found matching the criteria (CWE or remediation keywords)

**FAIL Criteria:**
- One or more vulnerabilities found matching the criteria

**CWE Matching:**
- Extracts CWE numbers from findings
- Compares against criteria CWE list
- Matches tool (veracode/invicti/both)

## Timeline

- **End of Week:** Self-testing complete
- **Next Week:** Cross-team testing

## Contact

Security Engineering Team
