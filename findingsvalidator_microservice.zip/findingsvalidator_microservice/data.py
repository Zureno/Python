"""
Data collection — query Athena for security findings/vulnerabilities
"""

from datetime import datetime, timedelta
from logger import logger
from helpers import execute_athena_query, wait_for_query, get_query_results


# ---------------------------------------------------------------------------
# Athena constants
# ---------------------------------------------------------------------------
DATABASE = "appsec_database_for_datalake_shared_resources"
TABLE = "vipr_findings_shared"


def _q(name: str) -> str:
    """Quote an Athena identifier."""
    return f'"{name}"'


# ---------------------------------------------------------------------------
# Data collection — query Athena for findings
# ---------------------------------------------------------------------------
def get_findings_data(appci: str, validator: dict) -> list[dict]:
    """
    Query the VIPR findings datalake table for *appci* and return matching findings.
    
    Args:
        appci: Application CI identifier
        validator: Validator config with tool, scope, criteria
        
    Returns:
        List of finding records (dicts) from Athena
        
    Raises on missing appci or Athena errors.
    """
    if not appci:
        raise ValueError("Parameter appci is mandatory")
    
    tool = validator.get("tool", "").lower()
    scope = validator.get("scope", "").lower()
    
    # Determine which tools to query based on validator tool
    tools = []
    if tool in ["veracode", "sast"]:
        tools.append("Veracode")
        date_cutoff = datetime.now() - timedelta(days=365)
    elif tool in ["invicti", "dast"]:
        tools.extend(["Netsparker", "Invicti"])
        date_cutoff = datetime.now() - timedelta(days=90)
    elif tool == "both":
        tools.extend(["Veracode", "Netsparker", "Invicti"])
        date_cutoff = datetime.now() - timedelta(days=365)
    else:
        raise ValueError(f"Unsupported tool: {tool}")
    
    # Get yesterday's date for partition filter
    yesterday_ymd = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    
    # Build safe SQL
    safe_appci = str(appci).replace("'", "''")
    tools_str = ", ".join([f"'{t}'" for t in tools])
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    sql = (
        f"SELECT "
        f"  {_q('Appci')}, "
        f"  {_q('remediation_description')}, "
        f"  {_q('source')}, "
        f"  {_q('closed_timestamp')}, "
        f"  {_q('cwes')}, "
        f"  {_q('severity')}, "
        f"  {_q('scan_type')}, "
        f"  {_q('display_name')} "
        f"FROM {_q(DATABASE)}.{_q(TABLE)} "
        f"WHERE {_q('Appci')} = '{safe_appci}' "
        f"  AND {_q('source')} IN ({tools_str}) "
        f"  AND ({_q('closed_timestamp')} IS NULL "
        f"       OR {_q('closed_timestamp')} = 'NA' "
        f"       OR {_q('closed_timestamp')} >= '{now_str}') "
        f"  AND {_q('partition_0')} = '{yesterday_ymd}' "
    )
    
    qid = execute_athena_query(DATABASE, sql)
    if not qid:
        raise RuntimeError(
            f"Athena query failed to start for findings validator (appci={appci})"
        )
    
    wait_for_query(qid)
    logger.info(f"Athena query for findings validator (id={qid}) executed successfully")
    
    rows = get_query_results(qid)
    logger.info(f"Retrieved {len(rows)} findings for AppCI {appci}")
    
    return rows
