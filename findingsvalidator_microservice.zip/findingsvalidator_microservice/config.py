"""
FindingsValidator Configuration

Set ENV to control execution environment:
- "local": For local development/testing
- "dev": For development AWS environment
- "prod": For production AWS environment
"""

CONFIG = {
    "ENV": "dev"  # Change to "local" for local testing, "prod" for production
}
