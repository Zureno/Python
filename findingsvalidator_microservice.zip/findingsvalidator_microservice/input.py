"""
Parse the Lambda event → (identifier, control, validators list)
"""

import json
from logger import logger


def extract_lambda_input(event: dict) -> tuple[str, str, list]:
    """
    Supports two invocation formats:
    
    Format A — SNS-triggered:
        event["Records"][0]["Sns"]["Message"]  →  JSON string with
        { "identifier": "...", "control": "...", "validator": [...] }
    
    Format B — Direct / QA invocation:
        event itself is the dict above.
    
    Returns (identifier, control_name, validators_list).
    """
    # --- Format A: SNS wrapper ------------------------------------------------
    if "Records" in event:
        try:
            sns_message = event["Records"][0]["Sns"]["Message"]
            body = json.loads(sns_message)
            logger.info("Parsed SNS message body")
        except (KeyError, IndexError, json.JSONDecodeError) as exc:
            raise ValueError(f"Could not parse SNS message from event: {exc}") from exc
    
    # --- Format B: direct invocation ------------------------------------------
    else:
        body = event
        logger.info("Direct invocation body received")
    
    # --- Extract required fields ----------------------------------------------
    identifier: str = body.get("identifier", "")
    control: str = body.get("control", "")
    validators = body.get("validator")  # Note: key is "validator" (singular)
    skip_failure = body.get("skip_failure", False)
    
    # Coerce validators from JSON string if needed
    if isinstance(validators, str):
        try:
            validators = json.loads(validators)
        except json.JSONDecodeError as exc:
            raise ValueError(f"'validator' field is not valid JSON: {exc}") from exc
    
    # --- Validate mandatory fields --------------------------------------------
    missing = [
        name
        for name, val in [("identifier", identifier), ("control", control), ("validator", validators)]
        if not val
    ]
    if missing:
        raise ValueError(f"Missing required field(s) in lambda event: {missing}")
    
    if not isinstance(validators, list):
        raise ValueError(f"'validator' must be a list, got {type(validators).__name__}")
    
    logger.info(
        f"Input extracted — identifier={identifier!r}, "
        f"control={control!r}, validators count={len(validators)}, skip_failure={skip_failure}"
    )
    
    return identifier, control, validators
