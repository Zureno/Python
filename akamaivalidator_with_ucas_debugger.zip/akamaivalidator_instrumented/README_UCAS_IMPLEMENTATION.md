# Akamaivalidator with UCAS Debugger Implementation

## Overview

This is your actual akamaivalidator Lambda with UCAS Debugger instrumentation added. All your existing business logic remains unchanged - we only added method start/stop logging and metrics tracking.

## What Changed

### New File
- **ucas_debugger.py** - UCAS Debugger wrapper class

### Instrumented Files
- **index.py** - Main handler with method start/stop + metrics
- **data.py** - Athena query method instrumented
- **validate.py** - Validation logic instrumented
- **output.py** - Result building and DynamoDB write instrumented

### Unchanged Files
- **input.py** - No changes
- **helpers.py** - No changes
- **logger.py** - No changes (already has AWS Powertools)
- **config.py** - No changes
- **requirements.txt** - No changes (AWS Powertools already there)
- **Dockerfile** - No changes

## UCAS Debugger Features

### 1. Method Start Logging
Every instrumented method logs when it starts:
```json
{
  "event": "method_start",
  "method": "get_akamai_onboarding_compliance",
  "timestamp": "2026-05-05T16:45:00.123Z",
  "parameters": {"appci": "BFM"}
}
```

### 2. Method Stop Logging with Duration
Every instrumented method logs when it completes:
```json
{
  "event": "method_stop",
  "method": "get_akamai_onboarding_compliance",
  "timestamp": "2026-05-05T16:45:02.456Z",
  "duration_ms": 2333.24,
  "metrics": {
    "compliance_status": "PASS",
    "pass_count": 5,
    "fail_count": 0
  }
}
```

### 3. Intermediate Metrics
Key metrics logged during execution:
```json
{
  "event": "metrics",
  "method": "get_akamai_onboarding_compliance",
  "metrics": {
    "records_retrieved": 10,
    "athena_query_completed": true
  }
}
```

## Instrumented Methods

### handler (index.py)
**Metrics tracked:**
- identifier, control, validator_type, criteria
- akamai_data_retrieved, data_status
- validation_passed
- final_status, result_size

### get_akamai_onboarding_compliance (data.py)
**Metrics tracked:**
- appci
- athena_query_id
- records_retrieved, athena_query_completed
- total_records_evaluated, pass_records, fail_records, special_pass
- compliance_status, result_data, pass_count, fail_count

### validate_akamai (validate.py)
**Metrics tracked:**
- validator_type, criteria, data_received
- validation_result, criteria_matched

### build_result (output.py)
**Metrics tracked:**
- identifier, control, validator_type, passed
- result_size, evidence_length
- evidence_truncated (if applicable)

### write_result (output.py)
**Metrics tracked:**
- identifier, control, table_name
- write_status, sort_key
- error_type, error_message (if failed)

## Installation

### Option 1: Replace Your Current Files

```bash
cd /path/to/your/akamaivalidator

# Backup current files
mkdir -p backup_$(date +%Y%m%d_%H%M%S)
cp *.py backup_*/

# Copy instrumented files
cp /path/to/instrumented/ucas_debugger.py .
cp /path/to/instrumented/index.py .
cp /path/to/instrumented/data.py .
cp /path/to/instrumented/validate.py .
cp /path/to/instrumented/output.py .
```

### Option 2: Side-by-Side Comparison

```bash
# Keep original in akamaivalidator/
# Deploy instrumented version as akamaivalidator-ucas/
# Compare logs before rolling out completely
```

## Testing Locally

```bash
cd akamaivalidator_instrumented
python index.py
```

Expected output includes structured JSON logs showing:
- Method start for handler
- Method start for get_akamai_onboarding_compliance
- Athena query metrics
- Records evaluation metrics
- Method stop with duration
- Method start for validate_akamai
- Validation result
- Method stop
- And so on...

## Example Log Output

```
{"level":"INFO","location":"method_start:34","message":"Method started: handler","timestamp":"2026-05-05 16:45:00,123+0000","service":"akamaivalidator-lambda","event":"method_start","method":"handler","parameters":{"request_id":"abc-123","function_name":"akamaivalidator"}}

{"level":"INFO","location":"method_start:34","message":"Method started: get_akamai_onboarding_compliance","timestamp":"2026-05-05 16:45:00,200+0000","service":"akamaivalidator-lambda","event":"method_start","method":"get_akamai_onboarding_compliance","parameters":{"appci":"BFM"}}

{"level":"DEBUG","location":"log_metrics:78","message":"Method metrics","timestamp":"2026-05-05 16:45:01,500+0000","service":"akamaivalidator-lambda","event":"metrics","method":"get_akamai_onboarding_compliance","metrics":{"athena_query_id":"abc-query-123"}}

{"level":"DEBUG","location":"log_metrics:78","message":"Method metrics","timestamp":"2026-05-05 16:45:02,300+0000","service":"akamaivalidator-lambda","event":"metrics","method":"get_akamai_onboarding_compliance","metrics":{"records_retrieved":10,"athena_query_completed":true}}

{"level":"INFO","location":"method_stop:50","message":"Method completed: get_akamai_onboarding_compliance","timestamp":"2026-05-05 16:45:02,456+0000","service":"akamaivalidator-lambda","event":"method_stop","method":"get_akamai_onboarding_compliance","duration_ms":2256.12,"metrics":{"compliance_status":"PASS","result_data":["akamai"],"pass_count":10,"fail_count":0}}
```

## CloudWatch Insights Queries

### Find Slowest Methods
```sql
fields @timestamp, method, duration_ms
| filter service = "akamaivalidator-lambda"
| filter event = "method_stop"
| sort duration_ms desc
| limit 20
```

### Track Validation Success Rate
```sql
fields @timestamp, identifier, control, metrics.final_status
| filter service = "akamaivalidator-lambda"
| filter method = "handler"
| filter event = "method_stop"
| stats count() by metrics.final_status
```

### Monitor Athena Query Performance
```sql
fields @timestamp, duration_ms, metrics.records_retrieved
| filter service = "akamaivalidator-lambda"
| filter method = "get_akamai_onboarding_compliance"
| filter event = "method_stop"
| stats avg(duration_ms), avg(metrics.records_retrieved)
```

### Find Errors
```sql
fields @timestamp, method, metrics.error_type, metrics.error_message
| filter service = "akamaivalidator-lambda"
| filter metrics.final_status = "ERROR" or metrics.write_status = "FAILED"
```

## Performance Impact

UCAS Debugger overhead per instrumented method:
- method_start: < 1ms
- method_stop: < 1ms
- log_metrics: < 0.5ms

Total overhead for typical execution: < 10ms (negligible)

## Deployment

### Lambda Deployment
```bash
cd akamaivalidator_instrumented
zip -r akamaivalidator-ucas.zip .
aws lambda update-function-code --function-name akamaivalidator --zip-file fileb://akamaivalidator-ucas.zip
```

### Environment Variables
No new environment variables needed! AWS Lambda Powertools is already configured via:
- `POWERTOOLS_SERVICE_NAME=akamaivalidator-lambda` (already in logger.py)
- `LOG_LEVEL=INFO` (set in Lambda configuration)

## Validation Checklist

After deployment, verify:
- [ ] CloudWatch Logs show structured JSON format
- [ ] method_start logs appear for all instrumented methods
- [ ] method_stop logs include duration_ms
- [ ] metrics appear in logs
- [ ] No errors in Lambda execution
- [ ] Validation results still write to DynamoDB correctly
- [ ] Response time increased by less than 50ms

## Rollback Plan

If issues occur:
```bash
cd /path/to/your/akamaivalidator/backup_YYYYMMDD_HHMMSS
zip -r akamaivalidator-rollback.zip .
aws lambda update-function-code --function-name akamaivalidator --zip-file fileb://akamaivalidator-rollback.zip
```

## What's Next

1. Deploy to dev environment
2. Run test validations
3. Review CloudWatch Logs
4. Validate metrics are useful
5. Adjust log levels if needed (INFO vs DEBUG)
6. Deploy to prod once validated

## Support

For questions about UCAS Debugger implementation:
- Check CloudWatch Logs for structured JSON
- Use CloudWatch Insights queries above
- Review method metrics in logs
- Contact DevOps team for additional support

## Summary

Your akamaivalidator now has:
- Automatic method start/stop logging
- Execution duration tracking
- Key metrics logging
- Zero changes to business logic
- Production-ready instrumentation
- CloudWatch Insights compatibility

All ready for demo!
