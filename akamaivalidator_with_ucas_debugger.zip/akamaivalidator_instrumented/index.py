import json
from logger import logger
from ucas_debugger import UCASDebugger
from input import extract_lambda_input
from data import get_akamai_onboarding_compliance
from validate import validate_akamai
from output import build_result, write_result

# Initialize UCAS Debugger
ucas = UCASDebugger(logger)


def handler(event, context):
    """
    Akamai Validator Lambda — standalone microservice with UCAS Debugger instrumentation.

    Expected event (direct invocation):
        {
            "identifier": "BFM",
            "control": "CDR-NSS3.4.2 - App01",
            "validator": {"type": "akamai", "criteria": ["akamai"]}
        }

    Or SNS-wrapped in event["Records"][0]["Sns"]["Message"].

    Flow:
        1. Parse input  → identifier, control name, validator config
        2. Collect data  → query Athena for Akamai onboarding compliance
        3. Validate      → compare criteria against collected data
        4. Build output  → assemble standardised result dict
        5. Write result  → persist to eqa-validation-results-table
    """
    ucas.method_start(
        "handler",
        request_id=context.request_id if context else "local",
        function_name=context.function_name if context else "local"
    )
    
    try:
        # 1. Parse input
        identifier, control, validator = extract_lambda_input(event)
        ucas.log_metrics(
            identifier=identifier,
            control=control,
            validator_type=validator.get("type"),
            criteria=validator.get("criteria")
        )

        # 2. Collect data from Athena
        logger.info(f"Querying Akamai onboarding data for AppCI {identifier}")
        akamai_data = get_akamai_onboarding_compliance(identifier)
        ucas.log_metrics(
            akamai_data_retrieved=len(akamai_data),
            data_status="compliant" if akamai_data else "non_compliant"
        )

        # 3. Validate
        passed = validate_akamai(validator, akamai_data)
        ucas.log_metrics(validation_passed=passed)

        # 4. Build output
        result = build_result(identifier, control, validator, passed)
        logger.info(f"Validation result: {json.dumps(result)}")

        # 5. Write to DynamoDB
        write_result(identifier, control, validator, result)

        ucas.method_stop(
            "handler",
            final_status="PASS" if passed else "FAIL",
            result_size=len(json.dumps(result))
        )

        return result

    except Exception as e:
        logger.exception(f"Akamai validator failed: {e}")
        ucas.method_stop(
            "handler",
            final_status="ERROR",
            error_type=type(e).__name__,
            error_message=str(e)
        )
        raise


# ---------------------------------------------------------------------------
# Local testing — run directly:  python index.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    test_event = {
        "identifier": "BFM",
        "control": "CDR-NSS3.4.2 - App01",
        "validator": {
            "type": "akamai",
            "criteria": ["akamai"]
        }
    }

    result = handler(test_event, None)
    print(json.dumps(result, indent=2))
