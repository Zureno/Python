import json
from logger import logger

# ---------------------------------------------------------------------------
# Parse the Lambda event → (identifier, control, validator dict)
# ---------------------------------------------------------------------------


def extract_lambda_input(event: dict) -> tuple[str, str, dict]:
    """
    Supports three invocation formats:

    Format A — SQS-triggered:
        event["Records"][0]["body"]  →  JSON string with
        { "identifier": "...", "control": "...", "validator": {...} }

    Format B — SNS-triggered:
        event["Records"][0]["Sns"]["Message"]  →  JSON string (same shape)

    Format C — Direct / QA invocation:
        event itself is the dict above.

    Returns (identifier, control_name, validator_dict).
    """

    # --- Format A/B: SQS or SNS wrapper ---------------------------------------
    if "Records" in event:
        try:
            record = event["Records"][0]
            if "body" in record:
                raw = record["body"]
                logger.info("Parsed SQS message body")
            else:
                raw = record["Sns"]["Message"]
                logger.info("Parsed SNS message body")
            body = json.loads(raw)
        except (KeyError, IndexError, json.JSONDecodeError) as exc:
            raise ValueError(f"Could not parse message from event: {exc}") from exc
    # --- Format C: direct invocation ------------------------------------------
    else:
        body = event
        logger.info("Direct invocation body received")

    # --- Extract required fields ----------------------------------------------
    identifier: str = body.get("identifier", "")
    control: str = body.get("control", "")
    validator = body.get("validator")

    # Coerce validator from JSON string if needed
    if isinstance(validator, str):
        try:
            validator = json.loads(validator)
        except json.JSONDecodeError as exc:
            raise ValueError(f"'validator' field is not valid JSON: {exc}") from exc

    # --- Validate mandatory fields --------------------------------------------
    missing = [
        name
        for name, val in [("identifier", identifier), ("control", control), ("validator", validator)]
        if not val
    ]
    if missing:
        raise ValueError(f"Missing required field(s) in lambda event: {missing}")

    if not isinstance(validator, dict):
        raise ValueError(f"'validator' must be a dict, got {type(validator).__name__}")

    logger.info(
        f"Input extracted — identifier={identifier!r}, "
        f"control={control!r}, validator type={validator.get('type')!r}"
    )
    return identifier, control, validator
