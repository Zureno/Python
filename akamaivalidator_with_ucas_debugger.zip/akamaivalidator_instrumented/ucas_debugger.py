"""
UCAS Debugger - Method instrumentation wrapper for AWS Lambda Powertools
"""
import time
from datetime import datetime
from aws_lambda_powertools import Logger


class UCASDebugger:
    """
    UCAS Debugger wrapper for method instrumentation.
    Logs method start, stop, duration, and key metrics using AWS Lambda Powertools.
    
    Usage:
        ucas = UCASDebugger(logger)
        
        def my_method(param1):
            ucas.method_start("my_method", param1=param1)
            # ... your logic ...
            ucas.method_stop("my_method", result_count=10)
    """
    
    def __init__(self, logger_instance: Logger):
        self.logger = logger_instance
        self.start_time = None
        self.method_name = None
    
    def method_start(self, method_name: str, **kwargs):
        """
        Log method start with optional parameters.
        
        Args:
            method_name: Name of the method being instrumented
            **kwargs: Additional context parameters to log
        """
        self.method_name = method_name
        self.start_time = time.time()
        
        self.logger.info(
            f"Method started: {method_name}",
            extra={
                "event": "method_start",
                "method": method_name,
                "timestamp": datetime.utcnow().isoformat(),
                "parameters": kwargs
            }
        )
    
    def method_stop(self, method_name: str, **metrics):
        """
        Log method stop with duration and metrics.
        
        Args:
            method_name: Name of the method being instrumented
            **metrics: Key metrics to log (e.g., records_processed=10)
        """
        duration_ms = None
        if self.start_time:
            duration_ms = round((time.time() - self.start_time) * 1000, 2)
        
        self.logger.info(
            f"Method completed: {method_name}",
            extra={
                "event": "method_stop",
                "method": method_name,
                "timestamp": datetime.utcnow().isoformat(),
                "duration_ms": duration_ms,
                "metrics": metrics
            }
        )
    
    def log_metrics(self, **metrics):
        """
        Log key metrics during execution.
        
        Args:
            **metrics: Metrics to log
        """
        self.logger.debug(
            "Method metrics",
            extra={
                "event": "metrics",
                "method": self.method_name,
                "metrics": metrics
            }
        )
