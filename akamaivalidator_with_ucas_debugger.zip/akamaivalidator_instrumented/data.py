from datetime import datetime, timedelta
from logger import logger
from ucas_debugger import UCASDebugger
from helpers import execute_athena_query, wait_for_query, get_query_results

# Initialize UCAS Debugger
ucas = UCASDebugger(logger)

# ---------------------------------------------------------------------------
# Athena constants
# ---------------------------------------------------------------------------

DATABASE = "appsec_database_for_datalake_shared_resources"
TABLE = "akamai_onboarding_shared"


def _q(name: str) -> str:
    """Quote an Athena identifier."""
    return f'"{name}"'


# ---------------------------------------------------------------------------
# Data collection — query Athena for Akamai onboarding compliance
# ---------------------------------------------------------------------------


def get_akamai_onboarding_compliance(appci: str) -> list[str]:
    """
    Query the Akamai onboarding datalake table for *appci* and evaluate
    whether the AppCI is compliant.

    Returns:
        ["akamai"]  — if compliant (PASS)
        []          — if not compliant (FAIL)

    Raises on missing appci or Athena errors.
    """
    ucas.method_start("get_akamai_onboarding_compliance", appci=appci)
    
    if not appci:
        raise ValueError("Parameter appci is mandatory")

    safe_appci = str(appci).replace("'", "''")

    sql = (
        f"WITH base_filtered AS ( "
        f"  SELECT * "
        f"  FROM {_q(DATABASE)}.{_q(TABLE)} "
        f"  WHERE {_q('appci')} = '{safe_appci}' "
        f"), "
        f"latest_p0 AS ( "
        f"  SELECT max({_q('partition_0')}) AS p0 "
        f"  FROM base_filtered "
        f"), "
        f"latest_period AS ( "
        f"  SELECT date_format( "
        f"           max(date_parse({_q('period')}, '%m-%d-%Y')), "
        f"           '%m-%d-%Y' "
        f"         ) AS per "
        f"  FROM base_filtered "
        f"  WHERE {_q('partition_0')} = (SELECT p0 FROM latest_p0) "
        f"), "
        f"filtered_latest AS ( "
        f"  SELECT * "
        f"  FROM base_filtered "
        f"  WHERE {_q('partition_0')} = (SELECT p0 FROM latest_p0) "
        f"    AND {_q('period')} = (SELECT per FROM latest_period) "
        f") "
        f"SELECT * "
        f"FROM filtered_latest "
        f"ORDER BY {_q('partition_0')} DESC "
    )

    qid = execute_athena_query(DATABASE, sql)
    if not qid:
        raise RuntimeError(f"Athena query failed to start for Akamai validator (appci={appci})")

    ucas.log_metrics(athena_query_id=qid)

    wait_for_query(qid)
    logger.info(f"Athena query for akamai validator (id={qid}) executed successfully")
    rows = get_query_results(qid)
    
    ucas.log_metrics(
        records_retrieved=len(rows),
        athena_query_completed=True
    )

    # -----------------------------------------------------------------
    # Evaluate each record for compliance
    # -----------------------------------------------------------------
    pass_records = 0
    fail_records = 0
    special_pass = 0

    for record in rows:
        onboarding_candidate = str(record.get("onboarding_canidate", "")).strip().lower()
        covered = str(record.get("covered", "")).strip().lower()
        acronym = str(record.get("acronym", "")).strip()
        operational_status = str(record.get("operational_status", "")).strip()
        hosting_type = str(record.get("hosting_type", "")).strip()
        dns = str(record.get("dns", "")).strip()
        source = str(record.get("source", "")).strip()
        network_exposure = str(record.get("network_exposure", "")).strip()
        third_party = str(record.get("third_party", "")).strip()

        # Records that are excluded from compliance evaluation
        if (
            acronym == "" or acronym.upper() == "RETIRED"
            or operational_status == "" or operational_status == "Retired"
            or hosting_type == "SaaS"
            or hosting_type == "NA"
            or dns == ""
            or "ualaki" in dns.lower()
            or "acme-challenge" in dns.lower()
            or source in ("docker-sidecar", "docker-sidecar,gigamon")
            or network_exposure != "External facing (Available on Internet)"
            or third_party == ""
            or third_party == "Yes"
        ):
            special_pass += 1
            logger.info(f"Record passes special conditions for AppCI {appci}")
            continue

        # Failing combinations
        if (
            (onboarding_candidate == "yes" and covered == "no")
            or (onboarding_candidate == "no" and covered == "yes")
        ):
            fail_records += 1
            logger.info(f"Failing combination found for AppCI {appci}")

        # Passing combinations
        elif (
            (onboarding_candidate == "yes" and covered == "yes")
            or (onboarding_candidate == "no" and covered == "no")
        ):
            pass_records += 1

        # Anything else is treated as a failure
        else:
            fail_records += 1

    # Log evaluation metrics
    ucas.log_metrics(
        total_records_evaluated=len(rows),
        pass_records=pass_records,
        fail_records=fail_records,
        special_pass=special_pass
    )

    # -----------------------------------------------------------------
    # Determine overall compliance
    # -----------------------------------------------------------------
    if pass_records == 0 and fail_records == 0 and special_pass == 0:
        compliant = False
    elif fail_records == 0:
        compliant = True
    else:
        compliant = False

    status = "PASS" if compliant else "FAIL"
    logger.info(f"Akamai onboarding & coverage compliance for {appci}: {status}")

    result = ["akamai"] if compliant else []
    
    ucas.method_stop(
        "get_akamai_onboarding_compliance",
        compliance_status=status,
        result_data=result,
        pass_count=pass_records,
        fail_count=fail_records
    )

    return result
