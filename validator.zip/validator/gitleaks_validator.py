from .logger import logger
 
 
class GitleaksValidator:
    def validate(self, mappings, gitleaks_findings):
        if not gitleaks_findings:
            return True
 
        for finding in gitleaks_findings:
            if str(finding.get("open_status", "")).strip().lower() == "true":
                logger.info(f"Gitleaks validation FAILED — open finding detected: {finding.get('display_name', '')}")
                return False
 
        return True