class AkamaiValidator:
    def validate(self, mappings, akamai_data):
        criteria = mappings["criteria"]
        for result in akamai_data:
            if result == "akamai" and criteria == ["akamai"]:
                return True
        return False