import json, ast
from .logger import logger


class SplunkotValidator:
    def validate(self, mappings, splunkot_data):
        success =  True

        #Get customproperty from control criteria. Each control MUST have ONLY 1 customproperty.
        try:
            control_prop = str(mappings['criteria'][0])
            false_pattern = f"'{control_prop}': 'False'"            
        except:
             logger.warning(f"Invalid OT control criteria {mappings['name']}")

        num_results = len(splunkot_data)
        num_na = 0
        num_fail = 0

        # If no records are found containing customproperty SPLUNK_ACCEPTABLE_VERSION_GAUGE,
        # UCAS does not return a pass or a fail
        if num_results == 0:
             success = "N/A"
        else:
            for record in splunkot_data:
                data_prop = str(record["customproperties"])

                # if there is one hostname for which "SPLUNK_ACCEPTABLE_VERSION_GAUGE" = 'False', validation fails
                # if SPLUNK_ACCEPTABLE_VERSION_GAUGE is not present for all it is "N/A". if none of these conditions met , It's set to true for all macis, validation passes.
                if false_pattern in data_prop:
                        num_fail +=1
                if control_prop not in data_prop:
                        num_na +=1    
                                         
            if  num_na == num_results:
                success = "N/A"
            if  num_fail > 0:
                success = False
        return success
