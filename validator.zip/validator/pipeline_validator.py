from integrations.asvs.harness import HarnessIntegration
from integrations.asvs.github import GithubIntegration
from .logger import logger

class PipelineValidator:

    def __init__(self):
        self.harness = HarnessIntegration()
        self.github = GithubIntegration()

    def validate(self, mapping, appci, repos):
        success = False # fail by default. prove positive
        results = 0
        count = 0

        try:
            for criteria in mapping["criteria"]:
                if mapping["tool"] == "harness":
                    count, raw = self.harness.validate_template_usage(criteria, appci)
                elif mapping["tool"] == "github":
                    count, raw = self.github.search_code(criteria, repos)
                results += count

        except Exception as error:
            logger.warning(f"In pipeline validator: {error}")
            raise SystemError("Error occured in pipeline validator while getting templates")

        if results > 0:
            success = True

        return success
