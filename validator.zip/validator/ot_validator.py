import json, ast
from .logger import logger


class OTValidator:
    def validate(self, mappings, ot_vulns):
        #Get customproperty from control criteria. Each control MUST have ONLY 1 customproperty.
        try:
            control_prop = str(mappings['criteria'][0])
        except:
            logger.warning(f"Invalid OT control criteria {mappings['name']}")
        #When there is no customproperty, the control is checking for onboarding status.
        #For these controls, if the device is not in datalake (which means it's not in Armis), then fail control.
        if control_prop == "" and ot_vulns == []:
            return False
        
        #If the control is checking for presence of an armis tag:
        else:
            for vuln in ot_vulns:
                #Get customproperty from armis data (type conversions needed)
                vuln_prop = json.loads(json.dumps(ast.literal_eval(vuln["customproperties"])))

                #If control is applicable to a device, customproperty will be present
                if control_prop in vuln_prop:
                    #If checking for non-compliance, fail if true. 100% must pass.
                    if "Non_Compliant" in control_prop:
                        if vuln_prop[control_prop] == "True":
                            return False
                        else: continue # Stops from proceeding to "Compliant" check

                    #else, if checking for compliance, fail if false. 100% must pass.
                    if "Compliant" in control_prop:
                        if vuln_prop[control_prop] == "False":
                            return False
                        else: continue
                    
        return True
