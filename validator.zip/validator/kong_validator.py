class KongValidator:
    def validate(self, data):

        success = False # fail by default. prove positive
        if not data:
            return "N/A" #empty list means no data found for planeids for an appci or No planeids for an appci
        if all(data):
            success= True
        return success
