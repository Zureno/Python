from .logger import logger

class onboardedValidator:
    def validate(self, mapping, sast_compliant, dast_compliant):
        try:
            criteria = mapping["criteria"]
        except KeyError:
            criteria = None
        
        logger.debug(f'Sast: {sast_compliant}, Dast: {dast_compliant}')

        if sast_compliant is True and "sast" in criteria:
            return True
                    
        if dast_compliant is True and "dast" in criteria:
            return True
        
        return False

