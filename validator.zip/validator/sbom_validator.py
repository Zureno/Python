class SbomValidator:
    def validate(self, appci, mapping, libraries, sbom, sast_compliant, sast_metadata):
        success = False # fail by default. prove success

        library_metadata = []

        criteria = mapping["criteria"]
        found_criteria = []

        # only edge case, if records and no criterea. control 10.1.1
        if criteria == [""]:
                if len(sbom) > 0:
                    success = True

        else:
            if len(libraries) > 0:
                for library in libraries:
                    for criteria in mapping["criteria"]:
                        if success == False:
                            if criteria.lower() in library["library"].lower():
                                success = True
                                found_criteria.append(criteria)
                                library_metadata.append(library)

        if sast_compliant is False:
            success = False

        return success
