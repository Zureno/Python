import re
import boto3
from .logger import logger
TABLE_NAME = 'eqa-cwe-mappings-table'

_cwe_desc_cache = {}
_cwe_items_cache = None


def _scan_all(table):
    # Scan all items from a DynamoDB table, handling pagination.
    items = []
    resp = table.scan()
    items.extend(resp.get('Items', []))
    while 'LastEvaluatedKey' in resp:
        resp = table.scan(ExclusiveStartKey=resp['LastEvaluatedKey'])
        items.extend(resp.get('Items', []))
    return items


def _preload_cwe_items_cache():
    # Preload and cache all CWE mapping records to minimize repeated DynamoDB calls.
    global _cwe_items_cache
    if _cwe_items_cache is not None:
        return _cwe_items_cache
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(TABLE_NAME)
        all_items = _scan_all(table)
        _cwe_items_cache = {str(it.get('cwe_id')): it for it in all_items if 'cwe_id' in it}
        return _cwe_items_cache
    except Exception:
        _cwe_items_cache = {}
        return _cwe_items_cache


def get_cwe_description_from_table(cwe_id: str, source: str):
    # Return description from DynamoDB when cwe_id matches and source equals the vuln scan type.
    cache_key = (str(cwe_id), str(source).lower())
    if cache_key in _cwe_desc_cache:
        return _cwe_desc_cache[cache_key]

    items_cache = _preload_cwe_items_cache()
    item = items_cache.get(str(cwe_id))
    if not item:
        _cwe_desc_cache[cache_key] = None
        return None
    item_source = str(item.get('source', '')).lower()
    if item_source == str(source).lower():
        desc = str(item.get('cwe_name', '')).strip() or None
        _cwe_desc_cache[cache_key] = desc
        return desc
    _cwe_desc_cache[cache_key] = None
    return None


class CodeqlValidator:
    def validate(self, mapping, vulns):
        """
        Validate CodeQL findings against a control mapping.
        Supports two matching modes:
          - scope = 'cwe'     : match by CWE number extracted from alert tags
          - scope = 'rule_id' : match by CodeQL rule ID (e.g. 'toctou-race-condition')
        """
        criteria = mapping.get('criteria', [])
        scope = mapping.get('scope', '')
        exclude_list = mapping.get('exclude', [])
        regex_include_list = mapping.get('regexinclude', [])

        success = True
        exception = False
        avits = []
        evidence = {
            "scan_type": "codeql",
            "avit_ids": [],
            "cwe_details": [],
            "FindingIDs": []
        }


        for vuln in vulns:
            try:
                avit = vuln.get("rule_id", "")
                remediation = vuln.get("remediation_description", "")
                cwes_raw = vuln.get("cwes", "")
                display_name = vuln.get("display_name", "")
                rule_id = vuln.get("rule_id", "")

                vuln_scan_type = vuln.get("scan_type", "").lower()
                # Normalize scan type
                if vuln_scan_type == "codeql":
                    vuln_scan_type = "codeql"

                # Only process codeql vulns
                if vuln_scan_type != "codeql":
                    logger.debug(f"Skipping vuln {avit}: scan_type mismatch (vuln: {vuln_scan_type}, expected: codeql)")
                    continue

                # -----------------------------------------------
                # Mode 1 - Match by rule_id
                # e.g. criteria: ["toctou-race-condition", "sql-injection"]
                # -----------------------------------------------
                if scope.lower() == 'rule_id':
                    for crit in criteria:
                        crit_norm = str(crit).strip().lower()
                        rule_id_norm = str(rule_id).strip().lower()
                        if crit_norm in rule_id_norm:

                            # Check exclusion list
                            is_excluded = False
                            for exclusion in exclude_list:
                                excl_tool = str(exclusion[0]).strip().lower()
                                excl_desc = str(exclusion[1]).strip().lower()
                                if excl_tool == vuln_scan_type:
                                    remediation_norm = str(remediation).strip().lower()
                                    if excl_desc in remediation_norm:
                                        is_excluded = True
                                        break

                            if not is_excluded:
                                # Check regexinclude if present
                                if regex_include_list:
                                    regex_matched = False
                                    for pattern in regex_include_list:
                                        try:
                                            if re.search(pattern, str(remediation), flags=re.IGNORECASE):
                                                regex_matched = True
                                                break
                                        except re.error as rex:
                                            pass
                                    if not regex_matched:
                                        continue

                                if avit not in avits:
                                    avits.append(avit)

                                # Capture Finding ID
                                silk_id = str(vuln.get("html_url", "")).strip()
                                if silk_id and silk_id not in evidence["FindingIDs"]:
                                    evidence["FindingIDs"].append(silk_id)

                                # Extract CWE numbers for evidence
                                cwes_str = str(cwes_raw).replace('[', '').replace(']', '').replace("'", '').replace('"', '')
                                for part in cwes_str.split(','):
                                    part = part.strip()
                                    match = re.search(r'(?:CWE-)?(\d+)', part)
                                    if match:
                                        cwe_id = match.group(1)
                                        if not any(d.get('id') == cwe_id for d in evidence["cwe_details"]):
                                            table_desc = get_cwe_description_from_table(cwe_id, "codeql")
                                            description_val = table_desc if table_desc else (str(remediation) if remediation else "")
                                            evidence["cwe_details"].append({
                                                "id": cwe_id,
                                                "description": description_val
                                            })

                # -----------------------------------------------
                # Mode 2 - Match by CWE number
                # e.g. criteria: ["79", "89"] or ["CWE-79"]
                # -----------------------------------------------
                elif scope.lower() == 'cwe':
                    cwes_str = str(cwes_raw).replace('[', '').replace(']', '').replace("'", '').replace('"', '')
                    cwe_numbers = []
                    for part in cwes_str.split(','):
                        part = part.strip()
                        match = re.search(r'(?:CWE-)?(\d+)', part)
                        if match:
                            cwe_numbers.append(match.group(1))


                    for crit in criteria:
                        crit_str = str(crit).strip()
                        crit_match = re.search(r'(?:CWE-)?(\d+)', crit_str)
                        if crit_match:
                            crit_num = crit_match.group(1)
                            if crit_num in cwe_numbers:

                                # Check exclusion list
                                is_excluded = False
                                for exclusion in exclude_list:
                                    excl_tool = str(exclusion[0]).strip().lower()
                                    excl_desc = str(exclusion[1]).strip().lower()
                                    if excl_tool == vuln_scan_type:
                                        remediation_norm = str(remediation).strip().lower()
                                        if excl_desc in remediation_norm:
                                            is_excluded = True
                                            break

                                if not is_excluded:
                                    # Check regexinclude if present
                                    if regex_include_list:
                                        regex_matched = False
                                        for pattern in regex_include_list:
                                            try:
                                                if re.search(pattern, str(remediation), flags=re.IGNORECASE):
                                                    regex_matched = True
                                                    break
                                            except re.error as rex:
                                                pass
                                        if not regex_matched:
                                            continue

                                    if avit not in avits:
                                        avits.append(avit)

                                    # Capture Finding ID
                                    silk_id = str(vuln.get("html_url", "")).strip()
                                    if silk_id and silk_id not in evidence["FindingIDs"]:
                                        evidence["FindingIDs"].append(silk_id)

                                    # Track CWE evidence
                                    if not any(d.get('id') == crit_num for d in evidence["cwe_details"]):
                                        table_desc = get_cwe_description_from_table(crit_num, "codeql")
                                        description_val = table_desc if table_desc else (str(remediation) if remediation else "")
                                        evidence["cwe_details"].append({
                                            "id": crit_num,
                                            "description": description_val
                                        })

                # Check criticality if present in mapping
                criticality = mapping.get('criticality')
                if criticality:
                    vuln_severity = vuln.get("severity", "").strip().upper()
                    if isinstance(criticality, list):
                        crit_values = [str(c).strip().upper() for c in criticality]
                    else:
                        crit_values = [str(criticality).strip().upper()]
                    if vuln_severity in crit_values:
                        if avit not in avits:
                            avits.append(avit)

            except Exception as e:
                exception = True
                success = "NA"
                evidence["avit_ids"] = list(avits)
                if not evidence["cwe_details"]:
                    evidence = "Error during validation"
                return success, avits, exception, evidence

        if avits:
            success = False
        else:
            pass

        evidence["avit_ids"] = list(avits)
        return success, avits, exception, evidence