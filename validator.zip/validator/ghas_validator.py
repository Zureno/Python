from .logger import logger


class GhasValidator:
    def validate(self, mappings, ghas_findings):
        if not ghas_findings:
            return True

        for alert in ghas_findings:
            if str(alert.get("state", "")).strip().lower() == "open":
                logger.info(
                    f"GHAS validation FAILED — open secret alert detected: {alert.get('secret_type', '')} in repo {alert.get('repo_name', '')}"
                )
                return False

        return True