import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from concurrent.futures import ThreadPoolExecutor, as_completed
from integrations.asvs.github import GithubIntegration
from shared.asyncwrapper import execute
from shared.controls import Control as Controlclass
from .logger import logger


class SourceValidator:

    def __init__(self):
        self.github = GithubIntegration()
        self.controlclass = Controlclass()

    def validate(self, mapping, definition, repos):
        success = False # fail by default. prove success
        results = 0
        raw_evidence = []

        try:
            language = mapping["language"]
        except:
            language = ['all']

        with ThreadPoolExecutor(max_workers=5) as executorA:
            future_to_criteria = {executorA.submit(GithubIntegration().search_code, criteria, repos, language): criteria for criteria in mapping["criteria"]}
            for future in as_completed(future_to_criteria):
                criteria = future_to_criteria[future]
                try:
                    count, raw = future.result()
                    results += count
                    raw_evidence.append(raw)
                except Exception as e:
                    logger.warning(f"Processing criteria {criteria}: {e}")

        executorA.shutdown(wait=True)

        if "implements" not in mapping:
            raise SystemError("Implements is not defined in the control mapping.")
        
        #If records and no criteria. control 1.10.1
        if mapping["criteria"] == [""]:
            if len(repos) > 0:
                success = True
        
        definition_pass = self.controlclass.get_definition_pass(definition, results, mapping["criteria"])

        # if implements is true, we want to make sure they do it so results should be > 0
        if results > 0 and mapping["implements"] == True and definition_pass == True:
            success = True
            
        # if implements is false, we want to make sure they do not do it so results should be 0
        if results == 0 and mapping["implements"] == False and definition_pass == True:
            success = True

        # SSDF 2.3.4 - check for existence of repos by appci 
        if mapping["criteria"] == ["check_repos"]:
            if len(repos) > 0:
                success = True
            else:
                success = False
            return success

        if len(repos) == 0:
            success = None
            
        return success   

'''
if __name__ == "__main__":
    #print("test")
    test_criteria = []
    source = SourceValidator()
    github = GithubIntegration()
    repos = github.get_repos_by_appci('AAP')
    mapping = {"type": "source",
                "implements": True,
                "definition": "any",
                "criteria": [
                        ""
                ]}
    print(source.validate(mapping, "any", repos))
    '''
