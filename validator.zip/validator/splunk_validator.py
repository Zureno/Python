class SplunkValidator:
    def validate(self, mappings, splunk_status):
        success = False  
        criteria = str(mappings['criteria'][0]) # SPLUNK_ACCEPTABLE_VERSION_GAUGE 
        true_pattern = f"'{criteria}': 'True'" # SPLUNK_ACCEPTABLE_VERSION_GAUGE set to True

        if splunk_status == []:
            # No records were found for the hostname, OR 
            # No records included SPLUNK_ACCEPTABLE_VERSION_GAUGE in customprops
            # So UCAS will not assign a pass/fail
            success = "N/A" 
                        
        else:
            splunk_status = splunk_status[0] # This is returned as a list of 1 item if there are results, so extract that item
            # Get all customproperties from latest record with SPLUNK custom property
            customprops_str = str(splunk_status.get("customproperties", ""))
            # Check if SPLUNK_ACCEPTABLE_VERSION_GAUGE is True in the customproperties
            if true_pattern in customprops_str:
                success = True
        return success # Defaults to false if SPLUNK_ACCEPTABLE_VERSION_GAUGE is not True
