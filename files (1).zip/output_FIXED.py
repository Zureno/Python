"""
Build validation result and write to DynamoDB
"""

import json
import boto3
from datetime import datetime
from botocore.exceptions import ClientError
from logger import logger


# ---------------------------------------------------------------------------
# DynamoDB table for validation results
# ---------------------------------------------------------------------------
TABLE_NAME = "eqa-validation-results-table"
dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
table = dynamodb.Table(TABLE_NAME)


# ---------------------------------------------------------------------------
# Build the sort key:  control#[validator]
# ---------------------------------------------------------------------------
def build_sort_key(control: str, validator: dict) -> str:
    """Build composite sort key for DynamoDB."""
    return f"{control}#[{validator}]"


# ---------------------------------------------------------------------------
# Confidence — single validator type → "low"
# ---------------------------------------------------------------------------
CONFIDENCE_MAP = {1: "low", 2: "medium"}


def get_confidence(num_validator_types: int) -> str:
    """Determine confidence level based on number of validator types."""
    return CONFIDENCE_MAP.get(num_validator_types, "high" if num_validator_types >= 3 else "NA")


# ---------------------------------------------------------------------------
# Evidence message builders (findings-specific)
# ---------------------------------------------------------------------------
def _build_evidence_message(identifier: str, criteria: list, passed: bool, matching_findings: list[dict] = None) -> str:
    """
    Return a human-readable evidence string for the findings validator.
    
    Args:
        identifier: AppCI identifier
        criteria: Criteria list (CWE IDs or remediation keywords)
        passed: Whether validation passed
        matching_findings: List of findings that matched (for failures)
        
    Returns:
        Evidence message string
    """
    if passed:
        return "This requirement has passed; no action is required."
    
    # Build detailed failure message
    if not matching_findings:
        criteria_str = ", ".join([str(c) for c in criteria])
        return (
            f"This requirement has failed because vulnerabilities matching criteria "
            f"[{criteria_str}] were found in AppCI {identifier}."
        )
    
    # Build detailed evidence with CWE and finding details
    cwe_finding_combinations = []
    
    for finding in matching_findings:
        matched_cwe = finding.get('matched_cwe', '')
        display_name = finding.get('display_name', 'Unknown vulnerability')
        remediation = finding.get('remediation_description', '')
        
        # Extract CWE number from matched_cwe (e.g., "CWE-20" -> "20")
        cwe_num = matched_cwe.replace('CWE-', '') if matched_cwe else ''
        
        # Build combination string
        if cwe_num and display_name:
            combo = f"{cwe_num} - {display_name}"
            if remediation:
                combo += f". {remediation}"
            cwe_finding_combinations.append(combo)
    
    # Format the evidence message
    if cwe_finding_combinations:
        combinations_text = ". ".join(cwe_finding_combinations)
        evidence = (
            f"This requirement has failed due to findings detected in the following "
            f"CWE(s) and Finding Name(s) combinations: {combinations_text}. "
            f"To pass this requirement, please remediate the findings in the Finding IDs column."
        )
    else:
        criteria_str = ", ".join([str(c) for c in criteria])
        evidence = (
            f"This requirement has failed because vulnerabilities matching criteria "
            f"[{criteria_str}] were found in AppCI {identifier}."
        )
    
    return evidence


# ---------------------------------------------------------------------------
# Build the standardised result dict
# ---------------------------------------------------------------------------
def build_result(
    identifier: str,
    control: str,
    validator: dict,
    passed: bool,
    matching_findings: list[dict] = None,
) -> dict:
    """
    Assemble the validation result dict matching the expected output schema:
    
        {
          "control":         str,
          "passed":          bool,
          "avit":            [],
          "number":          int,    # count of passing validators (0 or 1)
          "confidence":      str,
          "validations":     [...],
          "raw_evidence":    str,
          "evidence":        str,
          "finding_ids":     str,
          "review_required": str
        }
    
    Args:
        identifier: AppCI identifier
        control: Control name
        validator: Validator config dict
        passed: Whether validation passed
        matching_findings: List of findings that matched criteria (for failures)
        
    Returns:
        Complete result dict
    """
    if matching_findings is None:
        matching_findings = []
    
    criteria = validator.get("criteria", [])
    status = "PASS" if passed else "FAIL"
    
    # Single-validator validation entry
    validation_entry = {
        "type": validator.get("type", "findings"),
        "tool": validator.get("tool", ""),
        "scope": validator.get("scope", ""),
        "criteria": criteria,
        "identifier": identifier,
        "name": control,
        "status": status,
    }
    
    # Build avit (failed CWEs) - FIXED: Now populated for failures
    avit = []
    if not passed and matching_findings:
        # Extract unique CWEs from matching findings
        for finding in matching_findings:
            if 'matched_cwe' in finding:
                cwe_str = f"['{finding['matched_cwe']}']"
                if cwe_str not in avit:
                    avit.append(cwe_str)
    
    # Build finding_ids (comma-separated) - FIXED: Now populated for failures
    finding_ids = []
    if not passed and matching_findings:
        for finding in matching_findings:
            fid = finding.get('finding_id', '').strip()
            if fid:
                finding_ids.append(fid)
    finding_ids_str = ", ".join(finding_ids) if finding_ids else ""
    
    # Raw evidence — matches expected pattern
    if passed:
        raw_evidence = (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has passed because the following criteria passed: {criteria}"
        )
    else:
        raw_evidence = (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has failed because the following criteria failed: {criteria}"
        )
    
    # Human-readable evidence - FIXED: Now includes detailed vulnerability info
    evidence = _build_evidence_message(identifier, criteria, passed, matching_findings)
    
    # Truncate if exceeding ServiceNow 4000-char limit
    if len(evidence) > 4000:
        evidence = evidence[:3997] + "..."
    
    return {
        "control": control,
        "passed": passed,
        "avit": avit,
        "number": 1 if passed else 0,
        "confidence": "low" if passed else "medium",  # FIXED: low for pass, medium for fail
        "validations": [validation_entry],
        "raw_evidence": raw_evidence,
        "evidence": evidence,
        "finding_ids": finding_ids_str,  # FIXED: Now populated
        "review_required": "No",
    }


# ---------------------------------------------------------------------------
# Write result to DynamoDB
# ---------------------------------------------------------------------------

def write_result(identifier: str, control: str, validator: dict, result: dict) -> str:
    """
    Persist the validation result to eqa-validation-results-table.
    
    Key schema:
        PK  = identifier  (AppCI)
        SK  = control#[validator]
    
    Args:
        identifier: AppCI identifier
        control: Control name
        validator: Validator config
        result: Result dict to write
        
    Returns:
        Success message
    """
    sort_key = build_sort_key(control, validator)
    current_date = datetime.now().strftime("%m/%d/%Y")
    
    try:
        table.update_item(
            Key={
                "identifier": identifier,
                "control#validator": sort_key,
            },
            UpdateExpression="SET #res = :res, last_processed = :date",
            ExpressionAttributeNames={"#res": "result"},
            ExpressionAttributeValues={
                ":res": json.dumps(result),
                ":date": current_date,
            },
            ReturnValues="UPDATED_NEW",
        )
        msg = f"Successfully updated results for identifier={identifier}, sort_key={sort_key}"
        logger.info(msg)
        return msg
    
    except ClientError as e:
        error_msg = f"Error updating validator result: {e.response['Error']['Message']}"
        logger.error(error_msg)
        raise ValueError(error_msg) from e
