# UCAS Debugger Deployment Guide

## Directory Structure

```
your-project/
├── src/
│   ├── akamaivalidator/              # Your current production code
│   │   ├── index.py
│   │   ├── data.py
│   │   ├── validate.py
│   │   ├── output.py
│   │   ├── input.py
│   │   ├── helpers.py
│   │   ├── logger.py
│   │   ├── config.py
│   │   └── requirements.txt
│   │
│   ├── akamaivalidator-ucas/         # NEW: Instrumented version
│   │   ├── index.py                  # (instrumented)
│   │   ├── data.py                   # (instrumented)
│   │   ├── validate.py               # (instrumented)
│   │   ├── output.py                 # (instrumented)
│   │   ├── ucas_debugger.py          # NEW FILE
│   │   ├── input.py                  # (unchanged)
│   │   ├── helpers.py                # (unchanged)
│   │   ├── logger.py                 # (unchanged)
│   │   ├── config.py                 # (unchanged)
│   │   └── requirements.txt          # (unchanged)
│   │
│   └── demo/                          # NEW: For presentations only
│       ├── demo_presentation.py       # Interactive colored demo
│       └── ucas_debugger_colored.py   # Colored version
│
└── docs/
    ├── DEPLOYMENT_GUIDE.md            # This file
    ├── COLORED_DEMO_GUIDE.md          # How to use colored demo
    └── UCAS_DEBUGGER_DEMO_COMPARISON.md  # Before/After comparison
```

---

## Step-by-Step Deployment

### PHASE 1: Setup (One-Time)

#### Step 1: Backup Current Code
```bash
cd /path/to/your/project/src

# Backup original akamaivalidator
cp -r akamaivalidator akamaivalidator-backup-$(date +%Y%m%d)
```

#### Step 2: Create New Directory for Instrumented Code
```bash
# Create new directory
mkdir -p akamaivalidator-ucas
```

#### Step 3: Extract Files from ZIP
```bash
# Extract the instrumented code
unzip akamaivalidator_with_ucas_debugger.zip -d akamaivalidator-ucas/
```

---

### PHASE 2: For Demos & Presentations

#### Step 1: Setup Demo Directory
```bash
# Create demo directory
mkdir -p demo

# Copy demo files
cp akamaivalidator_demo/demo_presentation.py demo/
cp akamaivalidator_demo/ucas_debugger.py demo/ucas_debugger_colored.py
```

#### Step 2: Run Demo
```bash
cd demo
python demo_presentation.py
```

**Use this for:**
- Management presentations
- Stakeholder demos
- Training sessions
- Showing value proposition

---

### PHASE 3: Deploy to Dev Environment

#### Option A: Side-by-Side Deployment (RECOMMENDED for testing)

Deploy instrumented version alongside current version:

```bash
cd /path/to/your/project/src/akamaivalidator-ucas

# Create deployment package
zip -r akamaivalidator-ucas.zip .

# Deploy as NEW Lambda function
aws lambda create-function \
  --function-name akamaivalidator-ucas-dev \
  --runtime python3.11 \
  --handler index.handler \
  --role arn:aws:iam::YOUR_ACCOUNT:role/lambda-execution-role \
  --zip-file fileb://akamaivalidator-ucas.zip \
  --timeout 300 \
  --memory-size 512 \
  --environment Variables="{LOG_LEVEL=INFO}"
```

**Test both versions side-by-side:**
- Original: `akamaivalidator`
- UCAS version: `akamaivalidator-ucas-dev`

Compare CloudWatch logs to verify metrics.

#### Option B: In-Place Update (after testing)

Replace current Lambda with instrumented version:

```bash
cd /path/to/your/project/src/akamaivalidator-ucas

# Create deployment package
zip -r akamaivalidator-ucas.zip .

# Update existing Lambda
aws lambda update-function-code \
  --function-name akamaivalidator \
  --zip-file fileb://akamaivalidator-ucas.zip
```

---

### PHASE 4: Validation

#### Step 1: Test Locally
```bash
cd akamaivalidator-ucas
python index.py
```

**Expected output:**
```
{"level":"INFO","message":"Method started: handler"...}
{"level":"INFO","message":"Method started: get_akamai_onboarding_compliance"...}
{"level":"INFO","message":"Method completed: get_akamai_onboarding_compliance","duration_ms":2206.45...}
...
```

#### Step 2: Trigger Lambda Test
```bash
# Test event
cat > test-event.json << EOF
{
  "identifier": "BFM",
  "control": "CDR-NSS3.4.2 - App01",
  "validator": {
    "type": "akamai",
    "criteria": ["akamai"]
  }
}
EOF

# Invoke Lambda
aws lambda invoke \
  --function-name akamaivalidator-ucas-dev \
  --payload file://test-event.json \
  response.json

# Check response
cat response.json
```

#### Step 3: Verify CloudWatch Logs
```bash
# Get latest log stream
aws logs tail /aws/lambda/akamaivalidator-ucas-dev --follow
```

**Look for:**
- ✓ `"event":"method_start"` logs
- ✓ `"event":"method_stop"` logs with `duration_ms`
- ✓ `"event":"metrics"` logs
- ✓ Structured JSON format

#### Step 4: Run CloudWatch Insights Queries
```sql
fields @timestamp, method, duration_ms
| filter service = "akamaivalidator-lambda"
| filter event = "method_stop"
| sort duration_ms desc
| limit 10
```

**Should show:**
- All instrumented methods
- Duration for each method
- Performance breakdown

---

## File Placement Summary

### Production Lambda (akamaivalidator-ucas/)
```
✓ index.py           (instrumented)
✓ data.py            (instrumented)
✓ validate.py        (instrumented)
✓ output.py          (instrumented)
✓ ucas_debugger.py   (NEW - basic version, no colors)
✓ input.py           (unchanged)
✓ helpers.py         (unchanged)
✓ logger.py          (unchanged)
✓ config.py          (unchanged)
✓ requirements.txt   (unchanged)
```

### Demo Directory (demo/)
```
✓ demo_presentation.py        (for presentations)
✓ ucas_debugger_colored.py    (colored version)
```

---

## What NOT to Deploy to Lambda

❌ **demo_presentation.py** - Only for local demos
❌ **ucas_debugger_colored.py** - Colored version for local only
❌ **COLORED_DEMO_GUIDE.md** - Documentation only

---

## Rollback Plan

If issues occur in production:

### Quick Rollback
```bash
cd /path/to/your/project/src/akamaivalidator-backup-YYYYMMDD

# Repackage original code
zip -r akamaivalidator-original.zip .

# Restore original Lambda
aws lambda update-function-code \
  --function-name akamaivalidator \
  --zip-file fileb://akamaivalidator-original.zip
```

### Rollback with Version History
```bash
# List Lambda versions
aws lambda list-versions-by-function --function-name akamaivalidator

# Rollback to specific version
aws lambda update-alias \
  --function-name akamaivalidator \
  --name production \
  --function-version PREVIOUS_VERSION_NUMBER
```

---

## Environment-Specific Configuration

### Development
```python
# In index.py
import os
from ucas_debugger import UCASDebugger

# Enable colored output for local dev
is_local = os.getenv('AWS_EXECUTION_ENV') is None
ucas = UCASDebugger(logger, colored_output=is_local)
```

### Production
```python
# In index.py
from ucas_debugger import UCASDebugger

# Always structured JSON in production
ucas = UCASDebugger(logger, colored_output=False)
```

---

## Testing Checklist

Before promoting to production:

- [ ] Backup created
- [ ] Local testing completed (colored output works)
- [ ] Dev Lambda deployed
- [ ] Test event executed successfully
- [ ] CloudWatch logs verified (structured JSON)
- [ ] CloudWatch Insights queries work
- [ ] Performance overhead < 50ms
- [ ] No errors in Lambda execution
- [ ] DynamoDB writes still working
- [ ] Validation results correct
- [ ] Rollback plan tested

---

## Next Steps

### Week 1: Deploy akamaivalidator
1. ✓ Run demo presentation for stakeholders
2. ✓ Deploy to dev environment
3. ✓ Validate CloudWatch logs
4. ✓ Run for 1 week alongside original

### Week 2: Create validator_template
1. Use akamaivalidator-ucas as reference
2. Create generic validator_template with UCAS
3. Document pattern for other validators

### Weeks 3-8: Roll out to remaining 18 validators
1. Use validator_template as starting point
2. Deploy 3-4 validators per week
3. Monitor performance and logs
4. Adjust as needed

---

## Support

### For Questions:
- Check COLORED_DEMO_GUIDE.md for demo help
- Check README_UCAS_IMPLEMENTATION.md for technical details
- Review CloudWatch logs for issues

### Common Issues:

**Q: Colors not showing locally?**
A: Make sure `colored_output=True` when running locally

**Q: No logs in CloudWatch?**
A: Check LOG_LEVEL environment variable (should be INFO or DEBUG)

**Q: Duration missing?**
A: Ensure method_start was called before method_stop

**Q: Performance slow?**
A: UCAS overhead is < 10ms; check actual method execution time

---

## Quick Reference

### Deploy to Dev
```bash
cd src/akamaivalidator-ucas
zip -r deploy.zip .
aws lambda update-function-code --function-name akamaivalidator-dev --zip-file fileb://deploy.zip
```

### Run Demo
```bash
cd demo
python demo_presentation.py
```

### View Logs
```bash
aws logs tail /aws/lambda/akamaivalidator-dev --follow
```

### Rollback
```bash
cd src/akamaivalidator-backup-YYYYMMDD
zip -r rollback.zip .
aws lambda update-function-code --function-name akamaivalidator --zip-file fileb://rollback.zip
```

---

## Summary

**For Demos:** Use `demo/` directory with colored output
**For Dev:** Deploy `akamaivalidator-ucas/` to dev Lambda
**For Prod:** Deploy `akamaivalidator-ucas/` to prod Lambda (after testing)

**All files ready - just follow the steps above!** 🚀
