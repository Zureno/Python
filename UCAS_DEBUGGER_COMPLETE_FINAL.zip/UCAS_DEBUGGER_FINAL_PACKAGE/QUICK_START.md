# UCAS Debugger - Quick Start Guide

## ⚡ Get Started in 30 Minutes

This guide gets you from zero to demo in 30 minutes.

---

## Step 1: Run the Demo (5 minutes)

### Show Management the Value

```bash
cd demo
python demo_presentation.py
```

**Press Enter** to advance through:
1. Before: Plain text logs
2. After: Colored structured logs
3. Performance analysis with visual bars
4. CloudWatch Insights queries
5. Before/After comparison table

**What they'll see:**
- 🔵 Blue method starts
- 🟢 Green fast operations
- 🔴 Red slow operations (bottlenecks!)
- 📊 Visual performance breakdown
- ✅ Clear before/after comparison

**Talking points:**
- "Debugging time: hours → minutes"
- "Bottlenecks: invisible → highlighted in red"
- "Logs: text search → structured queries"
- "Implementation: 80 lines of code per validator"

---

## Step 2: Test Locally (10 minutes)

### Verify the Code Works

```bash
cd production/akamaivalidator
python index.py
```

**Expected output:**
```json
{"level":"INFO","event":"method_start","method":"handler"...}
{"level":"INFO","event":"method_stop","method":"handler","duration_ms":2532.18...}
```

**What to check:**
- ✅ Structured JSON format
- ✅ `duration_ms` fields present
- ✅ `event` fields (method_start, method_stop, metrics)
- ✅ No errors

**If errors occur:**
- Check Python version (3.9+)
- Install dependencies: `pip install -r requirements.txt`
- Check AWS credentials if using real data

---

## Step 3: Deploy to Dev (15 minutes)

### Put It in AWS

```bash
cd production/akamaivalidator

# Create deployment package
zip -r akamaivalidator-ucas.zip .

# Deploy to Lambda
aws lambda update-function-code \
  --function-name akamaivalidator-dev \
  --zip-file fileb://akamaivalidator-ucas.zip

# Or create new function for side-by-side testing
aws lambda create-function \
  --function-name akamaivalidator-ucas-dev \
  --runtime python3.11 \
  --handler index.handler \
  --role arn:aws:iam::YOUR_ACCOUNT:role/lambda-execution-role \
  --zip-file fileb://akamaivalidator-ucas.zip \
  --timeout 300 \
  --memory-size 512
```

---

## Step 4: Validate (10 minutes)

### Test Event

Create `test-event.json`:
```json
{
  "identifier": "BFM",
  "control": "CDR-NSS3.4.2 - App01",
  "validator": {
    "type": "akamai",
    "criteria": ["akamai"]
  }
}
```

### Invoke Lambda

```bash
aws lambda invoke \
  --function-name akamaivalidator-ucas-dev \
  --payload file://test-event.json \
  response.json

# Check response
cat response.json
```

**Should return:**
```json
{
  "control": "CDR-NSS3.4.2 - App01",
  "passed": true,
  ...
}
```

### Check CloudWatch Logs

```bash
aws logs tail /aws/lambda/akamaivalidator-ucas-dev --follow
```

**Look for:**
```json
{"event":"method_start","method":"handler"...}
{"event":"method_stop","method":"get_akamai_onboarding_compliance","duration_ms":2206.45...}
{"event":"method_stop","method":"handler","duration_ms":2532.18...}
```

### Run CloudWatch Insights Query

Go to CloudWatch → Insights → Select log group → Run:

```sql
fields @timestamp, method, duration_ms
| filter event = "method_stop"
| sort duration_ms desc
| limit 10
```

**Should show:**
```
method                               duration_ms
get_akamai_onboarding_compliance    2206.45
write_result                        160.34
build_result                        15.23
validate_akamai                     5.12
```

---

## ✅ Success Checklist

After 30 minutes, you should have:

- [x] Demo ran successfully with colored output
- [x] Local testing shows structured JSON logs
- [x] Lambda deployed to dev environment
- [x] Test event executed successfully
- [x] CloudWatch logs show duration_ms
- [x] CloudWatch Insights query works

---

## 🎯 What You've Achieved

**You now have:**
- ✅ Working demo for presentations
- ✅ Production-ready code in dev
- ✅ Proof of concept validated
- ✅ Performance visibility enabled

**Next steps:**
- Week 1: Run for 1 week alongside original
- Week 2: Create validator_template with UCAS
- Weeks 3-8: Roll out to remaining 18 validators

---

## 🆘 Troubleshooting

### Demo doesn't show colors
```bash
# Make sure you're in the demo directory
cd demo
python demo_presentation.py
```

### Local test fails
```bash
# Install dependencies
pip install aws-lambda-powertools boto3

# Check Python version
python --version  # Should be 3.9+
```

### Lambda deployment fails
```bash
# Check AWS credentials
aws sts get-caller-identity

# Verify role exists
aws iam get-role --role-name lambda-execution-role
```

### No logs in CloudWatch
```bash
# Check Lambda configuration
aws lambda get-function-configuration --function-name akamaivalidator-ucas-dev

# Verify LOG_LEVEL environment variable
# Should be INFO or DEBUG
```

### CloudWatch Insights returns no results
- Wait 1-2 minutes for logs to appear
- Verify log group name matches
- Check query syntax (case-sensitive)

---

## 📚 Next Steps

### After Quick Start

1. **Read full docs:**
   - `docs/DEPLOYMENT_GUIDE.md` - Complete deployment process
   - `docs/OUTPUT_COMPARISON.md` - Understand log changes
   - `production/akamaivalidator/README_UCAS_IMPLEMENTATION.md` - Technical details

2. **Create JIRA stories:**
   - Copy from `jira_stories/UCAS_Debugger_JIRA_Stories.md`
   - Adjust story points based on team velocity
   - Plan 4-phase rollout

3. **Plan rollout:**
   - Week 1: Validate akamaivalidator in dev
   - Week 2: Create validator_template
   - Weeks 3-8: Roll out to 18 other validators

---

## 💡 Pro Tips

### For Demos
- Run `demo_presentation.py` on a large monitor
- Press Enter at your own pace
- Emphasize the performance breakdown (87% in Athena!)
- Show CloudWatch Insights queries live

### For Development
- Use colored output locally: `colored_output=True`
- Test with real data from dev environment
- Compare logs with original validator side-by-side
- Monitor performance overhead (should be < 10ms)

### For Deployment
- Deploy to new Lambda first (side-by-side testing)
- Run both versions for 1 week
- Compare results to verify identical behavior
- Promote to production only after validation

---

## 🎉 You're Ready!

You now have:
- ✅ A working demo
- ✅ Tested code
- ✅ Deployed Lambda
- ✅ Validated results

**Total time:** 30 minutes
**Next step:** Show the demo to your team!

---

## 📞 Need Help?

- **Demo issues:** Check `docs/COLORED_DEMO_GUIDE.md`
- **Deployment issues:** Check `docs/DEPLOYMENT_GUIDE.md`
- **Technical questions:** Check `production/akamaivalidator/README_UCAS_IMPLEMENTATION.md`
- **AWS issues:** Contact DevOps team

---

**Ready to scale to all 19 validators? See README.md for the full roadmap!**
