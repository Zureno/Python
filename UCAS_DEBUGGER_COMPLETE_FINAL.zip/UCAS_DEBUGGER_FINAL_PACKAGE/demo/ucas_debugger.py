"""
UCAS Debugger with Colored Console Output - For Demo & Local Testing
"""
import time
from datetime import datetime
from aws_lambda_powertools import Logger


class Colors:
    """ANSI color codes for terminal output"""
    # Method events
    START = '\033[94m'      # Blue - Method start
    STOP = '\033[92m'       # Green - Method stop
    METRICS = '\033[93m'    # Yellow - Metrics
    ERROR = '\033[91m'      # Red - Errors
    
    # Status indicators
    PASS = '\033[92m'       # Green - Pass status
    FAIL = '\033[91m'       # Red - Fail status
    WARNING = '\033[93m'    # Yellow - Warnings
    
    # Special
    HEADER = '\033[95m'     # Magenta - Headers
    BOLD = '\033[1m'        # Bold text
    UNDERLINE = '\033[4m'   # Underlined text
    
    # Reset
    END = '\033[0m'         # Reset color


class UCASDebugger:
    """
    UCAS Debugger wrapper with colored console output for demos.
    Shows color-coded logs locally while maintaining structured JSON in CloudWatch.
    
    Usage:
        ucas = UCASDebugger(logger, colored_output=True)  # For local demos
        ucas = UCASDebugger(logger, colored_output=False) # For Lambda (no colors)
    """
    
    def __init__(self, logger_instance: Logger, colored_output: bool = False):
        self.logger = logger_instance
        self.colored_output = colored_output
        self.start_time = None
        self.method_name = None
    
    def _color_print(self, color: str, message: str):
        """Print colored message to console if colored_output is enabled"""
        if self.colored_output:
            print(f"{color}{message}{Colors.END}")
    
    def method_start(self, method_name: str, **kwargs):
        """
        Log method start with optional parameters.
        Shows in BLUE when colored output is enabled.
        
        Args:
            method_name: Name of the method being instrumented
            **kwargs: Additional context parameters to log
        """
        self.method_name = method_name
        self.start_time = time.time()
        
        # Colored console output for demos
        if self.colored_output:
            params_str = ", ".join(f"{k}={v}" for k, v in kwargs.items())
            self._color_print(
                Colors.START + Colors.BOLD,
                f"▶ START: {method_name} ({params_str})"
            )
        
        # Structured logging for CloudWatch
        self.logger.info(
            f"Method started: {method_name}",
            extra={
                "event": "method_start",
                "method": method_name,
                "timestamp": datetime.utcnow().isoformat(),
                "parameters": kwargs
            }
        )
    
    def method_stop(self, method_name: str, **metrics):
        """
        Log method stop with duration and metrics.
        Shows in GREEN when colored output is enabled.
        
        Args:
            method_name: Name of the method being instrumented
            **metrics: Key metrics to log (e.g., records_processed=10)
        """
        duration_ms = None
        if self.start_time:
            duration_ms = round((time.time() - self.start_time) * 1000, 2)
        
        # Colored console output for demos
        if self.colored_output:
            metrics_str = ", ".join(f"{k}={v}" for k, v in metrics.items())
            duration_color = Colors.STOP if duration_ms and duration_ms < 1000 else Colors.WARNING
            self._color_print(
                duration_color + Colors.BOLD,
                f"■ STOP: {method_name} [{duration_ms}ms] ({metrics_str})"
            )
        
        # Structured logging for CloudWatch
        self.logger.info(
            f"Method completed: {method_name}",
            extra={
                "event": "method_stop",
                "method": method_name,
                "timestamp": datetime.utcnow().isoformat(),
                "duration_ms": duration_ms,
                "metrics": metrics
            }
        )
    
    def log_metrics(self, **metrics):
        """
        Log key metrics during execution.
        Shows in YELLOW when colored output is enabled.
        
        Args:
            **metrics: Metrics to log
        """
        # Colored console output for demos
        if self.colored_output:
            metrics_str = ", ".join(f"{k}={v}" for k, v in metrics.items())
            self._color_print(
                Colors.METRICS,
                f"  ℹ METRICS: {self.method_name} → {metrics_str}"
            )
        
        # Structured logging for CloudWatch
        self.logger.debug(
            "Method metrics",
            extra={
                "event": "metrics",
                "method": self.method_name,
                "metrics": metrics
            }
        )
    
    def log_error(self, error_type: str, error_message: str):
        """
        Log error with colored output.
        Shows in RED when colored output is enabled.
        
        Args:
            error_type: Type of error
            error_message: Error message
        """
        # Colored console output for demos
        if self.colored_output:
            self._color_print(
                Colors.ERROR + Colors.BOLD,
                f"✖ ERROR: {self.method_name} → {error_type}: {error_message}"
            )
        
        # Structured logging for CloudWatch
        self.logger.error(
            f"Error in {self.method_name}",
            extra={
                "event": "error",
                "method": self.method_name,
                "error_type": error_type,
                "error_message": error_message
            }
        )
    
    def print_summary(self, title: str, status: str, **details):
        """
        Print colored summary for demo purposes.
        
        Args:
            title: Summary title
            status: PASS or FAIL
            **details: Additional details to display
        """
        if not self.colored_output:
            return
        
        print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*80}{Colors.END}")
        print(f"{Colors.HEADER}{Colors.BOLD}{title}{Colors.END}")
        print(f"{Colors.HEADER}{Colors.BOLD}{'='*80}{Colors.END}")
        
        status_color = Colors.PASS if status == "PASS" else Colors.FAIL
        print(f"{status_color}{Colors.BOLD}Status: {status}{Colors.END}")
        
        for key, value in details.items():
            key_display = key.replace('_', ' ').title()
            print(f"{Colors.BOLD}{key_display}:{Colors.END} {value}")
        
        print(f"{Colors.HEADER}{Colors.BOLD}{'='*80}{Colors.END}\n")
