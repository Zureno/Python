"""
UCAS Debugger Demo Script with Colored Output
Run this to see the visual difference between before and after
"""
import json
import time
from datetime import datetime


class Colors:
    """ANSI color codes"""
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'


def print_header(title: str):
    """Print colored header"""
    print(f"\n{Colors.MAGENTA}{Colors.BOLD}{'='*80}{Colors.END}")
    print(f"{Colors.MAGENTA}{Colors.BOLD}{title:^80}{Colors.END}")
    print(f"{Colors.MAGENTA}{Colors.BOLD}{'='*80}{Colors.END}\n")


def print_section(title: str):
    """Print section header"""
    print(f"\n{Colors.CYAN}{Colors.BOLD}{title}{Colors.END}")
    print(f"{Colors.CYAN}{'-'*60}{Colors.END}")


def demo_before():
    """Show logs WITHOUT UCAS Debugger"""
    print_header("BEFORE: Without UCAS Debugger")
    
    print(f"{Colors.BOLD}Plain text logs - hard to parse:{Colors.END}\n")
    
    logs = [
        "INFO Querying Akamai onboarding data for AppCI BFM",
        "INFO Athena query for akamai validator (id=abc-123) executed successfully",
        "INFO Akamai onboarding & coverage compliance for BFM: PASS",
        "INFO Akamai validation PASSED — criteria matched",
        "INFO Validation result: {\"control\":\"CDR-NSS3.4.2\",\"passed\":true,...}",
        "INFO Successfully updated results for identifier=BFM",
    ]
    
    for log in logs:
        print(f"  {log}")
        time.sleep(0.3)
    
    print(f"\n{Colors.RED}Problems:{Colors.END}")
    print(f"  ✗ No execution timing")
    print(f"  ✗ No method boundaries")
    print(f"  ✗ No performance metrics")
    print(f"  ✗ Hard to trace flow")
    print(f"  ✗ Can't query by method")


def demo_after():
    """Show logs WITH UCAS Debugger"""
    print_header("AFTER: With UCAS Debugger - Colored Output")
    
    print(f"{Colors.BOLD}Structured logs with color-coded events:{Colors.END}\n")
    
    # Simulate method execution with colors
    methods = [
        {
            "name": "handler",
            "start_params": "request_id=abc-123, function_name=akamaivalidator",
            "duration": 2532.18,
            "metrics": "final_status=PASS, result_size=842"
        },
        {
            "name": "get_akamai_onboarding_compliance",
            "start_params": "appci=BFM",
            "duration": 2206.45,
            "metrics": "compliance_status=PASS, pass_count=10, fail_count=0"
        },
        {
            "name": "validate_akamai",
            "start_params": "validator_type=akamai, criteria=['akamai']",
            "duration": 5.12,
            "metrics": "validation_result=PASS, criteria_matched=True"
        },
        {
            "name": "build_result",
            "start_params": "identifier=BFM, control=CDR-NSS3.4.2",
            "duration": 15.23,
            "metrics": "result_size=842, evidence_length=156"
        },
        {
            "name": "write_result",
            "start_params": "identifier=BFM, table=eqa-validation-results-table",
            "duration": 160.34,
            "metrics": "write_status=SUCCESS"
        },
    ]
    
    for method in methods:
        # Method start (BLUE)
        print(f"{Colors.BLUE}{Colors.BOLD}▶ START:{Colors.END} {method['name']} ({method['start_params']})")
        time.sleep(0.2)
        
        # Metrics (YELLOW)
        if "appci" in method['start_params'] or "identifier" in method['start_params']:
            print(f"{Colors.YELLOW}  ℹ METRICS:{Colors.END} {method['name']} → processing data...")
            time.sleep(0.2)
        
        # Method stop (GREEN or YELLOW based on duration)
        duration_color = Colors.GREEN if method['duration'] < 1000 else Colors.YELLOW
        print(f"{duration_color}{Colors.BOLD}■ STOP:{Colors.END} {method['name']} [{method['duration']}ms] ({method['metrics']})")
        time.sleep(0.2)
        print()
    
    print(f"\n{Colors.GREEN}Benefits:{Colors.END}")
    print(f"  ✓ Clear execution timeline")
    print(f"  ✓ Method boundaries visible")
    print(f"  ✓ Duration tracking per method")
    print(f"  ✓ Key metrics at each step")
    print(f"  ✓ Easy to spot bottlenecks")


def demo_performance_analysis():
    """Show performance breakdown"""
    print_header("Performance Analysis - Visual Breakdown")
    
    methods = [
        ("get_akamai_onboarding_compliance", 2206.45, 87.1),
        ("write_result", 160.34, 6.3),
        ("build_result", 15.23, 0.6),
        ("validate_akamai", 5.12, 0.2),
    ]
    
    print(f"{Colors.BOLD}Method Execution Times:{Colors.END}\n")
    
    for name, duration, percentage in methods:
        # Color based on duration
        if duration > 1000:
            color = Colors.RED
        elif duration > 100:
            color = Colors.YELLOW
        else:
            color = Colors.GREEN
        
        # Create visual bar
        bar_length = int(percentage / 2)  # Scale to max 50 chars
        bar = "█" * bar_length
        
        print(f"{color}{name:40} {bar} {duration:8.2f}ms ({percentage:5.1f}%){Colors.END}")
    
    print(f"\n{Colors.BOLD}Total Duration: 2532.18ms{Colors.END}")
    
    print(f"\n{Colors.RED}{Colors.BOLD}Bottleneck Identified:{Colors.END}")
    print(f"  → Athena query takes 87% of execution time (2206ms)")
    print(f"  → Consider caching or query optimization")
    
    print(f"\n{Colors.GREEN}{Colors.BOLD}Fast Operations:{Colors.END}")
    print(f"  → Validation logic is efficient (5ms)")
    print(f"  → Result building is fast (15ms)")


def demo_cloudwatch_insights():
    """Show CloudWatch Insights query examples"""
    print_header("CloudWatch Insights - Queryable Logs")
    
    queries = [
        {
            "name": "Find Slowest Methods",
            "query": """fields @timestamp, method, duration_ms
| filter service = "akamaivalidator-lambda"
| filter event = "method_stop"
| sort duration_ms desc
| limit 20"""
        },
        {
            "name": "Track Success Rate",
            "query": """fields @timestamp, metrics.final_status
| filter service = "akamaivalidator-lambda"
| filter method = "handler"
| stats count() by metrics.final_status"""
        },
        {
            "name": "Monitor Athena Performance",
            "query": """fields @timestamp, duration_ms
| filter method = "get_akamai_onboarding_compliance"
| stats avg(duration_ms), max(duration_ms)"""
        },
    ]
    
    for i, q in enumerate(queries, 1):
        print(f"\n{Colors.CYAN}{Colors.BOLD}Query {i}: {q['name']}{Colors.END}")
        print(f"{Colors.YELLOW}{q['query']}{Colors.END}")
    
    print(f"\n{Colors.GREEN}{Colors.BOLD}All queries work because logs are structured JSON!{Colors.END}")


def demo_comparison_summary():
    """Show final comparison"""
    print_header("Summary - Before vs After")
    
    comparison = [
        ("Execution Visibility", "✗ None", "✓ Full method trace"),
        ("Performance Metrics", "✗ No timing", "✓ Duration per method"),
        ("Bottleneck Detection", "✗ Manual analysis", "✓ Automatic (87% in Athena)"),
        ("Error Context", "✗ Stack trace only", "✓ Full method context"),
        ("CloudWatch Queries", "✗ Text search only", "✓ Structured queries"),
        ("Debugging Time", "✗ Hours", "✓ Minutes"),
    ]
    
    print(f"\n{Colors.BOLD}{'Feature':<25} {'Before':<25} {'After':<25}{Colors.END}")
    print(f"{Colors.CYAN}{'-'*75}{Colors.END}")
    
    for feature, before, after in comparison:
        before_colored = f"{Colors.RED}{before}{Colors.END}"
        after_colored = f"{Colors.GREEN}{after}{Colors.END}"
        print(f"{feature:<25} {before_colored:<34} {after_colored:<34}")
    
    print(f"\n{Colors.GREEN}{Colors.BOLD}Implementation Impact:{Colors.END}")
    print(f"  • Added 1 new file (ucas_debugger.py)")
    print(f"  • Modified 4 files (index, data, validate, output)")
    print(f"  • Zero changes to business logic")
    print(f"  • Less than 10ms overhead")
    print(f"  • Ready to deploy!")


def run_full_demo():
    """Run the complete demo"""
    print(f"\n{Colors.BOLD}{Colors.UNDERLINE}UCAS DEBUGGER DEMO{Colors.END}")
    print(f"{Colors.BOLD}Live Comparison: Before vs After{Colors.END}")
    
    input(f"\n{Colors.CYAN}Press Enter to see BEFORE (without UCAS Debugger)...{Colors.END}")
    demo_before()
    
    input(f"\n{Colors.CYAN}Press Enter to see AFTER (with UCAS Debugger)...{Colors.END}")
    demo_after()
    
    input(f"\n{Colors.CYAN}Press Enter to see Performance Analysis...{Colors.END}")
    demo_performance_analysis()
    
    input(f"\n{Colors.CYAN}Press Enter to see CloudWatch Insights examples...{Colors.END}")
    demo_cloudwatch_insights()
    
    input(f"\n{Colors.CYAN}Press Enter to see Final Summary...{Colors.END}")
    demo_comparison_summary()
    
    print(f"\n{Colors.MAGENTA}{Colors.BOLD}{'='*80}{Colors.END}")
    print(f"{Colors.GREEN}{Colors.BOLD}Demo Complete! Ready to implement across all 19 validators.{Colors.END}")
    print(f"{Colors.MAGENTA}{Colors.BOLD}{'='*80}{Colors.END}\n")


if __name__ == "__main__":
    run_full_demo()
