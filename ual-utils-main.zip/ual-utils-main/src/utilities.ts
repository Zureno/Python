import * as readline from "readline";
import { Writable } from "stream";
import keytar from "keytar";
import { stat } from "fs";
import { promisify } from "util";
import { homedir } from "os";
import { sep } from "path";

import { LoadCredentials } from "./commands/tss/load-credentials.js";
import { NPPID_CREDENTIAL_NAME, PPID_CREDENTIAL_NAME, ProvidedId } from "./constants.js";

const statP = promisify(stat);

export const getInput = async (message: string, muted?: boolean) => {
  let mutedStatus = false;
  const mutableStdout = new Writable({
    write: (
      chunk: string | Uint8Array,
      // eslint-disable-next-line @typescript-eslint/naming-convention
      _encoding: any,
      callback: () => void
    ) => {
      if (!mutedStatus) process.stdout.write(chunk);
      callback();
    },
  });

  const rd = readline.createInterface({
    input: process.stdin,
    output: mutableStdout,
    terminal: true,
  });

  const result: string = await new Promise((resolve) => {
    rd.question(message, (input) => {
      resolve(input);
    });
    mutedStatus = muted || false;
  });
  if (muted) console.log();
  rd.close();
  return result;
};

export const retrieveCredentials = (name: string): Promise<{ username: string; password: string } | undefined> => {
  return new Promise((resolve) => {
    keytar
      .findCredentials(name)
      .then((credentials) => {
        if (credentials.length !== 0) {
          resolve({
            username: credentials[0].account,
            password: credentials[0].password,
          });
        } else {
          resolve(undefined);
        }
      })
      .catch(() => {
        resolve(undefined);
      });
  });
};

export const credentialName = (id: ProvidedId): string => {
  switch (id) {
    case "none":
      return "";
    case "ppid":
      return PPID_CREDENTIAL_NAME;
    case "nppid":
      return NPPID_CREDENTIAL_NAME;
  }
};

export const checkReload = async (otp?: string) => {
  const timestampFile = `${homedir()}${sep}.ual-utils-timestamp`;
  const sixHours = 6 * 60 * 60 * 1000;
  let reload = false;

  await statP(timestampFile)
    .then((stats) => (reload = Date.now() > stats.mtimeMs + sixHours))
    .catch(() => (reload = true));

  if (reload) {
    await new LoadCredentials().handler({
      args: {
        _: [],
        $0: "test",
        otp: otp,
      },
    });
  }
};
