"use strict";
import { Arguments, Argv } from "yargs";
import { fromNodeProviderChain } from "@aws-sdk/credential-providers";
import { Command, CommandOptions } from "../command-api.js";
import axios from "axios";

interface Opts {
  profile: string;
}

interface Credentials {
  sessionId: string;
  sessionKey: string;
  sessionToken: string;
}

/**
 * Command to handle AWS functions for United users
 */
export class AwsOpenConsole implements Command {
  // Identity url for login

  command = ["open-console"];

  description = "Opens the AWS console for an authenticated AWS profile";
  builder = (yargs: Argv) =>
    yargs.option("profile", {
      type: "string",
      default: "default",
      alias: "p",
      requiresArg: false,
      desc: "profile to use when opening console",
    });

  handler = async (options: CommandOptions) => {
    const args = options.args as Arguments<Opts>;
    const credentials = await this.getCredentials(args.profile);
    const signInToken = await this.getSigningToken(credentials);
    await this.openConsole(signInToken);

    return 0;
  };

  getCredentials = async (profile: string): Promise<Credentials> => {
    const credentials = fromNodeProviderChain({
      profile: profile,
    });

    try {
      const awsCredentials = await credentials();
      return {
        sessionId: awsCredentials.accessKeyId,
        sessionKey: awsCredentials.secretAccessKey,
        sessionToken: awsCredentials.sessionToken as string,
      };
    } catch (err) {
      throw new Error("Unable to load credentials. Please ensure that your profile is correct and that it exists.");
    }
  };

  getSigningToken = async (credentials: Credentials): Promise<string> => {
    return new Promise((resolve, reject) => {
      axios
        .get("https://signin.aws.amazon.com/federation", {
          params: {
            Action: "getSigninToken",
            DurationSeconds: "43200",
            Session: JSON.stringify(credentials),
          },
        })
        // eslint-disable-next-line @typescript-eslint/naming-convention
        .then((response: { data: { SigninToken: string } }) => {
          try {
            resolve(response.data.SigninToken);
          } catch (err) {
            reject(err);
          }
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  openConsole = async (signInToken: string) => {
    const requestParameters = [
      "Action=login",
      `Destination=${encodeURIComponent("https://console.aws.amazon.com/")}`,
      `SigninToken=${signInToken}`,
      `Issuer=${encodeURIComponent("https://example.com")}`,
    ];

    await import("open").then((open) => {
      open
        .default(`https://us-east-1.signin.aws.amazon.com/federation?${requestParameters.join("&")}`, {
          wait: false,
        })
        .catch((err) => {
          throw err;
        });
    });
  };
}
