"use strict";
import { Arguments, Argv } from "yargs";
import { Command, CommandOptions } from "../command-api.js";
import { Client } from "ldapts";
import { retrieveCredentials } from "../../utilities.js";
import { GLOBAL_CREDENTIAL_NAME } from "../../constants.js";

interface Opts {
  applicationCi: string;
  showRoles: boolean;
  showType: boolean;
  showMembers: boolean;
  showName: boolean;
  filterEnvironment: string | null;
  pcr: boolean;
}

class RoleOrGroup {
  name: string;
  members: string[];
  groupMembers: RoleOrGroup[];

  constructor(name: string) {
    this.name = name;
    this.members = [];
    this.groupMembers = [];
  }

  addMembers(members: string[]) {
    this.members.push(...members);
    this.members = [...new Set(this.members)].sort();
  }

  addGroupMembers(group: RoleOrGroup) {
    this.groupMembers.push(group);
    this.groupMembers = this.groupMembers.sort((a, b) => (a.name < b.name ? -1 : 1));
  }

  render = (indent: string, showMembers: boolean) => {
    console.log(`${indent}- ${this.name}`);
    if (showMembers) {
      console.log(`${indent}  Members:`);
      this.members.forEach((member) => {
        console.log(`${indent}    - ${member}`);
      });
      this.groupMembers.forEach((group) => {
        group.render(`${indent}    `, showMembers);
      });
    }
  };
}

class Account {
  accountNumber: string;
  type: AccountType;
  roles: RoleOrGroup[];
  name: string;

  constructor(accountNumber: string, type: AccountType, name: string) {
    this.accountNumber = accountNumber;
    this.type = type;
    this.roles = [];
    this.name = name;
  }

  addRole(role: RoleOrGroup) {
    this.roles.push(role);
    this.roles = this.roles.sort((a, b) => (a.name < b.name ? -1 : 1));
  }

  render = (showType: boolean, showRoles: boolean, showMembers: boolean, showName: boolean) => {
    console.log(` - ${this.accountNumber}${showName ? ` [${this.name}]` : ""}`);
    if (showType) {
      console.log(`   Type: ${this.type}`);
    }
    if (showRoles || showMembers) {
      this.roles.forEach((role) => role.render("   ", showMembers));
    }
  };
}

enum AccountType {
  MicroAccount = "Micro Account",
  HubAccount = "Hub Account",
}

enum AwsEnvironment {
  DEV = "DEV",
  QA = "QA",
  STG = "STG",
  PRD = "PRD",
}

/**
 * Command to handle AWS functions for United users
 */
export class AwsListAccounts implements Command {
  // Identity url for login

  command = ["list-accounts"];

  description = "Lists all AWS accounts for an application CI";
  builder = (yargs: Argv) =>
    yargs
      .option("application-ci", {
        type: "string",
        alias: "a",
        requiresArg: true,
        desc: "List accounts for this CI",
      })
      .option("show-roles", {
        type: "boolean",
        alias: "r",
        default: false,
        requiresArg: false,
        desc: "Whether to show roles for each account",
      })
      .option("show-type", {
        type: "boolean",
        alias: "t",
        default: false,
        requiresArg: false,
        desc: "Whether to show type for each account",
      })
      .option("show-members", {
        type: "boolean",
        alias: "m",
        default: false,
        requiresArg: false,
        desc: "Whether to show members for each role",
      })
      .option("show-name", {
        type: "boolean",
        alias: "n",
        default: false,
        requiresArg: false,
        desc: "Whether to show name for each account, defaults to false except when searching PCR",
      })
      .option("filter-environment", {
        type: "string",
        alias: "e",
        default: null,
        requiresArg: false,
        desc: "Filter to a specific environment (dev, qa, stg, prd)",
      })
      .option("pcr", {
        type: "boolean",
        default: false,
        requiresArg: false,
        desc: "Whether to search for this application CI in PCR accounts",
      });

  handler = async (options: CommandOptions) => {
    const args = options.args as Arguments<Opts>;

    if (!args.applicationCi) {
      throw new Error("--application-ci (-a) must be provided. Add -h to show help.");
    }

    let environments = Object.values(AwsEnvironment);
    if (args.filterEnvironment) {
      const env = args.filterEnvironment.toUpperCase();
      if (!Object.values(AwsEnvironment).includes(env as AwsEnvironment)) {
        throw new Error(
          `Invalid environment specified: ${env}. Valid options are: ${Object.values(AwsEnvironment).join(", ")}`
        );
      }
      environments = environments.filter((e) => e === env);
    }

    const applicationCi = args.applicationCi.toUpperCase();

    const client = await this.bind();

    try {
      for (const env of args.pcr ? ["PCR"] : environments) {
        const accounts = await this.getAccounts(client, env, applicationCi);
        console.log(env);
        accounts.forEach((account) =>
          account.render(args.showType, args.showRoles, args.showMembers, args.showName || args.pcr)
        );
      }
    } finally {
      await client.unbind();
    }

    return 0;
  };

  bind = async (): Promise<Client> => {
    const client = new Client({
      url: "ldaps://ldapsndc.global.ual.com:636",
      tlsOptions: {
        rejectUnauthorized: false,
      },
    });

    const credentials = await retrieveCredentials(GLOBAL_CREDENTIAL_NAME);

    if (!credentials) {
      throw new Error("Failed to retrieve global credentials. Please run `ual tss load-credentials`");
    }

    let path = `CN=${credentials.username},OU=${
      credentials.username.substring(0, 1) == "u" ? "UnitedActive" : "AffiliatedPeople"
    },OU=United,OU=Accounts,DC=global,DC=ual,DC=com`;

    await client.bind(path, credentials.password);
    return client;
  };

  getAccounts = async (
    client: Client,
    awsEnvironment: AwsEnvironment | string,
    applicationCi: string
  ): Promise<Account[]> => {
    const { searchEntries } = await client.search(
      `OU=${awsEnvironment},OU=AWS,OU=Special Groups,OU=Groups,DC=global,DC=ual,DC=com`,
      {
        filter: `(cn=*_${applicationCi}-*)`,
      }
    );

    let accounts: { [key: string]: Account } = {};

    await Promise.all(
      searchEntries.map(async (entry) => {
        const accountNumber = entry.dn.split(",")[1].split("-")[1];
        if (!Object.keys(accounts).includes(accountNumber)) {
          const accountType = entry.dn.includes("_MA-") ? AccountType.MicroAccount : AccountType.HubAccount;
          accounts[accountNumber] = new Account(accountNumber, accountType, entry.cn as string);
        }
        const role = new RoleOrGroup((entry.cn as string).split("-").pop() as string);
        accounts[accountNumber].addRole(role);
        if (entry.member) {
          const userNames = await this.getUserNames(client, entry.member as string | string[], role);
        }
      })
    );

    // await this.getUserName(client, searchEntries[0].member[0] as string);

    return Object.values(accounts).sort((a, b) => (a.accountNumber < b.accountNumber ? -1 : 1));
  };

  getUserNames = async (client: Client, member: string | string[], roleOrGroup: RoleOrGroup): Promise<void> => {
    if (!member) {
      return;
    }
    const membersAsList = Array.isArray(member) ? member : [member];
    const effectiveMembers = membersAsList.filter((m) => m.includes("OU=Special Accounts"));
    const userNames = await Promise.all(
      effectiveMembers.map(async (member) => {
        const { searchEntries } = await client.search(member);
        return searchEntries[0]?.displayName || null;
      })
    );

    // Retry for groups
    const groups = membersAsList.filter((m) => m.includes("OU=Groups"));
    if (groups.length > 0) {
      await Promise.all(
        groups.map(async (groupPath) => {
          const { searchEntries } = await client.search(groupPath);
          if (searchEntries.length > 0) {
            const group = new RoleOrGroup(searchEntries[0].cn as string);
            await this.getUserNames(client, searchEntries[0].member as string | string[], group);
            roleOrGroup.addGroupMembers(group);
          }
        })
      );
    }

    roleOrGroup.addMembers(userNames.filter((name) => name !== null) as string[]);
  };
}
