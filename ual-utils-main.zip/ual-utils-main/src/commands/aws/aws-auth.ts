import { Arguments, Argv } from "yargs";
import jsdom from "jsdom";
import keytar from "keytar";
import * as readline from "readline";
import { Writable } from "stream";

import { XMLParser } from "fast-xml-parser";
import {
  STSClient,
  STSServiceException,
  AssumeRoleWithSAMLCommand,
  AssumeRoleWithSAMLCommandOutput,
  Credentials,
} from "@aws-sdk/client-sts";
import { NodeHttpHandler } from "@aws-sdk/node-http-handler";
import { HttpsProxyAgent } from "hpagent";
import * as fs from "fs";
import * as path from "path";
import * as ini from "ini";
import * as os from "os";
import * as utils from "../../utilities.js";

import { Command, CommandOptions } from "../command-api.js";
import { ProvidedId } from "../../constants.js";

type OutputType = ["json", "text", "yaml", "table", "yaml-stream"];
interface Opts {
  user: string;
  password: string;
  output: OutputType;
  profile: string;
  role: string;
  region: string;
  id: ProvidedId;
  prompt: boolean;
  accountNames: boolean;
  noSave: boolean;
  filters: string[];
  reset: boolean;
  credSource: boolean;
  otp: string;
}

/**
 * Command to handle AWS functions for United users
 */
export class AwsAuth implements Command {
  // Identity url for login
  identityUrl = "https://adfs.ual.com/adfs/ls/IdpInitiatedSignOn.aspx?loginToRp=urn:amazon:webservices";

  command = ["auth"];

  description = "Configures authentication for AWS CLI";
  builder = (yargs: Argv) =>
    yargs
      .option("user", {
        type: "string",
        default: "",
        alias: "u",
        requiresArg: false,
        desc: "user id for authentication (i.e. u123456.smith)",
      })
      .option("password", {
        type: "string",
        default: "",
        alias: "p",
        requiresArg: false,
        desc: "user password for authentication",
      })
      .option("output", {
        choices: ["json", "text", "yaml", "table", "yaml-stream"],
        default: "json",
        requiresArg: false,
        desc: "AWS CLI output format to use as default",
      })
      .option("profile", {
        type: "string",
        default: "default",
        requiresArg: false,
        desc: "profile name to assign for AWS CLI",
      })
      .option("role", {
        type: "string",
        default: "",
        requiresArg: false,
        desc: "name of AWS role to assume",
      })
      .option("region", {
        type: "string",
        default: "us-east-2",
        requiresArg: false,
        desc: "AWS region to use as default",
      })
      .option("id", {
        type: "string",
        default: "nppid",
        alias: "i",
        requiresArg: false,
        description: 'use "ppid", "nppid" or "none"',
      })
      .option("prompt", {
        type: "boolean",
        default: false,
        requiresArg: false,
        desc: "prompt for username and password even if saved",
      })
      .option("account-names", {
        type: "boolean",
        default: false,
        requiresArg: false,
        alias: "a",
        desc: "display account names next to roles",
      })
      .option("no-save", {
        type: "boolean",
        default: false,
        requiresArg: false,
        description: "prevents saving these credentials in the keystore",
      })
      .option("filters", {
        type: "array",
        requiresArg: false,
        alias: "f",
        desc: "space-separated, case-insensitive filters to limit role list",
      })
      .option("reset", {
        type: "boolean",
        default: false,
        requiresArg: false,
        description: "reset saved username and password. --id must also be provided",
      })
      .option("cred-source", {
        type: "boolean",
        default: false,
        requiresArg: false,
        desc: "run the process for AWS credential sourcing",
      })
      .option("otp", {
        type: "string",
        alias: "o",
        requiresArg: false,
        desc: "Duo one time password to use for authentication",
      });

  handler = async (options: CommandOptions) => {
    const args = options.args as Arguments<Opts>;
    // Check inputs
    const providedId = args.id;

    if (args.reset && providedId === "none") {
      throw new Error("If --reset provided, --id must be specified as well.");
    }

    if (providedId === "none" && !args.noSave) {
      console.warn(
        "Entered credentials will not be saved. Provide --id or --no-save to save your credentials or silence this warning."
      );
    }

    // Reset and exit if requested
    if (args.reset) {
      await this.resetUsernameAndPassword(providedId);
      return 0;
    }

    // Get username and password from CLI or save
    const credentials = await this.getUsernameAndPassword(args.user, args.password, providedId, args.prompt, args.otp);

    // Authenticate
    const assertion = await this.getAuthToken(credentials.username, credentials.password);

    // Get all available roles
    const roles = this.getRoles(assertion, args.filters);

    // Pick role or use command line input
    let selectedRole: string | undefined;
    if (args.role) {
      selectedRole = roles.find((r) => r.endsWith(args.role));
      if (!selectedRole) {
        console.error(`role not found: ${args.role}`);
      }
    }
    if (!selectedRole) {
      if (args.credSource) {
        console.error("valid role must be provided for credential sourcing");
        return 1;
      }
      selectedRole = await this.selectRole(roles, args.accountNames, assertion);
    }

    // Save username and password
    await this.saveUsernameAndPassword(providedId, credentials.username, credentials.password);

    // Send assume role command
    const awsCredentials = await this.assumeRole(assertion, args.region, selectedRole);

    if (!awsCredentials) {
      throw new Error("Credentials could not be retrieved");
    }

    this.writeCredentials(args.credSource, args.profile, args.output, awsCredentials, roles, selectedRole);
    return 0;
  };

  // Get an input from the console
  getInput = async (message: string, muted?: boolean) => {
    let mutedStatus = false;
    const mutableStdout = new Writable({
      write: (
        chunk: string | Uint8Array,
        // eslint-disable-next-line @typescript-eslint/naming-convention
        _encoding: any,
        callback: () => void
      ) => {
        if (!mutedStatus) process.stdout.write(chunk);
        callback();
      },
    });

    const rd = readline.createInterface({
      input: process.stdin,
      output: mutableStdout,
      terminal: true,
    });

    const result: string = await new Promise((resolve) => {
      rd.question(message, (input) => {
        resolve(input);
      });
      mutedStatus = muted || false;
    });
    if (muted) console.log();
    rd.close();
    return result;
  };

  // Get some hints for users entering credentials
  getHints = (
    id: ProvidedId,
    retrievedCredentials?: { username: string; password: string }
  ): {
    usernameHint: string;
    passwordHint: string;
  } => {
    if (retrievedCredentials) {
      return {
        usernameHint: `[default: ${retrievedCredentials.username}]`,
        passwordHint: "[default: saved password]",
      };
    }
    return {
      usernameHint: `(like u123456.smith${id === "ppid" ? ".p" : ""})`,
      passwordHint: "",
    };
  };

  // Get username and password from options, key store, or input

  getUsernameAndPassword = async (
    inputUsername: string,
    inputPassword: string,
    id: ProvidedId,
    prompt: boolean,
    otp?: string
  ): Promise<{ username: string; password: string }> => {
    await utils.checkReload(otp);
    const retrievedCredentials = await utils.retrieveCredentials(utils.credentialName(id));

    const hints = this.getHints(id, retrievedCredentials);
    let username = inputUsername || retrievedCredentials?.username;
    let password = inputPassword || retrievedCredentials?.password;

    if (prompt || !username) {
      username = await this.getInput(`Enter username ${hints.usernameHint}: `);
      if (!username) {
        throw new Error("Username cannot be empty.");
      }
    }

    if (prompt || !password) {
      password = await this.getInput(`Enter password${hints.passwordHint}: `, true);
      if (!password) {
        throw new Error("Password cannot be empty.");
      }
    }

    return { username, password };
  };

  // Save username and password
  saveUsernameAndPassword = async (id: ProvidedId, username: string, password: string) => {
    // Check if credentials already exist
    if (id === "none") {
      throw new Error("cannot save user/password when no id is provided");
    }
    await this.resetUsernameAndPassword(id);
    await keytar.setPassword(utils.credentialName(id), username, password);
  };

  // Reset username and password
  resetUsernameAndPassword = async (id: ProvidedId) => {
    if (id === "none") {
      throw new Error("reset called with no id");
    }

    // Check if credentials already exist
    await new Promise((resolve) => {
      keytar
        .findCredentials(utils.credentialName(id))
        .then(async (credentials) => {
          await Promise.all(credentials.map((cred) => keytar.deletePassword(utils.credentialName(id), cred.account)));
          resolve(null);
        })
        .catch(() => {
          resolve(null);
        });
    });
  };

  // Get auth token
  getAuthToken = async (username: string, password: string): Promise<string> => {
    const samlString = 'name="SAMLResponse" value="';
    const formData = new URLSearchParams({
      username: `global\\${username}`,
      password: password,
    });

    // First request to get cookies
    const firstResponse = await fetch(this.identityUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: formData,
      redirect: "manual",
    });

    if (!firstResponse.ok && firstResponse.status !== 302) {
      throw new Error(`Authentication failed: HTTP ${firstResponse.status}`);
    }

    // Extract cookies from response
    const setCookieHeaders = firstResponse.headers.get("set-cookie") || "";
    const cookies = setCookieHeaders
      .split(", ")
      .map((cookie) => cookie.split(";")[0])
      .join("; ");

    // Second request with cookies to get SAML response
    const secondResponse = await fetch(this.identityUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: cookies,
      },
      body: formData,
    });

    if (!secondResponse.ok) {
      throw new Error(`SAML authentication failed: HTTP ${secondResponse.status}`);
    }

    const body = await secondResponse.text();

    if (!body.includes(samlString)) {
      throw new Error("Invalid SAML response");
    }

    return body.split(samlString)[1].split('"')[0];
  };

  // Get list of accounts
  getAccountList = async (assertion: string): Promise<{ [key: string]: string }> => {
    const formData = new URLSearchParams({
      SAMLResponse: assertion,
    });

    const response = await fetch("https://signin.aws.amazon.com:443/saml", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Failed to get account list: HTTP ${response.status}`);
    }

    const body = await response.text();
    const dom = new jsdom.JSDOM(body);
    const accounts: { [key: string]: string } = {};

    dom.window.document.querySelectorAll(".saml-account-name").forEach((el) => {
      const segments = (el.textContent as string).split(" ");
      if (segments.length === 3) {
        accounts[segments[2].replace("(", "").replace(")", "")] = segments[1];
      } else {
        accounts[segments[1].replace("(", "").replace(")", "")] = "";
      }
    });

    return accounts;
  };

  getRoles = (assertion: string, filters?: string[]): string[] => {
    const buff = Buffer.from(assertion, "base64");
    const parser = new XMLParser();
    const assertionObject = parser.parse(buff) as { [key: string]: any };
    let roles: string[];
    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    const rolesObject = assertionObject["samlp:Response"].Assertion.AttributeStatement.Attribute[1]
      .AttributeValue as string;

    if (typeof rolesObject === "string") {
      roles = [rolesObject];
    } else {
      roles = rolesObject;
    }
    roles = roles.map((s) => s.split(",")[1]);

    if (filters && filters.length > 0) {
      const lowerCaseFilters = filters.map((filter) => String(filter).toLowerCase());
      roles = roles.filter((role) => {
        const lowercaseRole = role.toLowerCase();
        for (const filter of lowerCaseFilters) {
          if (!lowercaseRole.includes(filter)) {
            return false;
          }
        }
        return true;
      });
    }
    return roles;
  };

  private printRole = (role: string, index: number, accounts?: { [key: string]: string }) => {
    const roleName = role.split("/").pop() as string;
    const accountNumber = role.substring(13, 25);
    const accountName = accounts?.[accountNumber] ?? "";
    const indexString = index < 10 ? ` ${index}` : `${index}`;
    console.log(`[ ${indexString} ]: ${roleName} (${accountNumber})${accountName}`);
  };

  // List roles
  selectRole = async (roles: string[], accountNames: boolean, assertion: string) => {
    if (roles.length === 0) {
      throw new Error("No valid roles found! Check your credentials and filters and try again.");
    }

    if (roles.length > 1) {
      let accounts: { [key: string]: string };
      if (accountNames) {
        accounts = await this.getAccountList(assertion);
      }
      roles.forEach((role, index) => this.printRole(role, index, accounts));
    }

    let roleIndexString = "0";
    if (roles.length > 1) {
      roleIndexString = await this.getInput("Selection: ");
    }
    const roleIndex = Number(roleIndexString);
    return roles[roleIndex];
  };

  // Assume role
  assumeRole = async (
    assertion: string,
    region: string,
    role: string
  ): Promise<AssumeRoleWithSAMLCommandOutput["Credentials"]> => {
    const accountNumber = role.substring(13, 25);
    const principal = `arn:aws:iam::${accountNumber}:saml-provider/ADFS`;

    let client: STSClient;

    if (process.env.HTTPS_PROXY) {
      const agent = new HttpsProxyAgent({ proxy: process.env.HTTPS_PROXY });
      client = new STSClient({
        region: region,
        requestHandler: new NodeHttpHandler({
          httpAgent: agent,
          httpsAgent: agent,
        }) as any,
      });
    } else {
      client = new STSClient({ region: region });
    }

    let durationSeconds: number = 8 * 60 * 60;
    while (durationSeconds > 900) {
      try {
        const command = new AssumeRoleWithSAMLCommand({
          RoleArn: role,
          PrincipalArn: principal,
          SAMLAssertion: assertion,
          DurationSeconds: durationSeconds,
        });

        const credentials = await client.send(command);
        return credentials.Credentials;
      } catch (err: unknown) {
        if (err instanceof STSServiceException) {
          if (err.name === "ValidationError") {
            durationSeconds -= 1440;
          } else {
            throw err;
          }
        } else {
          throw err;
        }
      }
    }
  };

  // writes credentials to .aws/credentials unless the process
  // is running as an aws credential source via --cred-source
  writeCredentials = (
    credSource: boolean,
    profile: string,
    output: OutputType,
    credentials: Credentials,
    roles: string[],
    role: string
  ) => {
    let credentialsFileContent = "";

    if (credSource) {
      console.log(`{
          "Version": 1,
          "AccessKeyId": "${credentials.AccessKeyId as string}",
          "SecretAccessKey": "${credentials.SecretAccessKey as string}",
          "SessionToken": "${credentials.SessionToken as string}",
          "Expiration": "${credentials.Expiration?.toISOString() as string}"
      }`);
      return;
    }

    // Build file path
    const awsFolderPath = path.join(os.homedir(), ".aws");
    const credentialsPath = path.join(awsFolderPath, "credentials");

    try {
      if (fs.existsSync(credentialsPath)) {
        credentialsFileContent = String(fs.readFileSync(credentialsPath));
      } else {
        if (!fs.existsSync(awsFolderPath)) {
          fs.mkdirSync(awsFolderPath);
        }
        console.debug(`${credentialsPath} not found. Creating new file.`);
      }
    } catch (err) {
      console.debug(err);
    }

    const profileCredentials = {
      output: output,
      // eslint-disable-next-line @typescript-eslint/naming-convention
      aws_access_key_id: credentials.AccessKeyId,
      // eslint-disable-next-line @typescript-eslint/naming-convention
      aws_secret_access_key: credentials.SecretAccessKey,
      // eslint-disable-next-line @typescript-eslint/naming-convention
      aws_session_token: credentials.SessionToken,
    };

    const credentialsFileData = ini.parse(credentialsFileContent);

    if (!credentialsFileData[profile]) {
      credentialsFileData[profile] = {};
    }
    credentialsFileData[profile] = profileCredentials;

    fs.writeFileSync(credentialsPath, ini.stringify(credentialsFileData));
    if (roles.length === 1) {
      const roleName = role.split("/").pop() as string;
      const accountNumber = role.substring(13, 25);
      console.log(`Using ${roleName} (${accountNumber})`);
    }

    console.log(`Role assumed until: ${credentials.Expiration?.toTimeString() as string}`);
  };
}
