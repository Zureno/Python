import { Command, CommandOptions } from "../command-api.js";
import type { Argv } from "yargs";
import { AwsAuth } from "./aws-auth.js";
import { AwsOpenConsole } from "./aws-open-console.js";
import { AwsListAccounts } from "./aws-list-accounts.js";

/**
 * Command to handle AWS functions for United users
 */
export class Aws implements Command {
  auth = new AwsAuth();
  openConsole = new AwsOpenConsole();
  listAccounts = new AwsListAccounts();

  command = ["aws"];

  description = "Handles AWS functions for United users";
  builder = (yargs: Argv) =>
    yargs
      .command(this.auth.command, this.auth.description, this.auth.builder)
      .command(this.openConsole.command, this.openConsole.description, this.openConsole.builder)
      .command(this.listAccounts.command, this.listAccounts.description, this.listAccounts.builder)
      .demandCommand(1, "") // just print help
      .recommendCommands()
      .help()
      .alias("h", "help");

  handler = (options: CommandOptions) => {
    const { args } = options;
    if (args._.includes("auth")) {
      return this.auth.handler(options);
    } else if (args._.includes("open-console")) {
      return this.openConsole.handler(options);
    } else if (args._.includes("list-accounts")) {
      return this.listAccounts.handler(options);
    } else {
      console.log("Unrecognized command. Add -h to see available commands.");
      return 1;
    }
  };
}
