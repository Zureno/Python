import type { Argv, Arguments } from "yargs";

export interface CommandOptions {
  args: Arguments;
}

export interface Command {
  /**
   * The command line commands used to invoke this Command
   */
  command: string[];

  /**
   * A description of this Command
   */
  description: string;

  /**
   * A function to generate the options for this command
   */
  builder(yargs: Argv): Argv;

  /**
   * The function that handles this command
   */
  handler(options: CommandOptions): Promise<number> | number;
}
