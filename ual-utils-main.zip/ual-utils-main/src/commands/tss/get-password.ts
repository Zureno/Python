import { Command, CommandOptions } from "../command-api.js";
import { Arguments, Argv } from "yargs";
import * as ncp from "copy-paste";
import * as utils from "../../utilities.js";

import { ProvidedId } from "../../constants.js";

interface Opts {
  id: ProvidedId;
  print: boolean;
}

export class GetPassword implements Command {
  command = ["get-password"];

  description = "Retrieve and copy nppid or ppid password to the clipboard";
  builder = (args: Argv) =>
    args
      .option("id", {
        type: "string",
        default: "none",
        alias: "i",
        requiresArg: false,
        description: 'use "ppid", "nppid" or "none"',
      })
      .option("print", {
        requiresArg: false,
        description: "print password to stdout",
      });

  handler = async (options: CommandOptions) => {
    const args = options.args as Arguments<Opts>;

    // Get password from keystore
    await this.retrieveCredentials(args.id, args.print);
    return 0;
  };

  retrieveCredentials = async (id: ProvidedId, print: boolean) => {
    if (id === "none") {
      throw new Error("--id must be set to either nppid or ppid. Add -h to show help.");
    }

    await utils.checkReload();

    const creds = await utils.retrieveCredentials(utils.credentialName(id));
    if (!creds) {
      throw new Error("Could not find password in keystore");
    }

    ncp.copy(creds.password);
    console.log(print ? creds.password : "Copied password to clipboard.");
  };
}
