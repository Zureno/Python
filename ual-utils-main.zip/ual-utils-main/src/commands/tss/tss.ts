import { Command, CommandOptions } from "../command-api.js";
import type { Argv } from "yargs";
import { LoadCredentials } from "./load-credentials.js";
import { GetPassword } from "./get-password.js";

/**
 * Command to handle Tss functions for United users
 */
export class Tss implements Command {
  loadCredentials = new LoadCredentials();
  getPassword = new GetPassword();

  command = ["tss"];

  description = "Handles TSS functions for United users";
  builder = (yargs: Argv) =>
    yargs
      .command(this.loadCredentials.command, this.loadCredentials.description, this.loadCredentials.builder)
      .command(this.getPassword.command, this.getPassword.description, this.getPassword.builder)
      .demandCommand(1, "") // just print help
      .recommendCommands()
      .help()
      .alias("h", "help");

  handler = (options: CommandOptions) => {
    const { args } = options;
    if (args._.includes("load-credentials")) {
      return this.loadCredentials.handler(options);
    } else if (args._.includes("get-password")) {
      return this.getPassword.handler(options);
    } else {
      console.log("Unrecognized command. Add -h to see available commands.");
      return 1;
    }
  };
}
