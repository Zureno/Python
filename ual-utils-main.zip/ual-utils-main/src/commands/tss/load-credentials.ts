import { Command, CommandOptions } from "../command-api.js";
import { Argv } from "yargs";
import keytar from "keytar";

import { GLOBAL_CREDENTIAL_NAME, NPPID_CREDENTIAL_NAME, PPID_CREDENTIAL_NAME } from "../../constants.js";
import * as utils from "../../utilities.js";

import { retrieveCredentials } from "../../utilities.js";
import { writeFileSync } from "fs";
import { homedir } from "os";
import { sep } from "path";
import { createConnection } from "net";
import { ProxyAgent } from "undici";

interface Id {
  username: string;
  password: string;
}
/**
 * Command to handle AWS functions for United users
 */
export class LoadCredentials implements Command {
  tssUrl = "https://ual.secretservercloud.com";

  command = ["load-credentials"];

  description = "Loads credentials from TSS into credential store";
  builder = (yargs: Argv) =>
    yargs
      .option("user", {
        type: "string",
        alias: "u",
        requiresArg: false,
        desc: "user id for authentication (i.e. u123456)",
      })
      .option("password", {
        type: "string",
        alias: "p",
        requiresArg: false,
        desc: "user password for authentication",
      })
      .option("otp", {
        type: "string",
        alias: "o",
        requiresArg: false,
        desc: "duo one time password to use for authentication, or push to send a push request",
      })
      .option("prompt", {
        type: "boolean",
        requiresArg: false,
        default: false,
        desc: "prompt for username and password even if saved",
      })
      .option("no-save", {
        requiresArg: false,
        description: "prevents saving these credentials in the keystore",
      })
      .option("reset", {
        requiresArg: false,
        description: "reset saved username and password",
      });

  // Validate that the OTP is exactly 6 digits
  validateOtp = (otp: string) => {
    if (!/^[0-9]{6}$/.test(otp)) {
      throw new Error("Duo one-time passcode must be exactly 6 numeric digits.");
    }
  };

  // Check if proxy is available on specified host and port
  checkProxyAvailable = async (host: string, port: number): Promise<boolean> => {
    return new Promise((resolve) => {
      const socket = createConnection({ host, port, timeout: 1000 }, () => {
        socket.destroy();
        resolve(true);
      });

      socket.on("error", () => resolve(false));
      socket.on("timeout", () => {
        socket.destroy();
        resolve(false);
      });
    });
  };

  handler = async (options: CommandOptions) => {
    const { args } = options;

    // Check for proxy availability
    let proxyUrl: string | undefined;
    if (process.env.HTTPS_PROXY) {
      proxyUrl = process.env.HTTPS_PROXY;
      console.log(`→ Using proxy from environment: ${proxyUrl}`);
    } else if (await this.checkProxyAvailable("127.0.0.1", 9000)) {
      proxyUrl = "http://127.0.0.1:9000";
      console.log("→ Proxy detected on 127.0.0.1:9000 — routing traffic through proxy");
    } else {
      console.log("→ No proxy detected on port 9000 — connecting directly");
    }

    // Reset and exit if requested
    if (args.reset) {
      console.log("Clearing saved credentials...");
      await this.resetUsernameAndPassword();
      console.log("Cleared saved credentials.");
    } else {
      // Get username and password from CLI or keystore
      const credentials = await this.getUsernameAndPassword(
        args.prompt as boolean,
        args.username as string | undefined,
        args.password as string | undefined
      );

      // Save username and password
      if (args.save !== false) {
        await this.saveUsernameAndPassword(credentials.username, credentials.password);
      }

      let otp = args.otp as string;
      if (!args.otp) {
        // Prompt for OTP if not provided
        otp = await this.getDuoOneTimePasscode();
      }
      this.validateOtp(otp);

      // Get TSS token
      const tssToken = await this.getTssToken(credentials.username, credentials.password, otp, proxyUrl);

      // Look up secret ids
      const secrets = await this.searchSecrets(tssToken, proxyUrl);

      // Get nppid and ppid
      if (secrets.nppidSecretId) {
        const nppid = await this.getSecret(tssToken, secrets.nppidSecretId, proxyUrl);
        await this.resetUsernameAndPassword(NPPID_CREDENTIAL_NAME);
        await this.saveId(NPPID_CREDENTIAL_NAME, nppid);
      }
      if (secrets.ppidSecretId) {
        const ppid = await this.getSecret(tssToken, secrets.ppidSecretId, proxyUrl);
        await this.resetUsernameAndPassword(PPID_CREDENTIAL_NAME);
        await this.saveId(PPID_CREDENTIAL_NAME, ppid);
      }

      console.log("TSS credentials saved!");

      const timestampFile = `${homedir()}${sep}.ual-utils-timestamp`;
      const data = `loaded: ${new Date().toLocaleString()}\n`;
      writeFileSync(timestampFile, data);
    }
    return 0;
  };

  // Get Duo one-time passcode from input
  getDuoOneTimePasscode = async (): Promise<string> => {
    const otpResult = await utils.getInput("Enter Duo one-time passcode: ");
    if (otpResult === "") {
      throw new Error("Duo one-time passcode cannot be empty.");
    }
    return otpResult;
  };

  // Get username and password from options, key chain, or input
  getUsernameAndPassword = async (
    prompt: boolean,
    inputUsername?: string,
    inputPassword?: string
  ): Promise<{ username: string; password: string }> => {
    const retrievedCredentials = await retrieveCredentials(GLOBAL_CREDENTIAL_NAME);

    const usernameHint = retrievedCredentials?.username
      ? `[default: ${retrievedCredentials.username}]`
      : "(like u123456)";
    const passwordHint = retrievedCredentials?.password ? " [default: saved password]" : "";

    let username = inputUsername || retrievedCredentials?.username;
    let password = inputPassword || retrievedCredentials?.password;

    if (prompt || !username) {
      const usernameResult = await utils.getInput(`Enter global username ${usernameHint}: `);
      if (usernameResult !== "") {
        username = usernameResult;
      } else if (!username) {
        throw new Error("Username cannot be empty.");
      }
    }

    if (prompt || !password) {
      const passResult = await utils.getInput(`Enter password${passwordHint}: `, true);
      if (passResult !== "") {
        password = passResult;
      } else if (!password) {
        throw new Error("Password cannot be empty.");
      }
    }

    return { username, password };
  };

  // Save username and password
  saveUsernameAndPassword = async (username: string, password: string) => {
    // Check if credentials already exist
    await this.resetUsernameAndPassword();
    await keytar.setPassword(GLOBAL_CREDENTIAL_NAME, username, password);
  };

  // Reset username and password
  resetUsernameAndPassword = (credentialName?: string): Promise<void> => {
    // Check if credentials already exist
    return new Promise((resolve) => {
      keytar
        .findCredentials(credentialName || GLOBAL_CREDENTIAL_NAME)
        .then(async (credentials) => {
          await Promise.all(
            credentials.map((cred) => keytar.deletePassword(credentialName || GLOBAL_CREDENTIAL_NAME, cred.account))
          );
          resolve();
        })
        .catch(() => {
          resolve();
        });
    });
  };

  // Get tss token
  getTssToken = async (username: string, password: string, otp: string, proxyUrl?: string): Promise<string> => {
    const formData = new URLSearchParams({
      grant_type: "password",
      username: `global\\${username}`,
      password: password,
    });

    const response = await fetch(`${this.tssUrl}/oauth2/token`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        OTP: otp,
      },
      body: formData,
      ...(proxyUrl && { dispatcher: new ProxyAgent(proxyUrl) }),
    });

    if (!response.ok) {
      throw new Error(`Failed to authenticate with TSS: HTTP ${response.status}`);
    }

    const jsonData = await response.json() as {
      error?: string;
      access_token?: string;
    };

    if (jsonData.error) {
      throw new Error(`${jsonData.error} [try "ual tss load-credentials --reset"]`);
    } else if (jsonData.access_token) {
      console.log("TSS login succeeded.");
      return jsonData.access_token;
    } else {
      throw new Error("Unrecognized payload from TSS");
    }
  };

  // Search secrets
  searchSecrets = async (tssToken: string, proxyUrl?: string): Promise<{ nppidSecretId: number; ppidSecretId: number }> => {
    const nppidTemplateId = 6080;
    const ppidTemplateId = 6077;

    const url = `${this.tssUrl}/api/v2/secrets?filter.includeRestricted=true&filter.secretTemplateIds=${nppidTemplateId}&filter.secretTemplateIds=${ppidTemplateId}`;
    
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${tssToken}`,
      },
      ...(proxyUrl && { dispatcher: new ProxyAgent(proxyUrl) }),
    });

    if (!response.ok) {
      throw new Error(`Failed to find credentials in TSS: HTTP ${response.status}`);
    }

    const jsonData = await response.json() as { records: Array<{ id: number; secretTemplateId: number; lastHeartBeatStatus: string }> };
    const result = {
      nppidSecretId: 0,
      ppidSecretId: 0,
    };
    
    jsonData.records.forEach((secret) => {
      if (secret.secretTemplateId === nppidTemplateId && secret.lastHeartBeatStatus === "Success") {
        result.nppidSecretId = secret.id;
      } else if (secret.secretTemplateId === ppidTemplateId && secret.lastHeartBeatStatus === "Success") {
        result.ppidSecretId = secret.id;
      }
    });
    
    console.log("Retrieved credentials from TSS.");
    return result;
  };

  // Get secret value
  getSecret = async (tssToken: string, secretId: number, proxyUrl?: string): Promise<Id> => {
    const url = `${this.tssUrl}/api/v2/secrets/${secretId}?autoCheckout=true&autoCheckin=false&autoComment=ual-utils`;
    
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${tssToken}`,
        "Content-Type": "application/json",
      },
      ...(proxyUrl && { dispatcher: new ProxyAgent(proxyUrl) }),
    });

    if (!response.ok) {
      throw new Error(`Failed to retrieve credential password: HTTP ${response.status}`);
    }

    const jsonData = await response.json() as {
      items: Array<{ fieldName: string; itemValue: string }>;
    };
    
    const result = {
      username: "",
      password: "",
    };
    
    jsonData.items.forEach((item) => {
      if (item.fieldName === "Username") {
        result.username = item.itemValue;
      }
      if (item.fieldName === "Password") {
        result.password = item.itemValue;
      }
    });
    
    return result;
  };

  // Save username and password
  saveId = (credentialName: string, id: Id) => {
    return keytar.setPassword(credentialName, id.username, id.password);
  };
}
