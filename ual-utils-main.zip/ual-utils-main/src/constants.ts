/* eslint-disable @typescript-eslint/naming-convention */
// NPPID Credential name
export const NPPID_CREDENTIAL_NAME = "ual-utils-nppid";

// PPID Credential name
export const PPID_CREDENTIAL_NAME = "ual-utils-ppid";

// Global credential name
export const GLOBAL_CREDENTIAL_NAME = "ual-utils-global";

export type ProvidedId = "ppid" | "nppid" | "none";
