import chalk from "chalk";
import semver from "semver";
import { exec as _exec } from "child_process";
import { promisify } from "util";
import { formatAsBanner } from "./console-formatters.js";
import { VERSION } from "../version.js";

const exec = promisify(_exec);

export const checkRegistry = async (): Promise<string> => {
  const { stdout, stderr } = await exec("npm config get registry");
  if (stderr && stderr.trim().length > 0) {
    throw new Error(`The 'npm config' command generated an error stream with content [${stderr.trim()}]`);
  }

  const registry = stdout.trim();
  if (registry.includes("artifactoryunited") || registry.includes("artifactorycloud")) {
    return registry;
  } else {
    throw new Error(`Could not check ual-utils versions as registry ${registry} is not supported`);
  }
};

export const getLatestVersionFromNpm = async (): Promise<string> => {
  const registry = await checkRegistry();

  const { stdout, stderr } = await exec(`npm view ual-utils version --registry ${registry}`);
  if (stderr && stderr.trim().length > 0) {
    throw new Error(`The 'npm view' command generated an error stream with content [${stderr.trim()}]`);
  }
  const latestVersion = stdout.trim();

  return latestVersion;
};

const getVersionMessage = (laterVersion: string): string[] => {
  return [
    `Newer version of ual-utils is available [${chalk.green(laterVersion)}]`,
    "Upgrade recommended (npm install -g ual-utils)",
  ].filter(Boolean);
};

export const displayVersionMessage = async (currentVersion = VERSION): Promise<void> => {
  if (!process.stdout.isTTY) {
    return;
  }

  try {
    const laterVersion = await getLatestVersionFromNpm();
    if (semver.gt(laterVersion, currentVersion)) {
      const bannerMsg = formatAsBanner(getVersionMessage(laterVersion));
      bannerMsg.forEach((e) => console.error(e));
    }
  } catch (err) {
    console.error(`Could not run version check - ${String(err)}`);
  }
};
