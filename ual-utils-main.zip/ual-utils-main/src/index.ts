#!/usr/bin/env node

import yargs from "yargs";
import { hideBin } from "yargs/helpers";
import { Command } from "./commands/command-api.js";
import { VERSION } from "./version.js";

/**
 * !!! Import commands here
 */
import { Aws } from "./commands/aws/aws.js";
import { Tss } from "./commands/tss/tss.js";
import { displayVersionMessage } from "./util/npm.js";

/**
 * Global map of initialized commands served by this utility
 */
const commandsMap: Map<string, Command> = new Map<string, Command>();

/**
 * Location where command line options are defined and can be parsed
 */
const parseCommandLineArguments = (commands: Command[]): any => {
  // Build initial yargs instance
  const y = yargs(hideBin(process.argv));
  let cli = y.scriptName("ual").env("UAL").usage("Usage: ual COMMAND [options]");

  // Add each command to yargs and the commandsMap
  commands.forEach((command) => {
    cli = cli.command(command.command, command.description, (args) => command.builder(args));
    command.command.forEach((commandName) => commandsMap.set(commandName, command));
  });

  // Clean up and return final yargs
  return cli
    .version(VERSION)
    .demandCommand(1, "") // just print help
    .recommendCommands()
    .help()
    .alias("h", "help")
    .option("skip-version-check", {
      type: "boolean",
      default: false,
      requiresArg: false,
      desc: "skips the app version check",
    })
    .epilogue(["United Command Line Utility"].join("\n\n")).argv;
};

/**
 * Entrypoint for this command line utility
 */
const runRequestedCommand = async (argv: yargs.Arguments): Promise<number> => {
  // Basic error checking
  const cmd = argv._[0];
  if (typeof cmd !== "string") {
    throw new Error(`First argument should be a string. Got: ${cmd} (${typeof cmd})`);
  }

  const requestedCommand = commandsMap.get(cmd);
  if (!requestedCommand) {
    console.error("Unknown command:", cmd);
    return 1;
  } else {
    return requestedCommand.handler({ args: argv });
  }
};

/**
 * Initializes the command line tool
 */
// function main(): void {
const main = () => {
  /**
   * !!! Initialize commands here
   */
  const commands = [new Aws(), new Tss()];
  const argv = parseCommandLineArguments(commands);

  runRequestedCommand(argv)
    .then(async (value) => {
      if (!argv.skipVersionCheck) {
        await displayVersionMessage();
      }
      process.exit(value);
    })
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
};

main();
