import { coverageConfigDefaults, defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    pool: "threads",
    exclude: ["node_modules", "coverage", "dist", "public"],
    setupFiles: "./vitest.setup.ts",
    environment: "node",
    reporters: process.env.GITHUB_ACTIONS
      ? [["github-actions"], ["vitest-sonar-reporter", { output: "coverage/test-reporter.xml" }]]
      : [["default"], ["vitest-sonar-reporter", { output: "coverage/test-reporter.xml" }]],
    coverage: {
      enabled: true,
      include: ["src/**"],
      reporter: ["json", "json-summary", "lcov", "text-summary", "html"],
      reportOnFailure: true,
    },
    outputFile: "coverage/test-reporter.xml",
  },
});
