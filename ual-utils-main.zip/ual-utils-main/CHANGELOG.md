# Changelog

## [2.8.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.7.1...v2.8.0) (2026-03-13)


### Features

* tss proxy setup ([#174](https://github.com/United-Airlines-Org/ual-utils/issues/174)) ([cc3d3f5](https://github.com/United-Airlines-Org/ual-utils/commit/cc3d3f5035a8606e317774a75a5fd14f8f35a6fd))

## [2.7.1](https://github.com/United-Airlines-Org/ual-utils/compare/v2.7.0...v2.7.1) (2026-03-07)


### Bug Fixes

* Corrected template Id for NppID & PPID ([#171](https://github.com/United-Airlines-Org/ual-utils/issues/171)) ([a48dac2](https://github.com/United-Airlines-Org/ual-utils/commit/a48dac28bd6bf7045d3de363b240a829cb0b41d7))

## [2.7.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.6.0...v2.7.0) (2026-02-18)


### Features

* url change for tss changeover ([#166](https://github.com/United-Airlines-Org/ual-utils/issues/166)) ([04a1dea](https://github.com/United-Airlines-Org/ual-utils/commit/04a1deab7123fa4c5b4fe0dd547e2d6725730550))

## [2.6.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.5.1...v2.6.0) (2025-09-02)


### Features

* Add show names and PCR capability to list-accounts ([#158](https://github.com/United-Airlines-Org/ual-utils/issues/158)) ([2d796f2](https://github.com/United-Airlines-Org/ual-utils/commit/2d796f2219198783b3680410d3858d21ac354561))

## [2.5.1](https://github.com/United-Airlines-Org/ual-utils/compare/v2.5.0...v2.5.1) (2025-08-29)


### Bug Fixes

* Await unbind ([9846bf8](https://github.com/United-Airlines-Org/ual-utils/commit/9846bf86c81f0407978cc96a4f23960b9c7bec6b))

## [2.5.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.4.1...v2.5.0) (2025-08-29)


### Features

* aws list-accounts ([#155](https://github.com/United-Airlines-Org/ual-utils/issues/155)) ([9e0c4df](https://github.com/United-Airlines-Org/ual-utils/commit/9e0c4df46a8db8a3d6c512cbbd69848d40573c07))


### Bug Fixes

* bump the npm-dependencies group across 1 directory with 7 updates ([#154](https://github.com/United-Airlines-Org/ual-utils/issues/154)) ([5423ca5](https://github.com/United-Airlines-Org/ual-utils/commit/5423ca54a4e544661a2f294848d43bf08554f72b))
* Replace deprecated axios and request libraries with built-in fetch API ([#147](https://github.com/United-Airlines-Org/ual-utils/issues/147)) ([59b4405](https://github.com/United-Airlines-Org/ual-utils/commit/59b4405b8db882bbe8b34e18dcc4b17b50573d8f))

## [2.4.1](https://github.com/United-Airlines-Org/ual-utils/compare/v2.4.0...v2.4.1) (2025-08-28)


### Bug Fixes

* Correct artifactory registry ([#151](https://github.com/United-Airlines-Org/ual-utils/issues/151)) ([7f30338](https://github.com/United-Airlines-Org/ual-utils/commit/7f30338d317633b2d0d004a924b168b5184fde2d))

## [2.4.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.3.0...v2.4.0) (2025-07-14)


### Features

* Add --otp option to ual aws auth command for TSS authentication ([#137](https://github.com/United-Airlines-Org/ual-utils/issues/137)) ([76eb02a](https://github.com/United-Airlines-Org/ual-utils/commit/76eb02ab81f79cff2a735bc3da3c5300589ddcd5))
* default --id option to 'nppid' in ual aws auth command ([#140](https://github.com/United-Airlines-Org/ual-utils/issues/140)) ([e1d6de5](https://github.com/United-Airlines-Org/ual-utils/commit/e1d6de504cfdc6387078b635b595fd5838b60112))

## [2.3.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.2.0...v2.3.0) (2025-07-02)


### Features

* Deprecate TSS Push and prompt for Duo OTP ([#134](https://github.com/United-Airlines-Org/ual-utils/issues/134)) ([fe6043c](https://github.com/United-Airlines-Org/ual-utils/commit/fe6043c4cc7a9565c303b14f51b7ea1dad8e7ea0))

## [2.2.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.1.1...v2.2.0) (2025-05-06)


### Features

* Enable multi-sesion support ([#132](https://github.com/United-Airlines-Org/ual-utils/issues/132)) ([5363022](https://github.com/United-Airlines-Org/ual-utils/commit/536302223905ff2a8131fb05b552072f6f4ce0bf))
* Migrate Unit Tests to Vitest ([#125](https://github.com/United-Airlines-Org/ual-utils/issues/125)) ([9934459](https://github.com/United-Airlines-Org/ual-utils/commit/99344599708e6379edde66a30bfe3e24575ded03))
* Sonar Cloud Setup ([#130](https://github.com/United-Airlines-Org/ual-utils/issues/130)) ([f65250b](https://github.com/United-Airlines-Org/ual-utils/commit/f65250bbd2b1fa0aa373812a63e3e4842f42e758))
* Steps added for installation in Windows VDI ([#121](https://github.com/United-Airlines-Org/ual-utils/issues/121)) ([39ae0fb](https://github.com/United-Airlines-Org/ual-utils/commit/39ae0fbdb0aa575f85950560d8bc095c86f1aa37))


### Bug Fixes

* Added command required to install ual-utils ([#123](https://github.com/United-Airlines-Org/ual-utils/issues/123)) ([c19e497](https://github.com/United-Airlines-Org/ual-utils/commit/c19e497157ecf1790e69c1887386d501ca133ccd))

## [2.1.1](https://github.com/United-Airlines-Org/ual-utils/compare/v2.1.0...v2.1.1) (2024-02-28)


### Bug Fixes

* auto-reload credentials after 6 hours ([#117](https://github.com/United-Airlines-Org/ual-utils/issues/117)) ([f14e193](https://github.com/United-Airlines-Org/ual-utils/commit/f14e193b0e6f185a4da7bdefddd32439dcbd0442))

## [2.1.0](https://github.com/United-Airlines-Org/ual-utils/compare/v2.0.0...v2.1.0) (2023-12-08)


### Features

* Add copy password to clipboard on load-credentials ([#108](https://github.com/United-Airlines-Org/ual-utils/issues/108)) ([86086bc](https://github.com/United-Airlines-Org/ual-utils/commit/86086bcf728a485d9fe923e75fc515d7b4a71614))


### Bug Fixes

* Publish to Artifactory Cloud ([#110](https://github.com/United-Airlines-Org/ual-utils/issues/110)) ([b118d7a](https://github.com/United-Airlines-Org/ual-utils/commit/b118d7a44949dd5253daec3c3f78cb8c20977105))
* simplify pull-request-validation.yaml ([#106](https://github.com/United-Airlines-Org/ual-utils/issues/106)) ([70bff01](https://github.com/United-Airlines-Org/ual-utils/commit/70bff01985504f42ed2a4b851bb05ef77ed9e2bd))
* update eslint rules to only accept double-quoted strings ([#114](https://github.com/United-Airlines-Org/ual-utils/issues/114)) ([29f5f8f](https://github.com/United-Airlines-Org/ual-utils/commit/29f5f8fbc26905a7669b115260c3df451ba08b41))

## [2.0.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.9.0...v2.0.0) (2023-08-14)


### ⚠ BREAKING CHANGES

* Refactor/reduce complexity ([#96](https://github.com/United-Airlines-Org/ual-utils/issues/96))

### Features

* Refactor/reduce complexity ([#96](https://github.com/United-Airlines-Org/ual-utils/issues/96)) ([a78a23d](https://github.com/United-Airlines-Org/ual-utils/commit/a78a23dafaf029f5bbc7e26cc3f95f15fd31705e))


### Bug Fixes

* add missing alias ([#102](https://github.com/United-Airlines-Org/ual-utils/issues/102)) ([a1b6d4a](https://github.com/United-Airlines-Org/ual-utils/commit/a1b6d4adba593dada53ac9b5aa754988bc7ac3d1))

## [1.9.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.8.0...v1.9.0) (2023-04-14)


### Features

* ual aws auth respect HTTPS_PROXY ([#92](https://github.com/United-Airlines-Org/ual-utils/issues/92)) ([fd4c670](https://github.com/United-Airlines-Org/ual-utils/commit/fd4c67079ef01c907d38846c933ce5cb6d0812f8))


### Bug Fixes

* Remove state behavior in favor of variables ([#91](https://github.com/United-Airlines-Org/ual-utils/issues/91)) ([1f71349](https://github.com/United-Airlines-Org/ual-utils/commit/1f713490810ed387ea9d1b6a50dfdf6a866e58ec))

## [1.8.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.7.0...v1.8.0) (2023-04-12)


### Features

* ual aws auth role name filters ([#87](https://github.com/United-Airlines-Org/ual-utils/issues/87)) ([b25d2aa](https://github.com/United-Airlines-Org/ual-utils/commit/b25d2aaa505986637d77dc31777532fdd95b2f87))

## [1.7.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.6.1...v1.7.0) (2023-04-10)


### Features

* Display AWS account names next to roles ([#84](https://github.com/United-Airlines-Org/ual-utils/issues/84)) ([2854a53](https://github.com/United-Airlines-Org/ual-utils/commit/2854a5342b7a56b7538bbc9fe652728ae8ac01be))

## [1.6.1](https://github.com/United-Airlines-Org/ual-utils/compare/v1.6.0...v1.6.1) (2023-04-06)


### Bug Fixes

* Handle tss auth error on invalid password ([#75](https://github.com/United-Airlines-Org/ual-utils/issues/75)) ([dc3e5dd](https://github.com/United-Airlines-Org/ual-utils/commit/dc3e5dd57f8c938238a43207f49cf85c08e3f3e6))
* missing password argument check ([#76](https://github.com/United-Airlines-Org/ual-utils/issues/76)) ([2bdaabb](https://github.com/United-Airlines-Org/ual-utils/commit/2bdaabb4b3f5146241a30f11253d0285a8d0fbff))

## [1.6.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.5.2...v1.6.0) (2023-04-04)


### Features

* Open console ([#73](https://github.com/United-Airlines-Org/ual-utils/issues/73)) ([acfdf47](https://github.com/United-Airlines-Org/ual-utils/commit/acfdf47714a9ac280c1116593a80d13a925ebee9))

## [1.5.2](https://github.com/United-Airlines-Org/ual-utils/compare/v1.5.1...v1.5.2) (2023-01-03)


### Bug Fixes

* Create .aws folder when not present ([6468960](https://github.com/United-Airlines-Org/ual-utils/commit/6468960bdb607fdc3e57e39cb05e231d1dc66ca9))

## [1.5.1](https://github.com/United-Airlines-Org/ual-utils/compare/v1.5.0...v1.5.1) (2022-10-24)


### Bug Fixes

* add tag_name output to release-please job ([#64](https://github.com/United-Airlines-Org/ual-utils/issues/64)) ([7229f37](https://github.com/United-Airlines-Org/ual-utils/commit/7229f37030030539113c5ce8fb26c9be0c0cc79a))

## [1.5.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.4.0...v1.5.0) (2022-10-24)


### Features

* publish release messages to teams ([#62](https://github.com/United-Airlines-Org/ual-utils/issues/62)) ([31b1021](https://github.com/United-Airlines-Org/ual-utils/commit/31b1021edc47b680cbd89b8fb11879f6dc33b1f4))


### Bug Fixes

* safer types ([#61](https://github.com/United-Airlines-Org/ual-utils/issues/61)) ([403eb33](https://github.com/United-Airlines-Org/ual-utils/commit/403eb33f6689ebc0cdb6647d2842561334be047c))

## [1.4.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.3.2...v1.4.0) (2022-09-16)


### Features

* aws auth credential sourcing ([541b18d](https://github.com/United-Airlines-Org/ual-utils/commit/541b18d5b0342a0c17c031227f6e3a7557a4e05c))
* aws auth credential sourcing ([89daf9c](https://github.com/United-Airlines-Org/ual-utils/commit/89daf9cc050f199dd54195fb1744bb2c478bb575))

## [1.3.2](https://github.com/United-Airlines-Org/ual-utils/compare/v1.3.1...v1.3.2) (2022-09-15)


### Bug Fixes

* Update to only use passwords with a valid heartbeat ([#57](https://github.com/United-Airlines-Org/ual-utils/issues/57)) ([43ca649](https://github.com/United-Airlines-Org/ual-utils/commit/43ca6490b1ba75f878886301d534bb102cd0d03b))

## [1.3.1](https://github.com/United-Airlines-Org/ual-utils/compare/v1.3.0...v1.3.1) (2022-09-15)


### Bug Fixes

* Decrement DurationSeconds when assuming role ([#55](https://github.com/United-Airlines-Org/ual-utils/issues/55)) ([53921ae](https://github.com/United-Airlines-Org/ual-utils/commit/53921aed527a36f39b5e33d574df096ad5691df2))

## [1.3.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.2.0...v1.3.0) (2022-08-26)


### Features

* add flag to skip version check ([#53](https://github.com/United-Airlines-Org/ual-utils/issues/53)) ([4f606a2](https://github.com/United-Airlines-Org/ual-utils/commit/4f606a2cb4ac8c54e01ef401d1cdf862b81be3d4))

## [1.2.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.1.1...v1.2.0) (2022-08-22)


### Features

* print password to stdout ([8d63adf](https://github.com/United-Airlines-Org/ual-utils/commit/8d63adfda56e288ed88c7cb0d41614b6261ae0e1))

## [1.1.1](https://github.com/United-Airlines-Org/ual-utils/compare/v1.1.0...v1.1.1) (2022-08-15)


### Bug Fixes

* command name in help guide ([60331a3](https://github.com/United-Airlines-Org/ual-utils/commit/60331a34ae06c18a2d35d06b97e733559724e807))

## [1.1.0](https://github.com/United-Airlines-Org/ual-utils/compare/v1.0.4...v1.1.0) (2022-08-15)


### Features

* check package version ([933297f](https://github.com/United-Airlines-Org/ual-utils/commit/933297fb821303442caf88c5b6287a3efdaf987d))


### Bug Fixes

* AWS Credential file system management ([#44](https://github.com/United-Airlines-Org/ual-utils/issues/44)) ([5defcbd](https://github.com/United-Airlines-Org/ual-utils/commit/5defcbdb9e2d3b178fc6c036ee958f42376362fb))
* new profiles in AWS credentials file ([5defcbd](https://github.com/United-Airlines-Org/ual-utils/commit/5defcbdb9e2d3b178fc6c036ee958f42376362fb))
* windows credential file path ([5defcbd](https://github.com/United-Airlines-Org/ual-utils/commit/5defcbdb9e2d3b178fc6c036ee958f42376362fb))
* windows file system and new profiles ([74fcb4e](https://github.com/United-Airlines-Org/ual-utils/commit/74fcb4ed248da831018fa780bf0b60e6cb794973))

## [1.0.4](https://github.com/United-Airlines-Org/ual-utils/compare/v1.0.3...v1.0.4) (2022-08-04)


### Bug Fixes

* artifactory publish after release ([da6a9a6](https://github.com/United-Airlines-Org/ual-utils/commit/da6a9a668bfa2738cab04d89ee9d1b5eb61a1dc0))
* artifactory publish after release ([ded3387](https://github.com/United-Airlines-Org/ual-utils/commit/ded33874e08269598f8f19075b299228d79abff4))

## [1.0.3](https://github.com/United-Airlines-Org/ual-utils/compare/v1.0.2...v1.0.3) (2022-08-04)


### Bug Fixes

* publish workflow ([#34](https://github.com/United-Airlines-Org/ual-utils/issues/34)) ([29eab3c](https://github.com/United-Airlines-Org/ual-utils/commit/29eab3cd2631df4fb470632403b91180c9115437))

## [1.0.2](https://github.com/United-Airlines-Org/ual-utils/compare/v1.0.1...v1.0.2) (2022-08-04)


### Bug Fixes

* bootstrap ([#27](https://github.com/United-Airlines-Org/ual-utils/issues/27)) ([29f81e4](https://github.com/United-Airlines-Org/ual-utils/commit/29f81e4e5a9157269dfd3b074f876d93c522f686))
* cleanup bootstrap ([9c2c3d3](https://github.com/United-Airlines-Org/ual-utils/commit/9c2c3d3aad5225dc1ec9f8cea21331a098393ea2))
* cleanup manifest ([#30](https://github.com/United-Airlines-Org/ual-utils/issues/30)) ([47036ff](https://github.com/United-Airlines-Org/ual-utils/commit/47036fff7ea673fd32def917edc43ed4950048b8))
* package name ([#32](https://github.com/United-Airlines-Org/ual-utils/issues/32)) ([a7319e3](https://github.com/United-Airlines-Org/ual-utils/commit/a7319e360e5bf9d235fd878e127116671291f1ec))

## [1.0.1](https://github.com/United-Airlines-Org/ual-utils/compare/ual-utils-v1.0.0...ual-utils-v1.0.1) (2022-08-04)


### Bug Fixes

* cleanup manifest ([#30](https://github.com/United-Airlines-Org/ual-utils/issues/30)) ([47036ff](https://github.com/United-Airlines-Org/ual-utils/commit/47036fff7ea673fd32def917edc43ed4950048b8))

## 1.0.0 (2022-08-04)


### Bug Fixes

* bootstrap ([#27](https://github.com/United-Airlines-Org/ual-utils/issues/27)) ([29f81e4](https://github.com/United-Airlines-Org/ual-utils/commit/29f81e4e5a9157269dfd3b074f876d93c522f686))
* cleanup bootstrap ([9c2c3d3](https://github.com/United-Airlines-Org/ual-utils/commit/9c2c3d3aad5225dc1ec9f8cea21331a098393ea2))
