import { formatAsBanner } from '../../src/util/console-formatters';
import { describe, it, expect } from 'vitest';

describe('Test banner format', () => {
  it('creates evenly sized lines', () => {
    type Pair<T> = [T[], T[]];

    function cmp<T>(pair: Pair<T>): Boolean {
      return (
        pair[0].length === pair[1].length &&
        pair[0].every((value, index) => value === pair[1][index])
      );
    }

    const ps: Pair<string>[] = [
      [
        ['a', 'b', 'c'],
        ['*********', '*** a ***', '*** b ***', '*** c ***', '*********'],
      ],
      [[], []],
      [
        ['a', 'bbb', 'c'],
        [
          '***********',
          '*** a   ***',
          '*** bbb ***',
          '*** c   ***',
          '***********',
        ],
      ],
    ];

    expect(ps.every((p) => cmp([formatAsBanner(p[0]), p[1]])));
  });
});
