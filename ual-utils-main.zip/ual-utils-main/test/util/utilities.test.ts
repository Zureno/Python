import { describe, it, expect, vi } from 'vitest';
import { credentialName, retrieveCredentials, getInput } from '../../src/utilities.js';
import { NPPID_CREDENTIAL_NAME, PPID_CREDENTIAL_NAME } from "../../src/constants.js";

const bufferToText = (buffer: Buffer) => {
  return Buffer.from(buffer).toString('utf-8');
}

describe('Utilities', () => {
  const outputSpy = vi.spyOn(process.stdout, 'write');

  it('returns the correct credential name', () => {
    expect(credentialName('none')).toBe('');
    expect(credentialName('ppid')).toBe(PPID_CREDENTIAL_NAME);
    expect(credentialName('nppid')).toBe(NPPID_CREDENTIAL_NAME);
  })

  it('handles retrieving credentials from keytar', async () => {
    const credentials = await retrieveCredentials('test');
    expect(credentials).toEqual({ username: 'u123456.smith', password: 'fakepassword' });
  });

  it('gets input from the command line', () => {
    vi.resetAllMocks();
    const message = 'Enter your password: ';
    const input = 'fakepassword';
    getInput(message).then((result) => {
      expect(result).toBe(input);
    });
    process.stdin.emit('data', input);
    process.stdin.emit('end');

    // 4 calls initially - 2 newlines, the prompt, and one more newline - then 12 more for each character in the input
    expect(outputSpy).toHaveBeenCalledTimes(16);
  });

  it('hides the output when muted', () => {
    vi.resetAllMocks();
    const message = 'Enter your password: ';
    const input = 'fakepassword';
    getInput(message, true).then((result) => {
      expect(result).toBe(input);
    });
    process.stdin.emit('data', input);
    process.stdin.emit('end');

    // Initial 4 above, and 0 additional since password is hidden
    expect(outputSpy).toHaveBeenCalledTimes(4);
  })
});
