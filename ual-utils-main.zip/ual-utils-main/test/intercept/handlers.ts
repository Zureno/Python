import { http, HttpResponse } from 'msw';

export const handlers = [
  http.post('https://ual.secretservercloud.com/oauth2/token', () => {
    return HttpResponse.json({
      access_token: 'c0e01c65-dc6d-44e4-8bd5-735d382d32fc'
    }, { status: 200 })
  }),
  http.get('https://ual.secretservercloud.com/api/v2/secrets', () => {
    return HttpResponse.json({
      records: [
        { id: 0, secretTemplateId: 0, lastHeartBeatStatus: 'Success' },
        { id: 1, secretTemplateId: 1, lastHeartBeatStatus: 'Success' },
        { id: 2, secretTemplateId: 2, lastHeartBeatStatus: 'Success' },
      ]
    }, { status: 200 })
  })
];
