import { AwsAuth } from '../../src/commands/aws/aws-auth';
import * as fs from 'fs';
import { afterEach, describe, expect, it, vi } from 'vitest';

describe('AWS Authentication', () => {

  afterEach(() => {
    vi.resetAllMocks();
  });

  it('defaults id option to nppid', () => {
    const auth = new AwsAuth();
    
    // Create a mock yargs object to test the builder
    const mockYargs = {
      option: vi.fn().mockReturnThis(),
    };
    
    // Call the builder method
    auth.builder(mockYargs as any);
    
    // Check that the 'id' option was configured with default 'nppid'
    const idOptionCall = mockYargs.option.mock.calls.find(call => call[0] === 'id');
    expect(idOptionCall).toBeDefined();
    expect(idOptionCall[1].default).toBe('nppid');
  });

  it('runs through static authentication', async () => {
    const auth = new AwsAuth();

    vi.spyOn(auth, 'getAuthToken').mockImplementation(async () => {
      return String(fs.readFileSync('test/aws/resources/token.txt'));
    });
    vi
      .spyOn(auth, 'assumeRole')
      .mockImplementation(async () => {
        return {
          AccessKeyId: '123',
          SecretAccessKey: '123',
          SessionToken: '123',
          Expiration: new Date(),
        };
      });

    const result = await auth.handler({
      args: {
        user: 'u123456.smith',
        password: 'fakepassword',
        save: false,
        output: 'json',
        profile: 'default',
        id: 'nppid',
        prompt: false,
        _: ['ual aws auth'],
        $0: 'test',
      },
    });
    expect(result).toEqual(0);
  });
});
