import { AwsOpenConsole } from '../../src/commands/aws/aws-open-console';
import { afterEach, describe, expect, it, vi } from 'vitest';

describe('AWS Open Console', () => {

  afterEach(() => {
    vi.resetAllMocks();
  });

  it('opens the AWS console for an authenticated AWS profile', async () => {
    const openConsoleClass = new AwsOpenConsole();
    vi.spyOn(openConsoleClass, 'openConsole').mockImplementation(async () => Promise.resolve());

    vi.spyOn(openConsoleClass, 'getCredentials').mockImplementation(async () => {
      return {
        sessionId: '123',
        sessionKey: '123',
        sessionToken: '123',
      };
    });
    vi
      .spyOn(openConsoleClass, 'getSigningToken')
      .mockImplementation(async () => {
        return '123';
      });

    const result = await openConsoleClass.handler({
      args: {
        profile: 'default',
        _: ['ual aws open-console'],
        $0: 'test',
      },
    });

    expect(result).toEqual(0);
    expect(openConsoleClass.openConsole).toHaveBeenCalled();
    expect(openConsoleClass.getCredentials).toHaveBeenCalled();
    expect(openConsoleClass.getSigningToken).toHaveBeenCalled();

  });
});
