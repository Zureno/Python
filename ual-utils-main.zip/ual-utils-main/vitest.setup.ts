import { beforeAll, beforeEach, afterAll, vi } from "vitest";
import { server } from "./test/intercept/server";

beforeAll(() => {
  server.listen();
});

beforeEach(() => {
  vi.mock('keytar', () => {
    return {
      default: {
        findCredentials: async (name: string) => {
          if (name === 'test') {
            return [{ account: "u123456.smith", password: "fakepassword" }];
          }
          return [];
        },
        setPassword: vi.fn(),
      }
    }
  });

  vi.mock('./src/utilities', async (importOriginal) => {
    const original = await importOriginal<typeof import('./src/utilities')>();
    return {
      ...original,
      checkReload: vi.fn(),
    };
  });
})

afterAll(() => {
  server.close();
});
