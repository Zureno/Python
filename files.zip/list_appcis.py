"""
AppCI Quick Reference
Lists all 50 AppCIs found in results.csv
"""

ALL_APPCIS = [
    'AAP', 'ACZ', 'AJZ', 'AMP', 'ANU', 'AOU', 'AZF', 'AZK', 'BDZ', 'BEX',
    'BFM', 'BJB', 'BTR', 'BUM', 'BUZ', 'CBU', 'CEA', 'CNT', 'CQC', 'CQD',
    'CQO', 'CRH', 'CSP', 'CUZ', 'CZX', 'DHW', 'DTB', 'DVB', 'EAN', 'EBG',
    'EBP', 'EDS', 'EHF', 'EHO', 'EKH', 'ELE', 'ELV', 'EMI', 'EQA', 'EQC',
    'ESM', 'ETR', 'EUH', 'EWJ', 'EWL', 'EXQ', 'EYG', 'FEC', 'RDL', 'TOB'
]

print("=" * 80)
print("📋 All AppCIs from results.csv (50 total)")
print("=" * 80)
print()

# Print in columns
cols = 5
for i in range(0, len(ALL_APPCIS), cols):
    row = ALL_APPCIS[i:i+cols]
    print("  ".join(f"{appci:4}" for appci in row))

print()
print("=" * 80)
print()
print("🔍 To test any AppCI:")
print()
print("  # Quick test with defaults")
print("  python test_suite.py EQA")
print()
print("  # Test multiple AppCIs")
print("  python test_suite.py EQA BFM EBP")
print()
print("  # Run all predefined test cases")
print("  python test_suite.py")
print()
print("=" * 80)
