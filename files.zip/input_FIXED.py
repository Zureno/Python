"""
Input extraction utilities for akamaivalidator Lambda.

Extracts and validates input parameters from Lambda event.
"""

def extract_lambda_input(event: dict) -> tuple:
    """
    Extract identifier, control, and validator from Lambda event.
    
    Args:
        event: Lambda event dictionary containing:
            - identifier: Application identifier (e.g., "BFM")
            - control: Control requirement (e.g., "CDR-NSS3.4.2 - App01")
            - validator: Validator configuration dict with type and criteria
    
    Returns:
        tuple: (identifier, control, validator_dict)
    
    Example event:
        {
            "identifier": "BFM",
            "control": "CDR-NSS3.4.2 - App01",
            "validator": {
                "type": "akamai",
                "criteria": ["akamai"]
            }
        }
    """
    identifier = event.get('identifier')
    control = event.get('control')
    validator = event.get('validator', {})
    
    return identifier, control, validator
