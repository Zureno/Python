# Test Suite Usage Guide

## 📦 Two Test Suites Available

### **1. test_suite_simple.py** (Recommended for quick testing)
- Easy to read and customize
- Add your own test cases easily
- Clear pass/fail output

### **2. test_suite_comprehensive.py** (Full validation)
- Detailed comparisons
- Color-coded output
- Checks all fields thoroughly

---

## 🚀 Quick Start

### **Simple Test Suite**

```bash
cd /Users/v196361/Documents/GitHub/eqa.udcrm-control-automation/src/findingsvalidator

# Copy the test suite
cp test_suite_simple.py .

# Make it executable
chmod +x test_suite_simple.py

# Run tests
python test_suite_simple.py
```

**Output:**
```
================================================================================
TEST: EHF - Veracode CWE-20 (Should FAIL)
================================================================================

Input:
  AppCI: EHF
  Control: OWASP-V5.1.3
  Tool: veracode
  Scope: CWE
  Criteria: ['20']
  Expected: FAIL

Actual Results:
  passed: False
  confidence: medium
  finding_ids: SILK-102829361
  avit: ["['CWE-20']"]
  evidence: This requirement has failed due to findings detected...

✅ TEST PASSED
```

---

## 📝 Adding Your Own Test Cases

**Edit test_suite_simple.py:**

```python
# Add a new test
results.append(run_test(
    name="YOUR_APPCI - Description",
    event={
        "identifier": "YOUR_APPCI",
        "control": "CONTROL_NAME",
        "validator": [{
            "type": "findings",
            "tool": "veracode",  # or "invicti" or "both"
            "scope": "CWE",
            "criteria": ["79"]  # CWE number(s)
        }]
    },
    should_pass=False  # False = expect FAIL, True = expect PASS
))
```

---

## 🧪 Test Scenarios

### **FAIL Cases (Should find vulnerabilities)**

Test AppCIs that are **known to have** the specified CWE:

```python
run_test(
    name="AppCI with known CWE-20 vulnerability",
    event={
        "identifier": "EHF",
        "control": "OWASP-V5.1.3",
        "validator": [{
            "type": "findings",
            "tool": "veracode",
            "scope": "CWE",
            "criteria": ["20"]
        }]
    },
    should_pass=False  # Expect vulnerabilities found
)
```

**Expected Output:**
- ✅ `passed: false`
- ✅ `confidence: medium`
- ✅ `finding_ids: "SILK-102829361"` (populated)
- ✅ `avit: ["['CWE-20']"]` (populated)
- ✅ `evidence: "...CWE(s) and Finding Name(s) combinations..."` (detailed)

---

### **PASS Cases (Should NOT find vulnerabilities)**

Test AppCIs that are **known to be clean** for the specified CWE:

```python
run_test(
    name="AppCI without CWE-434 vulnerability",
    event={
        "identifier": "EQA",
        "control": "OWASP-V12.5.2",
        "validator": [{
            "type": "findings",
            "tool": "invicti",
            "scope": "CWE",
            "criteria": ["434"]
        }]
    },
    should_pass=True  # Expect no vulnerabilities
)
```

**Expected Output:**
- ✅ `passed: true`
- ✅ `confidence: low`
- ✅ `finding_ids: ""` (empty)
- ✅ `avit: []` (empty)
- ✅ `evidence: "This requirement has passed; no action is required."`

---

## 🎯 Common Test Patterns

### **Test Different Tools**

```python
# Veracode (SAST)
"tool": "veracode"

# Invicti (DAST)
"tool": "invicti"

# Both tools
"tool": "both"
```

### **Test Different CWEs**

```python
# Common CWEs to test:
"criteria": ["20"]   # Input Validation
"criteria": ["79"]   # XSS
"criteria": ["89"]   # SQL Injection
"criteria": ["95"]   # Code Injection
"criteria": ["434"]  # File Upload
```

### **Test Multiple CWEs**

```python
"criteria": ["79", "89", "95"]  # Test multiple at once
```

---

## 📊 Interpreting Results

### **✅ Test Passed**
All checks match expected behavior:
- Pass/Fail status correct
- finding_ids populated (if FAIL) or empty (if PASS)
- avit populated (if FAIL) or empty (if PASS)
- Confidence level correct
- Evidence format correct

### **❌ Test Failed**
One or more checks don't match:
- Check the "Full Output" section
- Verify partition_0 is commented in data.py
- Verify all 3 files updated (validate, output, index)
- Check Athena returned findings (not 0)

### **⚠️ Warning**
Non-critical issues:
- Evidence missing detailed info (still works, just not ideal)
- Minor field mismatches

---

## 🔧 Troubleshooting

### **"Retrieved 0 findings" in logs**
❌ **Problem:** partition_0 still in data.py
✅ **Fix:** Comment out line 84 in data.py

### **"passed" shows as `[true, []]`**
❌ **Problem:** index.py not unpacking tuple
✅ **Fix:** Change to `passed, matching_findings = validate_findings(...)`

### **finding_ids always empty**
❌ **Problem:** Not using COMPLETE versions of files
✅ **Fix:** Use validate_COMPLETE.py, output_COMPLETE.py, index_COMPLETE.py

### **Generic evidence (not detailed)**
❌ **Problem:** Using MINIMAL instead of COMPLETE output.py
✅ **Fix:** Use output_COMPLETE.py

---

## 🎉 Full Test Command

```bash
# Run simple tests
python test_suite_simple.py

# Or comprehensive tests (with colors)
python test_suite_comprehensive.py

# Run with verbose logging
python test_suite_simple.py 2>&1 | tee test_results.log
```

---

## 📝 Sample Test Output

```
================================================================================
FINDINGS VALIDATOR TEST SUITE
================================================================================

================================================================================
TEST: EHF - Veracode CWE-20 (Should FAIL)
================================================================================

Input:
  AppCI: EHF
  Control: OWASP-V5.1.3
  Tool: veracode
  Scope: CWE
  Criteria: ['20']
  Expected: FAIL

Actual Results:
  passed: False
  confidence: medium
  finding_ids: SILK-102829361
  avit: ["['CWE-20']"]
  evidence: This requirement has failed due to findings detected in the following CWE(s)...

✅ TEST PASSED

================================================================================
TEST: EQA - Invicti CWE-434 (Should PASS)
================================================================================

Input:
  AppCI: EQA
  Control: OWASP-V12.5.2
  Tool: invicti
  Scope: CWE
  Criteria: ['434']
  Expected: PASS

Actual Results:
  passed: True
  confidence: low
  finding_ids: 
  avit: []
  evidence: This requirement has passed; no action is required.

✅ TEST PASSED

================================================================================
SUMMARY
================================================================================

Total Tests: 2
✅ Passed: 2
❌ Failed: 0

✅ ALL TESTS PASSED!
```

---

## 🚀 Ready to Test!

1. **Make sure you've applied all fixes:**
   - validate_COMPLETE.py → validate.py
   - output_COMPLETE.py → output.py
   - index_COMPLETE.py → index.py
   - data.py line 84 commented out

2. **Run the test suite:**
   ```bash
   python test_suite_simple.py
   ```

3. **All tests should pass!** ✅
