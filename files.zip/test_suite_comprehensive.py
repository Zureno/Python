#!/usr/bin/env python3
"""
Comprehensive Test Suite for Findings Validator

Tests both PASS and FAIL scenarios across multiple AppCIs.
"""

import json
import sys
from index import handler

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'
BOLD = '\033[1m'


def print_header(text):
    """Print a bold header"""
    print(f"\n{BOLD}{BLUE}{'='*80}{RESET}")
    print(f"{BOLD}{BLUE}{text}{RESET}")
    print(f"{BOLD}{BLUE}{'='*80}{RESET}\n")


def print_test_header(test_num, total, name):
    """Print test case header"""
    print(f"\n{BOLD}[Test {test_num}/{total}] {name}{RESET}")
    print("-" * 80)


def print_pass(message):
    """Print success message"""
    print(f"{GREEN}✓ PASS{RESET} - {message}")


def print_fail(message):
    """Print failure message"""
    print(f"{RED}✗ FAIL{RESET} - {message}")


def print_warning(message):
    """Print warning message"""
    print(f"{YELLOW}⚠ WARNING{RESET} - {message}")


def compare_results(test_name, expected, actual, key):
    """Compare expected vs actual for a specific key"""
    exp_val = expected.get(key)
    act_val = actual.get(key)
    
    if exp_val == act_val:
        print_pass(f"{key}: {act_val}")
        return True
    else:
        print_fail(f"{key}: Expected '{exp_val}', Got '{act_val}'")
        return False


def run_test(test_num, total, test_case):
    """Run a single test case"""
    name = test_case['name']
    event = test_case['event']
    expected = test_case['expected']
    
    print_test_header(test_num, total, name)
    
    # Print test input
    print(f"{BOLD}Input:{RESET}")
    print(f"  AppCI: {event['identifier']}")
    print(f"  Control: {event['control']}")
    print(f"  Tool: {event['validator'][0]['tool']}")
    print(f"  Scope: {event['validator'][0]['scope']}")
    print(f"  Criteria: {event['validator'][0]['criteria']}")
    
    # Run the handler
    try:
        result = handler(event, None)
    except Exception as e:
        print_fail(f"Exception raised: {e}")
        return False
    
    # Compare results
    print(f"\n{BOLD}Results:{RESET}")
    all_passed = True
    
    # Check critical fields
    all_passed &= compare_results(name, expected, result, 'passed')
    all_passed &= compare_results(name, expected, result, 'confidence')
    all_passed &= compare_results(name, expected, result, 'number')
    
    # Check finding_ids
    exp_finding_ids = expected.get('finding_ids', '')
    act_finding_ids = result.get('finding_ids', '')
    if exp_finding_ids:
        # For FAIL cases, check if finding_ids is populated
        if act_finding_ids:
            print_pass(f"finding_ids: '{act_finding_ids}' (populated)")
        else:
            print_fail(f"finding_ids: Expected populated, Got empty")
            all_passed = False
    else:
        # For PASS cases, check if finding_ids is empty
        if not act_finding_ids:
            print_pass(f"finding_ids: Empty (as expected)")
        else:
            print_warning(f"finding_ids: Expected empty, Got '{act_finding_ids}'")
    
    # Check avit
    exp_avit = expected.get('avit', [])
    act_avit = result.get('avit', [])
    if len(exp_avit) > 0:
        # For FAIL cases, check if avit is populated
        if len(act_avit) > 0:
            print_pass(f"avit: {act_avit} (populated)")
        else:
            print_fail(f"avit: Expected populated, Got empty")
            all_passed = False
    else:
        # For PASS cases, check if avit is empty
        if len(act_avit) == 0:
            print_pass(f"avit: [] (empty as expected)")
        else:
            print_fail(f"avit: Expected empty, Got {act_avit}")
            all_passed = False
    
    # Check validation status
    exp_status = expected.get('validations', [{}])[0].get('status')
    act_status = result.get('validations', [{}])[0].get('status')
    if exp_status == act_status:
        print_pass(f"validation status: {act_status}")
    else:
        print_fail(f"validation status: Expected {exp_status}, Got {act_status}")
        all_passed = False
    
    # Check evidence content (for FAIL cases)
    if not expected['passed']:
        act_evidence = result.get('evidence', '')
        if 'CWE(s) and Finding Name(s) combinations' in act_evidence:
            print_pass("evidence: Contains detailed CWE and finding information")
        else:
            print_warning("evidence: Missing detailed CWE information")
            print(f"  Actual: {act_evidence[:100]}...")
    
    # Print summary
    print()
    if all_passed:
        print_pass(f"{BOLD}TEST PASSED{RESET}")
    else:
        print_fail(f"{BOLD}TEST FAILED{RESET}")
    
    # Print full output for debugging if test failed
    if not all_passed:
        print(f"\n{BOLD}Full Output (for debugging):{RESET}")
        print(json.dumps(result, indent=2))
    
    return all_passed


def main():
    """Run all test cases"""
    
    print_header("FINDINGS VALIDATOR - COMPREHENSIVE TEST SUITE")
    
    # Define test cases
    test_cases = [
        # ========================
        # FAIL Cases (Should find vulnerabilities)
        # ========================
        {
            'name': 'EHF - Veracode CWE-20 (SHOULD FAIL)',
            'event': {
                "identifier": "EHF",
                "control": "OWASP-V5.1.3",
                "validator": [{
                    "type": "findings",
                    "tool": "veracode",
                    "scope": "CWE",
                    "criteria": ["20"]
                }]
            },
            'expected': {
                'passed': False,
                'confidence': 'medium',
                'number': 0,
                'avit': ["['CWE-20']"],
                'finding_ids': 'SILK-102829361',  # Should be populated
                'validations': [{'status': 'FAIL'}]
            }
        },
        
        # ========================
        # PASS Cases (Should NOT find vulnerabilities)
        # ========================
        {
            'name': 'EQA - Invicti CWE-434 (SHOULD PASS)',
            'event': {
                "identifier": "EQA",
                "control": "OWASP-V12.5.2",
                "validator": [{
                    "type": "findings",
                    "tool": "invicti",
                    "scope": "CWE",
                    "criteria": ["434"]
                }]
            },
            'expected': {
                'passed': True,
                'confidence': 'low',
                'number': 1,
                'avit': [],
                'finding_ids': '',  # Should be empty
                'validations': [{'status': 'PASS'}]
            }
        },
        
        # ========================
        # Additional Test Cases
        # ========================
        {
            'name': 'EBP - Veracode CWE-95 (Test)',
            'event': {
                "identifier": "EBP",
                "control": "OWASP-V5.5.4",
                "validator": [{
                    "type": "findings",
                    "tool": "veracode",
                    "scope": "CWE",
                    "criteria": ["95"]
                }]
            },
            'expected': {
                'passed': False,  # Adjust based on actual data
                'confidence': 'medium',
                'number': 0,
                'avit': ["['CWE-95']"],
                'finding_ids': '',  # Will be populated if fails
                'validations': [{'status': 'FAIL'}]
            }
        },
        
        {
            'name': 'AAP - Veracode CWE-79 (Test)',
            'event': {
                "identifier": "AAP",
                "control": "OWASP-V7.3.4",
                "validator": [{
                    "type": "findings",
                    "tool": "veracode",
                    "scope": "CWE",
                    "criteria": ["79"]
                }]
            },
            'expected': {
                'passed': False,
                'confidence': 'medium',
                'number': 0,
                'avit': ["['CWE-79']"],
                'finding_ids': '',
                'validations': [{'status': 'FAIL'}]
            }
        },
        
        {
            'name': 'BFM - Both Tools CWE-89 (Test)',
            'event': {
                "identifier": "BFM",
                "control": "OWASP-V5.3.4",
                "validator": [{
                    "type": "findings",
                    "tool": "both",
                    "scope": "CWE",
                    "criteria": ["89"]
                }]
            },
            'expected': {
                'passed': False,
                'confidence': 'medium',
                'number': 0,
                'avit': ["['CWE-89']"],
                'finding_ids': '',
                'validations': [{'status': 'FAIL'}]
            }
        },
    ]
    
    # Run all tests
    total = len(test_cases)
    passed = 0
    failed = 0
    
    for i, test_case in enumerate(test_cases, 1):
        if run_test(i, total, test_case):
            passed += 1
        else:
            failed += 1
    
    # Print final summary
    print_header("TEST SUMMARY")
    print(f"Total Tests: {total}")
    print(f"{GREEN}Passed: {passed}{RESET}")
    print(f"{RED}Failed: {failed}{RESET}")
    
    if failed == 0:
        print(f"\n{GREEN}{BOLD}✓ ALL TESTS PASSED!{RESET}")
        sys.exit(0)
    else:
        print(f"\n{RED}{BOLD}✗ SOME TESTS FAILED{RESET}")
        sys.exit(1)


if __name__ == "__main__":
    main()
