"""
Findings validation — compare collected findings against validator criteria
"""

import re
from logger import logger


def validate_findings(validator: dict, findings_data: list[dict]) -> tuple[bool, list[str]]:
    """
    Determine whether the findings validator passes or fails.
    
    Args:
        validator:      The validator definition dict
        findings_data:  List of findings returned by data.get_findings_data()
    
    Returns:
        tuple: (passed: bool, finding_ids: list[str])
            - passed: True → PASS (no matching vulnerabilities found)
                     False → FAIL (matching vulnerabilities exist)
            - finding_ids: List of display_names (SILK IDs) that matched
    """
    criteria = validator.get("criteria", [])
    scope = validator.get("scope", "").lower()
    tool = validator.get("tool", "").lower()
    
    if not criteria:
        logger.warning("No criteria specified in validator, defaulting to PASS")
        return True, []
    
    # Check each finding
    matching_findings = []
    finding_ids = []  # Collect display_names (SILK IDs)
    
    for finding in findings_data:
        cwes_raw = finding.get("cwes", "")
        remediation = finding.get("remediation_description", "")
        scan_type_raw = finding.get("scan_type", "").upper()
        display_name = finding.get("display_name", "")  # This is the SILK ID
        
        # Normalize scan type
        if scan_type_raw in ['STATIC', 'SAST', 'SCA']:
            scan_type = 'veracode'
        elif scan_type_raw in ['DYNAMIC', 'DAST']:
            scan_type = 'invicti'
        else:
            scan_type = scan_type_raw.lower()
        
        # Skip if tool doesn't match
        if tool != "both" and tool != scan_type:
            continue
        
        # CWE-based validation
        if scope == "cwe":
            # Extract CWE numbers from cwes field
            cwes_str = str(cwes_raw).replace('[', '').replace(']', '').replace("'", '').replace('"', '')
            cwe_numbers = []
            for part in cwes_str.split(','):
                part = part.strip()
                match = re.search(r'(?:CWE-)?(\d+)', part)
                if match:
                    cwe_numbers.append(match.group(1))
            
            # Check if any criteria CWE matches
            for crit in criteria:
                crit_str = str(crit).strip()
                crit_match = re.search(r'(?:CWE-)?(\d+)', crit_str)
                if crit_match:
                    crit_num = crit_match.group(1)
                    if crit_num in cwe_numbers:
                        # Match found!
                        matching_findings.append(finding)
                        
                        # Capture Finding ID (SILK ID from display_name) - REFERENCE IMPLEMENTATION
                        silk_id = str(display_name).strip()
                        if silk_id and silk_id not in finding_ids:
                            finding_ids.append(silk_id)
                        
                        logger.info(
                            f"CWE match found - CWE: {crit_num}, "
                            f"display_name: {display_name}"
                        )
                        break
        
        # Remediation description-based validation
        else:
            remediation_norm = str(remediation).strip().lower()
            for crit in criteria:
                crit_norm = str(crit).strip().lower()
                if crit_norm in remediation_norm:
                    matching_findings.append(finding)
                    
                    # Capture Finding ID (SILK ID from display_name) - REFERENCE IMPLEMENTATION
                    silk_id = str(display_name).strip()
                    if silk_id and silk_id not in finding_ids:
                        finding_ids.append(silk_id)
                    
                    logger.info(
                        f"Remediation match found - criteria: {crit}, "
                        f"display_name: {display_name}"
                    )
                    break
    
    # Determine pass/fail
    if matching_findings:
        logger.info(f"Findings validation FAILED — {len(matching_findings)} matching vulnerabilities found")
        return False, finding_ids
    else:
        logger.info("Findings validation PASSED — no matching vulnerabilities found")
        return True, []
