# Minimal Fix for finding_ids - Based on Reference Implementation

## 🔍 Discovery from Reference Code

After analyzing `validator.zip`, I found how finding_ids are actually generated:

```python
# From findings_validator.py lines 116-118 and 209-211
silk_id = str(display_name).strip()
if silk_id and silk_id not in evidence["FindingIDs"]:
    evidence["FindingIDs"].append(silk_id)
```

## 🎯 Key Insight

**Finding ID = `display_name` field** (NOT a separate `finding_id` field!)

- The `display_name` field contains values like `"SILK-102829361"`
- This is collected during validation
- Later joined into comma-separated string for output

---

## ✅ What Changed (Minimal Fix)

### **1. validate.py** → Returns `(bool, list[str])`

**OLD:**
```python
def validate_findings(validator: dict, findings_data: list[dict]) -> bool:
    # ...
    return False  # or True
```

**NEW:**
```python
def validate_findings(validator: dict, findings_data: list[dict]) -> tuple[bool, list[str]]:
    finding_ids = []  # Collect SILK IDs
    
    for finding in findings_data:
        display_name = finding.get("display_name", "")  # This is the SILK ID
        # ... matching logic ...
        if match:
            # Capture Finding ID (from reference implementation)
            silk_id = str(display_name).strip()
            if silk_id and silk_id not in finding_ids:
                finding_ids.append(silk_id)
    
    return False, finding_ids  # or (True, [])
```

**Changes:**
- Return type: `bool` → `tuple[bool, list[str]]`
- Collect `display_name` into `finding_ids` list
- Return `finding_ids` along with passed/failed status

---

### **2. output.py** → Accept and join `finding_ids`

**OLD:**
```python
def build_result(identifier, control, validator, passed) -> dict:
    return {
        # ...
        "finding_ids": "",  # Always empty
    }
```

**NEW:**
```python
def build_result(identifier, control, validator, passed, finding_ids: list[str] = None) -> dict:
    if finding_ids is None:
        finding_ids = []
    
    # Join list into comma-separated string
    finding_ids_str = ", ".join(finding_ids) if finding_ids else ""
    
    return {
        # ...
        "finding_ids": finding_ids_str,  # Now populated
    }
```

**Changes:**
- Accept `finding_ids` parameter (list of strings)
- Join with `", "` to create comma-separated string
- Use in output

---

### **3. index.py** → Unpack tuple

**OLD:**
```python
passed = validate_findings(validator, findings_data)
result = build_result(identifier, control, validator, passed)
```

**NEW:**
```python
passed, finding_ids = validate_findings(validator, findings_data)
result = build_result(identifier, control, validator, passed, finding_ids)
```

**Changes:**
- Unpack tuple from `validate_findings`
- Pass `finding_ids` to `build_result`

---

### **4. data.py** → NO CHANGES NEEDED!

Your current data.py already has `display_name` in the SELECT:
```python
f"  {_q('display_name')} "
```

**Just comment out partition_0** (you said you already did this):
```python
# f"  AND {_q('partition_0')} = '{yesterday_ymd}' "
```

---

## 📦 Files to Replace

Only **3 files** need changes:

1. ✅ **validate.py** → `validate_MINIMAL_FIX.py`
2. ✅ **output.py** → `output_MINIMAL_FIX.py`
3. ✅ **index.py** → `index_MINIMAL_FIX.py`
4. ⚠️ **data.py** → Just comment out partition_0 line 84 (you already did this)

---

## 🧪 Test Case

**Input:**
```json
{
  "identifier": "EHF",
  "control": "OWASP-V5.1.3",
  "validator": [{
    "type": "findings",
    "tool": "veracode",
    "scope": "CWE",
    "criteria": ["20"]
  }]
}
```

**Expected Output:**
```json
{
  "finding_ids": "SILK-102829361",  // From display_name field
  "passed": false,
  // ...
}
```

---

## 🔄 Data Flow

```
data.py
  ↓ Athena query returns display_name field
validate.py
  ↓ Collects display_name into finding_ids list
  ↓ Returns (passed, finding_ids)
index.py
  ↓ Unpacks tuple
  ↓ Passes finding_ids to build_result
output.py
  ↓ Joins list with ", "
  ↓ Returns finding_ids_str in result dict
```

---

## ✅ Why This Will Work

1. **Based on actual reference implementation** (not guessing)
2. **Minimal changes** (only 3 files, simple modifications)
3. **Uses existing data** (display_name already in SELECT)
4. **Matches reference pattern** (same logic as working code)

---

## 📋 Installation Steps

```bash
cd /Users/v196361/Documents/GitHub/eqa.udcrm-control-automation/src/findingsvalidator

# Backup (if not already done)
mkdir -p backup_$(date +%Y%m%d_%H%M%S)
cp validate.py output.py index.py data.py backup_*/

# Replace files
cp validate_MINIMAL_FIX.py validate.py
cp output_MINIMAL_FIX.py output.py
cp index_MINIMAL_FIX.py index.py

# Verify partition_0 is commented in data.py (line 84)
grep -n "partition_0" data.py

# Test
python index.py
```

---

## 🎯 What This Fixes

✅ **finding_ids now populated** with actual SILK IDs from display_name
✅ **Minimal code changes** (easier to debug)
✅ **Based on reference** (proven pattern)
✅ **No complex logic** (just collect and join)

This is the **simplest fix that matches the reference implementation**! 🚀
