"""
Build validation result and write to DynamoDB
"""

import json
import boto3
from datetime import datetime
from botocore.exceptions import ClientError
from logger import logger


# ---------------------------------------------------------------------------
# DynamoDB table for validation results
# ---------------------------------------------------------------------------
TABLE_NAME = "eqa-validation-results-table"
dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
table = dynamodb.Table(TABLE_NAME)


# ---------------------------------------------------------------------------
# Build the sort key:  control#[validator]
# ---------------------------------------------------------------------------
def build_sort_key(control: str, validator: dict) -> str:
    """Build composite sort key for DynamoDB."""
    return f"{control}#[{validator}]"


# ---------------------------------------------------------------------------
# Confidence — single validator type → "low"
# ---------------------------------------------------------------------------
CONFIDENCE_MAP = {1: "low", 2: "medium"}


def get_confidence(num_validator_types: int) -> str:
    """Determine confidence level based on number of validator types."""
    return CONFIDENCE_MAP.get(num_validator_types, "high" if num_validator_types >= 3 else "NA")


# ---------------------------------------------------------------------------
# Evidence message builders (findings-specific)
# ---------------------------------------------------------------------------
def _build_evidence_message(identifier: str, criteria: list, passed: bool) -> str:
    """
    Return a human-readable evidence string for the findings validator.
    
    Args:
        identifier: AppCI identifier
        criteria: Criteria list (CWE IDs or remediation keywords)
        passed: Whether validation passed
        
    Returns:
        Evidence message string
    """
    if passed:
        return "This requirement has passed; no action is required."
    else:
        criteria_str = ", ".join([str(c) for c in criteria])
        return (
            f"This requirement has failed because vulnerabilities matching criteria "
            f"[{criteria_str}] were found in AppCI {identifier}."
        )


# ---------------------------------------------------------------------------
# Build the standardised result dict
# ---------------------------------------------------------------------------
def build_result(
    identifier: str,
    control: str,
    validator: dict,
    passed: bool,
    finding_ids: list[str] = None,  # MINIMAL FIX: Accept finding_ids list
) -> dict:
    """
    Assemble the validation result dict matching the expected output schema.
    
    Args:
        identifier: AppCI identifier
        control: Control name
        validator: Validator config dict
        passed: Whether validation passed
        finding_ids: List of SILK IDs (display_names) from matching findings
        
    Returns:
        Complete result dict
    """
    if finding_ids is None:
        finding_ids = []
    
    criteria = validator.get("criteria", [])
    status = "PASS" if passed else "FAIL"
    
    # Single-validator validation entry
    validation_entry = {
        "type": validator.get("type", "findings"),
        "tool": validator.get("tool", ""),
        "scope": validator.get("scope", ""),
        "criteria": criteria,
        "identifier": identifier,
        "name": control,
        "status": status,
    }
    
    # Raw evidence — matches expected pattern
    if passed:
        raw_evidence = (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has passed because the following criteria passed: {criteria}"
        )
    else:
        raw_evidence = (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has failed because the following criteria failed: {criteria}"
        )
    
    # Human-readable evidence
    evidence = _build_evidence_message(identifier, criteria, passed)
    
    # Truncate if exceeding ServiceNow 4000-char limit
    if len(evidence) > 4000:
        evidence = evidence[:3997] + "..."
    
    # MINIMAL FIX: Join finding_ids list into comma-separated string
    finding_ids_str = ", ".join(finding_ids) if finding_ids else ""
    
    return {
        "control": control,
        "passed": passed,
        "avit": [],
        "number": 1 if passed else 0,
        "confidence": get_confidence(1),  # single validator type → "low"
        "validations": [validation_entry],
        "raw_evidence": raw_evidence,
        "evidence": evidence,
        "finding_ids": finding_ids_str,  # MINIMAL FIX: Now populated
        "review_required": "No",
    }


# ---------------------------------------------------------------------------
# Write result to DynamoDB
# ---------------------------------------------------------------------------

def write_result(identifier: str, control: str, validator: dict, result: dict) -> str:
    """
    Persist the validation result to eqa-validation-results-table.
    
    Key schema:
        PK  = identifier  (AppCI)
        SK  = control#[validator]
    
    Args:
        identifier: AppCI identifier
        control: Control name
        validator: Validator config
        result: Result dict to write
        
    Returns:
        Success message
    """
    sort_key = build_sort_key(control, validator)
    current_date = datetime.now().strftime("%m/%d/%Y")
    
    try:
        table.update_item(
            Key={
                "identifier": identifier,
                "control#validator": sort_key,
            },
            UpdateExpression="SET #res = :res, last_processed = :date",
            ExpressionAttributeNames={"#res": "result"},
            ExpressionAttributeValues={
                ":res": json.dumps(result),
                ":date": current_date,
            },
            ReturnValues="UPDATED_NEW",
        )
        msg = f"Successfully updated results for identifier={identifier}, sort_key={sort_key}"
        logger.info(msg)
        return msg
    
    except ClientError as e:
        error_msg = f"Error updating validator result: {e.response['Error']['Message']}"
        logger.error(error_msg)
        raise ValueError(error_msg) from e
