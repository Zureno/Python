#!/usr/bin/env python3
"""
Simple Test Suite for Findings Validator

Easy to customize - just add your test cases below.
"""

import json
from index import handler


def run_test(name, event, should_pass):
    """
    Run a single test case
    
    Args:
        name: Test name
        event: Test event dict
        should_pass: True if expecting PASS, False if expecting FAIL
    """
    print(f"\n{'='*80}")
    print(f"TEST: {name}")
    print(f"{'='*80}")
    
    # Print input
    print(f"\nInput:")
    print(f"  AppCI: {event['identifier']}")
    print(f"  Control: {event['control']}")
    validator = event['validator'][0]
    print(f"  Tool: {validator['tool']}")
    print(f"  Scope: {validator['scope']}")
    print(f"  Criteria: {validator['criteria']}")
    print(f"  Expected: {'PASS' if should_pass else 'FAIL'}")
    
    # Run test
    try:
        result = handler(event, None)
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        return False
    
    # Check results
    passed = result.get('passed')
    finding_ids = result.get('finding_ids', '')
    avit = result.get('avit', [])
    confidence = result.get('confidence')
    evidence = result.get('evidence', '')
    
    print(f"\nActual Results:")
    print(f"  passed: {passed}")
    print(f"  confidence: {confidence}")
    print(f"  finding_ids: {finding_ids}")
    print(f"  avit: {avit}")
    print(f"  evidence: {evidence[:150]}..." if len(evidence) > 150 else f"  evidence: {evidence}")
    
    # Validate
    success = True
    
    if passed != should_pass:
        print(f"\n❌ MISMATCH: Expected passed={should_pass}, Got passed={passed}")
        success = False
    
    if not should_pass:  # FAIL case
        if not finding_ids:
            print(f"❌ MISSING: finding_ids should be populated for FAIL case")
            success = False
        if len(avit) == 0:
            print(f"❌ MISSING: avit should be populated for FAIL case")
            success = False
        if confidence != 'medium':
            print(f"❌ WRONG: confidence should be 'medium' for FAIL, got '{confidence}'")
            success = False
        if 'CWE(s) and Finding Name(s) combinations' not in evidence:
            print(f"⚠️  WARNING: evidence missing detailed CWE information")
    else:  # PASS case
        if finding_ids:
            print(f"⚠️  WARNING: finding_ids should be empty for PASS case")
        if len(avit) > 0:
            print(f"❌ WRONG: avit should be empty for PASS case")
            success = False
        if confidence != 'low':
            print(f"❌ WRONG: confidence should be 'low' for PASS, got '{confidence}'")
            success = False
    
    if success:
        print(f"\n✅ TEST PASSED")
    else:
        print(f"\n❌ TEST FAILED")
        print(f"\nFull Output:")
        print(json.dumps(result, indent=2))
    
    return success


def main():
    """Run all test cases"""
    
    print("\n" + "="*80)
    print("FINDINGS VALIDATOR TEST SUITE")
    print("="*80)
    
    results = []
    
    # =========================================================================
    # TEST 1: FAIL Case - EHF should have CWE-20 vulnerabilities
    # =========================================================================
    results.append(run_test(
        name="EHF - Veracode CWE-20 (Should FAIL)",
        event={
            "identifier": "EHF",
            "control": "OWASP-V5.1.3",
            "validator": [{
                "type": "findings",
                "tool": "veracode",
                "scope": "CWE",
                "criteria": ["20"]
            }]
        },
        should_pass=False  # Expect FAIL
    ))
    
    # =========================================================================
    # TEST 2: PASS Case - EQA should NOT have CWE-434 vulnerabilities
    # =========================================================================
    results.append(run_test(
        name="EQA - Invicti CWE-434 (Should PASS)",
        event={
            "identifier": "EQA",
            "control": "OWASP-V12.5.2",
            "validator": [{
                "type": "findings",
                "tool": "invicti",
                "scope": "CWE",
                "criteria": ["434"]
            }]
        },
        should_pass=True  # Expect PASS
    ))
    
    # =========================================================================
    # TEST 3: Add your own test case
    # =========================================================================
    results.append(run_test(
        name="EBP - Veracode CWE-95",
        event={
            "identifier": "EBP",
            "control": "OWASP-V5.5.4",
            "validator": [{
                "type": "findings",
                "tool": "veracode",
                "scope": "CWE",
                "criteria": ["95"]
            }]
        },
        should_pass=False  # Adjust based on your data
    ))
    
    # =========================================================================
    # TEST 4: Both tools test
    # =========================================================================
    results.append(run_test(
        name="BFM - Both Tools CWE-89",
        event={
            "identifier": "BFM",
            "control": "OWASP-V5.3.4",
            "validator": [{
                "type": "findings",
                "tool": "both",
                "scope": "CWE",
                "criteria": ["89"]
            }]
        },
        should_pass=False  # Adjust based on your data
    ))
    
    # =========================================================================
    # SUMMARY
    # =========================================================================
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    total = len(results)
    passed = sum(results)
    failed = total - passed
    
    print(f"\nTotal Tests: {total}")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    
    if failed == 0:
        print(f"\n✅ ALL TESTS PASSED!")
        return 0
    else:
        print(f"\n❌ SOME TESTS FAILED")
        return 1


if __name__ == "__main__":
    exit(main())
